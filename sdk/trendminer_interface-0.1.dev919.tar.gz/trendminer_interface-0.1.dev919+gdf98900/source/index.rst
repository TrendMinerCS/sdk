trendminer-interface
====================

.. toctree::
    :maxdepth: 2

    getting_started/index
    use_cases/index
    admin workflows/index