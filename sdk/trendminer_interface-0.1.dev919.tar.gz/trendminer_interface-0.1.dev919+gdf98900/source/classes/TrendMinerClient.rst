.. _client:

================
TrendMinerClient
================
.. currentmodule:: trendminer_interface

.. autoclass:: TrendMinerClient
    :inherited-members:
