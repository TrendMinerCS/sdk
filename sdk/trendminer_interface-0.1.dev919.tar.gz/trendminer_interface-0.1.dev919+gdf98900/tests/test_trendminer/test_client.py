from pprint import pprint


def test_client_methods(client, user1):
    for tmc in [client, user1]:
        assert tmc
        assert tmc.version
        assert tmc.resolution
        assert tmc.index_horizon
        pprint(tmc.license)


def test_session(client, user1):
    for tmc in [client, user1]:
        assert tmc
        assert not tmc.session.access_expired
        tmc.session.assure_valid_token()
        assert tmc.session.token
        tmc.session.token_refresh()
        assert tmc.session.base_url
        assert tmc.session.token_expiration_margin
        assert tmc.session.token_decoded


def test_logout(user1):
    user1.logout()
