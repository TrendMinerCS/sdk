from copy import deepcopy


def test_create(user1):

    prefix = user1.unique_prefix

    # basic formula
    formula = user1.formula(
        name=prefix,
        formula="A+B",
        mapping={
            "A": "TM_hour_Europe_Brussels",
            "B": "TM_hour_US_Eastern",
        }
    )
    formula.save()
    formula.description = prefix
    formula.update()
    formula = user1.formula.from_path(prefix)
    formula = user1.formula.from_identifier(formula.identifier)
    formula.delete()

    # with shifts
    h1 = user1.tag.from_name("TM_hour_Europe_Brussels")
    h2 = user1.tag.from_name("TM_hour_US_Eastern")
    h2.shift = 120
    day = user1.tag.from_name("TM_day_Europe_Brussels")
    day_shifted = deepcopy(day)
    day_shifted.shift = "-1s"

    formula = user1.formula(
        name=prefix,
        formula="if(A>10, A, max(sin(B)^2, tanh(B))) + phase + 0*phase_shifted",
        mapping={
            "A": h1,
            "B": h2,
            "phase": day,
            "phase_shifted": day_shifted,
        }
    )
    formula.save()
    formula.description = prefix
    formula.update()
    formula = user1.formula.from_path(prefix)
    formula = user1.formula.from_identifier(formula.identifier)
    formula.delete()


def test_browse(user1):
    prefix = user1.unique_prefix
    folder = user1.folder(name=prefix)
    folder.save()
    # basic formula
    formula = user1.formula(
        name=prefix,
        formula="A",
        mapping={
            "A": "TM_hour_Europe_Brussels",
        },
        parent=folder
    )
    formula.save()
    formula = user1.formula.from_path(f"{prefix}/{formula.name}")
    assert folder.get_children()
    assert folder.get_children(included=["formula"])
    assert user1.formula.search(prefix)
    formula.delete()
    folder.delete()


def test_digital_states(user1):
    prefix = user1.unique_prefix
    formula = user1.formula(
        name=prefix,
        formula='if(or(v0="ALPHA", v0="BETA"), 100, 200)',
        mapping={
            "v0": "TM4-BP2-PRODUCT.1",
        },
    )
    formula.save()
    formula.delete()
