from trendminer_interface import _input as ip
from trendminer_interface.exceptions import ResourceNotFound, AmbiguousResource
import pytest


def test_match():
    items=[
        {
            "name": "A",
            "value": 0
        },
        {
            "name": "a",
            "value": 1,
         },
        {
            "name": "b",
            "value": 2
        },
        {
            "name": "c",
            "value": 3,
        },
        {
            "name": "c",
            "value": 4
        }
    ]

    assert ip.dict_match_nocase(items, key="name", value="b")["value"] == 2
    assert ip.dict_match_nocase(items, key="name", value="B")["value"] == 2
    assert ip.dict_match_nocase(items, key="name", value="A")["value"] == 0

    with pytest.raises(ResourceNotFound):
        ip.dict_match_nocase(items, key="name", value="d")

    with pytest.raises(AmbiguousResource):
        ip.dict_match_nocase(items, key="name", value="c")


def test_correct_value():
    d = {
        "a": "A",
        "aa": "A",
        "b": "B",
        "bb": "B",
    }

    assert ip.correct_value("a", d) == "A"
    assert ip.correct_value("AA", d) == "A"
    with pytest.raises(ValueError):
        ip.correct_value("c", d)
