import keycloak.exceptions
import keyring
from confighub_interface import ConfigClient
from trendminer_interface import TrendMinerClient
from trendminer_interface.exceptions import ResourceNotFound
from config import system_administrator, client, username1, username2, asset_framework_name
from getpass import getpass
import secrets
import pandas as pd

url = client["url"]
client_id = client["client_id"]
admin_name = system_administrator["username"]

# Set client secret (client id should already exist)
print(f"Setting client secret for '{client_id}'")
while True:
    try:
        TrendMinerClient(
            url=url,
            client_id=client_id,
            client_secret=keyring.get_password(url, client_id),
        )
        print(f"  Credentials set successfully!")
        break
    except (ValueError, keycloak.exceptions.KeycloakAuthenticationError):
        keyring.set_password(url, client_id, getpass(f" {client_id} client secret: "))


# Set config admin password (user should already exist)
print(f"\nSetting password for '{admin_name}'")
while True:
    try:
        cfg = ConfigClient(
            url=url,
            client_id=client_id,
            client_secret=keyring.get_password(url, client_id),
            username=system_administrator["username"],
            password=keyring.get_password(url, admin_name)
        )
        admin = TrendMinerClient(
            url=url,
            client_id=client_id,
            client_secret=keyring.get_password(url, client_id),
            username=system_administrator["username"],
            password=keyring.get_password(url, admin_name)
        )
        print(f"  Credentials set successfully!")
        break
    except (ValueError, keycloak.exceptions.KeycloakAuthenticationError):
        keyring.set_password(url, admin_name, getpass(f" {admin_name} password: "))


# Create regular users
for username in [username1, username2]:
    print(f"\nCreating/retrieving user '{username}'")
    pw = secrets.token_urlsafe(15) + "aA!"
    try:
        user = cfg.user.by_name(username)
        try:
            TrendMinerClient(
                url=url,
                client_id=client_id,
                client_secret=keyring.get_password(url, client_id),
                username=username,
                password=keyring.get_password(url, username),
            )
            print("  Existing credentials validated!")
            break
        except (ValueError, keycloak.exceptions.KeycloakAuthenticationError):
            user.set_password(pw)
            print("  Password reset")

    except ResourceNotFound:
        user = cfg.user(
            name=username,
            first_name=username,
            last_name="SDK test account",
            mail=f"{username}.SDK@trendminer.com"
        )
        user.save(password=pw)

    while True:
        keyring.set_password(url, username, getpass(f" {username} initial pw: {pw}\n new password: "))
        try:
            TrendMinerClient(
                url=url,
                client_id=client_id,
                client_secret=keyring.get_password(url, client_id),
                username=username,
                password=keyring.get_password(url, username),
            )
            print("  New credentials validated!")
            break
        except (ValueError, keycloak.exceptions.KeycloakAuthenticationError):
            pass


# Load or retrieve asset framework; add user permissions
print(f"\nChecking/creating asset framework '{asset_framework_name}'")
try:
    af = admin.asset.framework.by_name(asset_framework_name)
    print(" Already exists. No new asset framework created")
except (ResourceNotFound, KeyError):
    df = pd.read_csv("data/asset_framework.csv")
    af = admin.asset.framework(
        name=asset_framework_name,
        df=df,
        published=True,
    )
    af.save()
    af.wait_for_sync()
    print(" Successfully created!")

for username in [username1, username2]:
    af.get_root_asset().access.remove(username)  # removing right that does not exist does not give an error
    af.get_root_asset().access.add(username, permissions=["read"])

# Index demo tags
print("Sending index requests for all demo tags")
for tag in admin.tag.search(datasources=["DEMO"]):
    tag.index()
print(" Done!")

