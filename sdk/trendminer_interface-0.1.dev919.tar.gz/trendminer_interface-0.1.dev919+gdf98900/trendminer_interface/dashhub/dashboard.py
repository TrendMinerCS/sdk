from trendminer_interface.base import ByFactory, kwargs_to_class,  WorkOrganizerObjectBase, WorkOrganizerObjectFactoryBase

from .tile import (TileMultiFactory, TrendHubViewTileFactory,
                   CounterTileFactory, TableTileFactory,
                   GanttTileFactory, MonitorTileFactory,
                   ExternalContentTileFactory, CurrentValueTileFactory,
                   TextTileFactory)


class Dashboard(WorkOrganizerObjectBase):
    """TrendMiner dashboard (DashHub view)

    Attributes
    ----------
    live : bool
        Whether the dashboard is updating live
    scrollable : bool
        Whether the dashboard is scrollable
    tiles : list
        Tiles that are on the dashboard
    """
    content_type = "DASHBOARD"
    tiles = ByFactory(TileMultiFactory, "_list")

    # pylint: disable=too-many-arguments
    def __init__(
            self,
            client,
            identifier,
            name,
            description,
            parent,
            owner,
            last_modified,
            tiles,
            live,
            scrollable,
    ):

        WorkOrganizerObjectBase.__init__(self, client=client, identifier=identifier, name=name, description=description,
                                         parent=parent, owner=owner, last_modified=last_modified)

        self.live = live
        self.scrollable = scrollable
        self.tiles = tiles

    def _json_data(self):
        return {
            "autoRefreshEnabled": self.live,
            "scrollable": self.scrollable,
            "tiles": [tile._json() for tile in self.tiles],
        }

    def _full_instance(self):
        return DashboardFactory(client=self.client).from_identifier(self.identifier)


class DashboardFactory(WorkOrganizerObjectFactoryBase):
    """Factory for initializing and retrieving dashboards"""
    tm_class = Dashboard

    def __call__(self,
                 tiles,
                 name='New Dashboard',
                 description='',
                 parent=None,
                 live=False,
                 scrollable=False,
                 ):
        """Initialize a new dashboard

        Parameters
        ----------
        tiles : list
            Tiles to add to the dashboard
        name : str, default "New Dashboard"
            Name of the dashboard
        description : str, optional
            Dashboard description
        parent : Folder or str
            Folder in which the dashboard needs to be saved
        live : bool
            Whether the dashboard will be updated live
        scrollable : bool
            Whether the dashboard needs to be scrollable

        Returns
        -------
        Dashboard
        """

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            parent=parent,
            owner=None,
            last_modified=None,
            tiles=tiles,
            live=live,
            scrollable=scrollable,
        )

    @kwargs_to_class
    def _from_json(self, data):
        """Enriched response json to dashboard

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        Dashboard
        """
        return {
            **self._json_to_kwargs_base(data),
            "live": data["data"]["autoRefreshEnabled"],
            "tiles": [
                TileMultiFactory(client=self.client)._from_json(tile)
                for tile in data["data"]["tiles"]
            ],
            "scrollable": data["data"]["scrollable"],
        }

    @property
    def trend(self):
        """TrendHub view tile factory

        Returns
        -------
        TrendHubViewTileFactory
        """
        return TrendHubViewTileFactory(client=self.client)

    @property
    def count(self):
        """ContextHub view counter tile factory

        Returns
        -------
        CounterTileFactory
        """
        return CounterTileFactory(client=self.client)

    @property
    def table(self):
        """ContextHub view table tile factory

        Returns
        -------
        TableTileFactory
        """
        return TableTileFactory(client=self.client)

    @property
    def gantt(self):
        """ContextHub view gantt tile factory

        Returns
        -------
        GanttTileFactory
        """
        return GanttTileFactory(client=self.client)

    @property
    def monitor(self):
        """Monitor tile factory

        Returns
        -------
        MonitorTileFactory
        """
        return MonitorTileFactory(client=self.client)

    @property
    def external(self):
        """External content tile factory

        Returns
        -------
        ExternalContentTileFactory
        """
        return ExternalContentTileFactory(client=self.client)

    @property
    def text(self):
        """Text tile factory

        Returns
        -------
        TextTileFactory
        """
        return TextTileFactory(client=self.client)

    @property
    def values(self):
        """Current value tile factory

        Returns
        -------
        CurrentValueTileFactory
        """
        return CurrentValueTileFactory(client=self.client)
