import abc

from .base import TileBase, TileFactoryBase
from trendminer_interface.context import ContextHubViewFactory


class ContextTileBase(TileBase, abc.ABC):
    """ContextHub tile base class

    Tile content is a ContextHub view
    """
    visualization_type = "CONTEXT_HUB_VIEW"
    display_mode = None
    min_size = (1, 2)

    def _get_content(self, content):
        """Convert content into ContextHub view

        Attributes
        ----------
        content : ContextHubView or Any

        Returns
        -------
        ContextHub view
        """
        return ContextHubViewFactory(client=self.client)._get(content)

    def _json_configuration(self):
        return {
            "displayMode": self.display_mode,
            "configurationType": self.visualization_type,
            "contextViewId": self.content.identifier,
        }


class ContextTileFactoryBase(TileFactoryBase, abc.ABC):
    """ContextHub tile parent class"""
    tm_class = ContextTileBase

    def _from_json_content(self, data):
        return ContextHubViewFactory(client=self.client)._from_json_identifier_only(data["contextViewId"])


class CounterTile(ContextTileBase):
    """ContextHub view counter tile"""
    display_mode = "COUNT"


class CounterTileFactory(ContextTileFactoryBase):
    """ContextHub view counter tile factory"""
    tm_class = CounterTile


class TableTile(ContextTileBase):
    """ContextHub view table tile"""
    display_mode = "TABLE"


class TableTileFactory(ContextTileFactoryBase):
    """ContextHub view table tile factory"""
    tm_class = TableTile


class GanttTile(ContextTileBase):
    """ContextHub view Gantt tile"""
    display_mode = "GANTT"


class GanttTileFactory(ContextTileFactoryBase):
    """ContextHub view Gantt tile factory"""
    tm_class = GanttTile
