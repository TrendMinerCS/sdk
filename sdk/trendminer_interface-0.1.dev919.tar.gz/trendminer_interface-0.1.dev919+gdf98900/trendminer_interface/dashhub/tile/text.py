from .base import TileBase, TileFactoryBase


class TextTile(TileBase):
    """External content dashboard tile"""
    visualization_type = "RICH_TEXT"
    min_size = (1, 1)

    def _json_configuration(self):
        return {
            "configurationType": self.visualization_type,
            "content": self.content,
        }


class TextTileFactory(TileFactoryBase):
    """Factory for creating external conten dahboard tiles"""
    tm_class = TextTile

    def _from_json_content(self, data):
        return data["content"]
