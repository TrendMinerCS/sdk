from datetime import datetime

from trendminer_interface.base import AuthenticatableBase

from .interval import IntervalFactory


class TimeFactory(AuthenticatableBase):
    """Factory with some time-related methods, also serving as parent to other time-related factories

    All outcomes are given in the client timezone
    """

    def now(self):
        """Current time

        Returns
        -------
        now : datetime
            The current time
        """
        return datetime.now(tz=self.client.tz)


    @property
    def interval(self):
        """Interval factory for generating intervals

        Returns
        -------
        IntervalFactory
        """
        return IntervalFactory(client=self.client)
