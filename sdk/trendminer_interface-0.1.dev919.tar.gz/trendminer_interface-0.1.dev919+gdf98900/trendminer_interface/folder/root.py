from .base import FolderBase


class RootFolder(FolderBase):
    """Work organize root folder

    The root folder is an artificial construct. It is not an actual folder in the appliance. Its identifier is None, and
    it does not have a name or owner.

    When a work organizer object is stored in the root directory, it does not have a parent (`parent=None`). It does
    NOT have a WorkOrganizerRoot instance as parent.

    This class only implements the methods required to browse the work organizer root folder.
    """
    pass  # All methods are implemented on FolderBase
