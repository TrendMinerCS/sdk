import pandas as pd
import numpy as np
import random
import trendminer_interface._input as ip

from .functions import sample, calculate


@pd.api.extensions.register_series_accessor("interval")
class IntervalSeriesAccessor:

    def __init__(self, pandas_obj):
        self._validate(pandas_obj)
        self._obj = pandas_obj

    @staticmethod
    def _validate(obj):
        if not isinstance(obj.name, pd.Interval):
            raise AttributeError("Methods can only be applied on DataFrame with IntervalIndex index")

    def set_closed(self, closed):
        return self._set_interval(
            left=self._obj.left,
            right=self._obj.right,
            closed=closed,
            keep_as=None,
        )

    def _set_interval(self, left, right, closed, keep_as):
        ser = self._obj.copy()
        ser.name = pd.Interval(
            left=left,
            right=right,
            closed=closed,
        )

        if keep_as is not None:
            ser[keep_as] = self._obj.name

        return ser

    def _move_interval(self, left, right, keep_as):
        if left is not None:
            left = self._obj.name.left + pd.Timedelta(left)
        if right is not None:
            right = self._obj.name.right + pd.Timedelta(right)
        return self._set_interval(left=left, right=right, closed=self._obj.name.closed, keep_as=keep_as)

    def grow(self, left=None, right=None, keep_as=None):
        if left is not None:
            left = -pd.Timedelta(left)
        return self._move_interval(left=left, right=right, keep_as=keep_as)

    def shrink(self, left=None, right=None, keep_as=None):
        if right is not None:
            right = -pd.Timedelta(right)
        return self._move_interval(left=left, right=right, keep_as=keep_as)

    def after_start(self, length, keep_as=None):
        return self._set_interval(
            right=self._obj.index.left + pd.Timedelta(length),
            left=None,
            closed=self._obj.name.closed,
            keep_as=keep_as,
        )

    def after_end(self, length, keep_as=None):
        return self._set_interval(
            left=self._obj.index.right,
            right=self._obj.index.right + pd.Timedelta(length),
            closed=self._obj.name.closed,
            keep_as=keep_as,
        )

    def before_start(self, length, keep_as=None):
        return self._set_interval(
            left=self._obj.index.left - pd.Timedelta(length),
            right=self._obj.index.left,
            closed=self._obj.name.closed,
            keep_as=keep_as,
        )

    def before_end(self, length, keep_as=None):
        return self._set_interval(
            left=self._obj.index.right - pd.Timedelta(length),
            right=None,
            closed=self._obj.name.closed,
            keep_as=keep_as,
        )

    def round(self, freq, left="shrink", right="shrink"):
        """Round the interval to a given frequency

        Parameters
        ----------
        freq : pd.Timedelta
            Rounding frequency
        left : str, default 'shrink'
            - 'shrink' round interval start timestamp inwards, shrinking the interval
            - 'grow' round interval start timestamp outwards, growing the interval
            - 'nearest' round interval start timestamp to the nearest rounded timestamp
        right : str, default 'shrink'
            - 'shrink' round interval end timestamp inwards, shrinking the interval
            - 'grow' round interval end timestamp outwards, growing the interval
            - 'nearest' round interval end timestamp to the nearest rounded timestamp
        drop : bool, default True
            Whether to drop the original IntervalIndex
        """

        freq = pd.Timedelta(freq)

        value_options = ["shrink", "grow", "nearest"]
        left = ip.case_correct(left, value_options)
        right = ip.case_correct(right, value_options)

        if left == "shrink":
            new_left = self._obj.name.left.ceil(freq)
        elif left == "grow":
            new_left = self._obj.name.left.floor(freq)
        elif left == "nearest":
            new_left = self._obj.name.left.round(freq)
        else:
            raise ValueError(left)

        if right == "shrink":
            new_right = self._obj.name.right.floor(freq)
        elif right == "grow":
            new_right = self._obj.name.right.ceil(freq)
        elif right == "nearest":
            new_right = self._obj.name.right.round(freq)
        else:
            raise ValueError(right)

        return self._set_interval(left=new_left, right=new_right, closed=self._obj.name.closed, keep_as=None)

    def calculate(self, tag, operation, name):
        """Perform an aggregation operation on a tag for the dataframe intervals

        Parameters
        ----------
        tag : Tag
            The tag on which the operation happens
        operation : str
            mean, min, max, range, start, end, delta, integral, or stdev
        name : str
            Name under which the calculation result needs to be stored in the DataFrame.

        Returns
        -------
        pandas.DataFrame
        """
        intervals = pd.IntervalIndex([self._obj.name])
        values = calculate(intervals=intervals, tag=tag, operation=operation, name=name)

        ser = self._obj.copy()
        ser[name] = values.iloc[0]
        return ser

    def sample(self, duration, n=1, overlap=False, freq=pd.Timedelta(minutes=1), drop=True, name="samples"):
        """Sample random sub-intervals from a given list of intervals

        Parameters
        ----------
        duration : pandas.Timedelta
            Duration of the sample intervals
        n : int, default 1
            Number of intervals to return
        overlap : bool, default False
            Whether the returned sample intervals can overlap
        freq : pandas.Timedelta, default 1m
            The resolution to which all inputs and outputs will be rounded. Defaults to client index resolution.
        drop : bool, default True
            Whether to drop the original IntervalIndex in the returned DataFrame
        name : str, default 'samples'
            Name of the new IntervalIndex column of samples

        Returns
        -------
        samples : pandas.DataFrame
            DataFrame with sampled intervals as index

        Notes
        -----
        Intervals will be rounded down to the given freq before sampling.

        The sampling method first determines how many sample should be taken per interval, and then iteratively
        samples that number of sub-intervals from each interval. The number of samples per interval are distributed
        randomly proportional to the number of possible sample positions within an interval. An interval can be sampled
        in (interval length - duration)/freq + 1 possible ways. For example, there is only 1 way to take a 1h sample out
        of a 1h interval, while for a freq of 1m there are 60 ways of taking a 1h sample out of a 2h interval.
        """
        # FIXME
        freq = pd.Timedelta(freq)
        duration = pd.Timedelta(duration)

        df = self.round(freq=freq, left="shrink", right="shrink")

        # Determine how many samples to draw from each interval
        if overlap:
            weights = np.clip(
                (df.index.length - duration)/freq + 1,
                a_min=0, a_max=None,
            )

            sample_count = (
                pd.Series(
                    data=1,
                    index=pd.IntervalIndex(random.choices(df.index, weights=weights, k=n))
                )
                .groupby(level=0).sum()
                .reindex(df.index, fill_value=0)
            )

        else:
            # Initialize sample count dataframe
            sample_count = pd.Series(
                index=df.index,
                data=0,
            )

            # Iteratively distribute n samples across intervals
            for i in range(0, n):

                # The weight for being sampled is proportional to the duration that would be left to take a sample
                weights = np.clip(
                    (df.index.length - (1+sample_count)*duration)/freq + 1,
                    a_min=0, a_max=None,
                )
                if weights.sum() == 0:
                    raise ValueError(f"Cannot generate {n} non-overlapping '{duration}' samples from given intervals")
                sample_count[random.choices(sample_count.index, weights=weights)] += 1

        # required step to keep original (rather than rounded) index when drop=False
        # df has the rounded IntervalIndex, while self._obj has the original
        if drop:
            df_iter = df
        else:
            df_iter = self._obj.reset_index(drop=False)

        k = 0
        samples_list = []
        for i, row in df_iter.iterrows():
            interval = i if drop else df.index[i]  # always take rounded interval here
            samples = pd.DataFrame(
                index=sample(
                    interval=interval,
                    duration=duration,
                    n=sample_count.iloc[k],
                    overlap=overlap,
                    freq=freq,
                    name=name,
                ),
                columns=row.index,
            )
            samples[:] = row.values
            if not len(samples) == 0:
                samples_list.append(samples)
            k+=1

        return pd.concat(samples_list)
