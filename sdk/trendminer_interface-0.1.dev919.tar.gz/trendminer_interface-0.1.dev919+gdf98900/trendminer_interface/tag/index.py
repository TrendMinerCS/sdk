from trendminer_interface import _input as ip

from trendminer_interface.base import RetrievableBase, FactoryBase, LazyLoadingMixin, LazyAttribute, AsTimestamp
from trendminer_interface.authentication.response_hooks import ignore_404
from trendminer_interface.constants import INDEX_STATUS_OPTIONS, MAX_GET_SIZE


class IndexStatus(RetrievableBase, LazyLoadingMixin):
    """Index status for a particular tag

    The index for a tag can be considered a cache of the time series data of that tag. Once the data for a tag has been
    retrieved and cached on the appliance, it is automatically kept up-to-date from the tag datasource.

    Can only be retrieved and deleted, but not edited.

    Attributes
    ----------
    tag : Tag
        Tag for which the instance gives the index status
    status : str
        "OK", "FAILED", "INCOMPLETE", "IN_PROGRESS", "OUT_OF_DATE", "STALE", or "NOT_INDEXED"

        Information on what index states mean can be found here:
        https://documentation.trendminer.com/en/63122-index-manager-screen.html

        NOT_INDEXED is an artificial state, it does not exist on the appliance. It simply signifies the absence of index
        data on the appliance.
    progress : float
        Tag historic indexing progress percentage
    last_update : pandas.Timestamp
        Timestamp the index data was last updated

    """
    endpoint = '/compute/index/'
    last_update = AsTimestamp()

    # TODO: last_update seems to be going unused
    def __init__(self, tag, status, progress, last_update):
        RetrievableBase.__init__(self, client=tag.client, identifier=tag.identifier)

        self.tag = tag
        self.status = status
        self.progress = progress

    def __call__(self):
        """Sends an index request for the current tag

        If the tag was already indexed, or in the process of indexing, this request will only update the index with the
        new data available in the datasource. If no historic index data was yet present, this request will also start
        the backward indexing to retrieve the historic data.
        """
        self.client.session.post(self.link)

    def _full_instance(self):
        return IndexStatusFactory(client=self.client).from_identifier(self.tag.identifier)

    def refresh(self):
        """Refreshes the index for the current tag
        """
        self.client.session.post(self.link + "/refresh")

    def delete(self):
        """Removes the index data for the current tag
        """
        self.client.session.delete(self.link)

    def _json(self):
        return {"id": self.identifier}

    def __repr__(self):
        return f"<< IndexStatus | {self._repr_lazy('status')} | {self._repr_lazy('progress')} >>"


class IndexStatusFactory(FactoryBase):
    """Implements methods for retrieval of tag index statusses

    ``client.tag.index`` returns a IndexStatusFactory instance
     """
    tm_class = IndexStatus

    def from_identifier(self, ref):
        """Retrieve index status from its uuid

        The index status uuid is equal to the tag uuid.

        Parameters
        ----------
        ref : str
            Tag uuid
        """
        response = self.client.session.get(f"compute/index/{ref}", hooks={"response": [ignore_404]})
        if response.status_code == 404:
            return self.not_indexed(identifier=ref)
        return self._from_json(response.json())

    def not_indexed(self, identifier):
        """Returns a 'not indexed' status

        This is a placeholder status. This status does not actually exist on the server. It is the absence of an index
        status for a given tag on the appliance that tells us a tag is not indexed.

        Parameters
        ----------
        identifier : str
            uuid of the tag which is not indexed

        Returns
        -------
        IndexStatus
            'NOT INDEXED' status for tag with the given identifier
        """
        from .tag import TagFactory
        return self.tm_class(
            tag=TagFactory(client=self.client)._from_json_identifier_only(identifier),
            status="NOT_INDEXED",
            progress=0,
            last_update=None,
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        IndexStatus
        """
        from .tag import TagFactory
        return self.tm_class(
            tag=TagFactory(client=self.client)._from_json_index_status(data),
            status=data["status"],
            progress=data["indexingProgress"],
            last_update=data["lastUpdatedDate"],
        )

    def from_tag(self, tag):
        """Returns the index status for a given tag

        Parameters
        ----------
        tag : Tag or str
            A (reference to the) tag for which we want to retrieve the index status

        Returns
        -------
        IndexStatus
            Index status for the given tag
        """
        return self.tm_class(
            tag=tag,
            status=LazyAttribute(),
            progress=LazyAttribute(),
            last_update=LazyAttribute(),
        )

    def search(self, name=None, status=None):
        """Search index statuses

        Parameters
        ----------
        name : str, optional
            Tag name search query
        status : {"OK", "FAILED", "INCOMPLETE", "IN_PROGRESS", "OUT_OF_DATE", "STALE"}, optional
            Search only for tags matching the specific status

        Returns
        -------
        list of IndexStatus
            Index statuses matching the search criteria

        Notes
        -----
        If no name or status is given, all tag indexes are returned.
        """
        params = {
            "sort": "name,asc",
            "size": MAX_GET_SIZE,
        }

        filters = []
        if name is not None:
            filters.append(f"name=='{name}'")
        if status is not None:
            filters.append(f"status=='{ip.correct_value(status, INDEX_STATUS_OPTIONS)}'")

        if filters:
            params.update({"query": ";".join(filters)})

        content = self.client.session.paginated(keys=["content"]).get("/compute/index/", params=params)

        return [self._from_json(data) for data in content]

    def from_name(self, ref):
        """Retrieve index status from tag name

        Parameters
        ----------
        ref : str
            Name of the tag for which the retrieve the index status. Does not need to be case-sensitive.

        Returns
        -------
        IndexStatus
            Index status of the given tag
        """
        return ip.object_match_nocase(self.search(name=ref), "name", ref)

    @property
    def _get_methods(self):
        return self.from_tag, self.from_identifier, self.from_name
