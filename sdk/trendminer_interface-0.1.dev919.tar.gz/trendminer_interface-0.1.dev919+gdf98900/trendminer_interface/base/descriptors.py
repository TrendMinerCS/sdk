import pandas as pd
from trendminer_interface.base import LazyAttribute
from trendminer_interface import _input as ip
from .color import to_color


class ByFactory:
    """Descriptor for converting class attributes into defined classes

    Attributes
    ----------
    factory_class : type
        The class which holds the conversion method
    method : str, default "get"
        The class method (as a string) that needs to be invoked for conversion
    """
    def __init__(self, factory_class, method="_get"):
        self.factory_class = factory_class
        self.method = method

    def __set_name__(self, owner, name):
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    def __set__(self, instance, value):
        factory = self.factory_class(client=instance.client)
        setattr(
            instance,
            self.private_name,
            getattr(factory, self.method)(value)
        )


class HasOptions:
    """Descriptor for when a class attribute needs to be on of fixed set of options

    Case corrects inputs.

    Attributes
    ----------
    options : list or dict
        list of options, or dict with accepted keys, and the final values they map to.
    """
    def __init__(self, options):
        self.options = options

    def __set_name__(self, owner, name):
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    def __set__(self, instance, value):
        setattr(
            instance,
            self.private_name,
            ip.correct_value(value, self.options)
        )


class AsColor:
    """Descriptor for setting an attribute as color

    Attributes
    ----------
    choose : bool
        Whether a color needs to be chosen instead if the attribute is set to None
    """
    def __init__(self, choose=False):
        self.choose = choose

    def __set_name__(self, owner, name):
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    def __set__(self, instance, value):
        setattr(
            instance,
            self.private_name,
            to_color(value, choose=self.choose)
    )


class AsTimestamp:
    """Descriptor for setting an attribute as pandas Timestamp"""

    def __set_name__(self, owner, name):
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    def __set__(self, instance, value):
        if not isinstance(value, LazyAttribute):
            value = pd.Timestamp(value)
            if not value.tz:
                value = value.tz_localize(instance.client.tz)
            else:
                value = value.tz_convert(instance.client.tz)
        setattr(instance, self.private_name, value)


class AsTimedelta:
    """Descriptor for setting an attribute as pandas Timestamp"""

    def __set_name__(self, owner, name):
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    def __set__(self, instance, value):
        if not isinstance(value, LazyAttribute):
            value = pd.Timedelta(value)
        setattr(instance, self.private_name, value)
