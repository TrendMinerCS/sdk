import posixpath
import pandas as pd

import trendminer_interface._input as ip

from trendminer_interface.component_factory import ComponentMultiFactory
from trendminer_interface.base import EditableBase, FactoryBase, ByFactory, AsTimestamp
from trendminer_interface.user import UserFactory
from trendminer_interface.constants import MAX_GET_SIZE
from trendminer_interface.times import IntervalFactory

from .type import ContextTypeFactory
from .field import ContextField
from .event import EventFactory
from .attachment import AttachmentFactory


# TODO: implement getting attachments

# TODO: remove
class ContextItem(EditableBase):
    """Context item containing contextual information

    Attributes
    ----------
    created_by : User or
        User that created the context item on the appliance
    context_type : ContextType
        Context type of the context item
    sync_time : datetime.datetime
        Time the context item Python object was loaded from the TrendMiner appliance
    last_modified : datetime.datetime
        Time the context item was last modified
    components : list
        Components (tags, assets, attributes) to which the context item is attached. Though through the UX, a context
        item can only be attached to a single component, multiple components can be provided via API. Adding more than
        a single component is not recommended.
    description : str
        Context item description
    identifier : str
        Context item uuid
    key : str
        Context item unique short-key
    search_fields : dict
        Metadata from when the context item was created from a monitor. Contains the keys 'tm_monitor_id',
        'tm_search_id' and 'tm_search_type'.
    """
    endpoint = "context/item/"

    created_by = ByFactory(UserFactory)
    context_type = ByFactory(ContextTypeFactory)
    components = ByFactory(ComponentMultiFactory, "_list")
    sync_time = AsTimestamp()
    last_modified = AsTimestamp()

    def __init__(self, client, identifier, key, context_type, components, events, fields, keywords, description,
                 created_by, search_fields, sync_time, last_modified):
        super().__init__(client=client, identifier=identifier)
        self.sync_time = sync_time
        self.last_modified = last_modified
        self.context_type = context_type
        self.components = components
        self.events = events
        self.fields = fields
        self.keywords = keywords
        self.description = description or ""
        self.identifier = identifier
        self.key = key
        self.created_by = created_by
        self.search_fields = search_fields or {}

    @property
    def events(self):
        """Contex item events

        Input for setting context item events can also be a list of datetimes, or an Interval instance.

        Returns
        -------
        events: list of ContextEvent
            Context item events corresponding to the context type workflow
        """
        return self._events

    @events.setter
    def events(self, events):
        # Setting events requires knowledge of the workflow
        self._events = EventFactory(client=self.client, workflow=self.context_type.workflow)._list(events)

    @property
    def fields(self):
        """Context item data fields

        Returns
        -------
        fields : dict
            Field data. Dictionary keys are the keys of the corresponding context field, not ContextField instances.
            Data can be str or float, depending on the context field type. Other keys (not corresponding to the fields
            associated with the context type) can be added too, which will show up as 'other properties' in the UX.
        """
        return self._fields

    @fields.setter
    def fields(self, fields):
        fields = fields or {}
        fields = {field.key if isinstance(field, ContextField) else field: value for field, value in fields.items()}
        self._fields = fields

    @property
    def keywords(self):
        """Keywords attached to the item

        Keywords in TrendMiner are always lowercase.

        Returns
        -------
        keywords : list of str
            List of keywords attached to the context item
        """
        return self._keywords

    @keywords.setter
    def keywords(self, keywords):
        self._keywords = [kw.lower() for kw in ip.any_list(keywords)]

    @property
    def interval(self):
        """Time interval covered by the context item

        The interval is determined by the start and end event. If the end event has not occurred yet, the end of the
        interval will be the current time. If there is no workflow associated with the context type, the context item
        only has a single timestamp, so the length of the returned interval is 0.

        Returns
        -------
        interval : Interval
            The time interval covered by the context item
        """
        if not self.events:
            return None

        start_event = self.events[0]
        end_event = self.events[-1]

        if self.context_type.workflow is not None:
            is_open = end_event.state != self.context_type.workflow.states[-1]
        else:
            is_open = False

        if is_open:
            end_time = self.sync_time or self.client.now()
        else:
            end_time = end_event.timestamp

        return IntervalFactory(client=self.client)(start_event.timestamp, end_time, data=self.fields, is_open=is_open)

    def _json(self):
        # ignore None values as they throw errors
        fields = {
            **self.search_fields,
            **{key: value for key, value in self.fields.items() if value is not None}
        }
        return {
            "identifier": self.identifier,
            "description": self.description,
            "keywords": self.keywords,
            "type": self.context_type._json(),
            "components": [component._json_component() for component in self.components],
            "fields": fields,
            "events": [event._json() for event in self.events],
        }

    def _post_updates(self, response):
        super()._post_updates(response)
        self.key = response.json()["shortKey"]
        self.created_by = UserFactory(client=self.client)._from_json_limited(response.json()["userDetails"])
        self.events = [
            EventFactory(client=self.client, workflow=self.context_type.workflow)._from_json(event)
            for event in response.json()["events"]
        ]

    def _put_updates(self, response):
        super()._put_updates(response)
        self._sync_time = self.client.now()
        self.last_modified = response.json()["lastModifiedDate"]

    def approve(self):
        """Add user approval to this context item"""
        self.client.session.post(f"/context/data/{self.identifier}/approval")

    def remove_approval(self):
        """Remove user approval from this context item"""
        self.client.session.delete(f"/context/data/{self.identifier}/approval")

    def history(self):
        """Return context item history

        Keeping history must be configured for the context type.

        Returns
        -------
        dict
            Context item history
        """
        params = {"size": MAX_GET_SIZE, "sort": "desc"}
        response = self.client.session.get(f"/context/history/{self.identifier}", params=params)
        return response.json()

    @property
    def attachments(self):
        """Context item attachment factory"""
        return AttachmentFactory(parent=self)

    def __repr__(self):
        if self.interval is not None:
            return (
                f"<< ContextItem | {self.context_type.key} | {self.interval.duration} >>"
            )
        return f"<< ContextItem | {self.context_type.key} >>"


class ContextItemFactory(FactoryBase):
    """Factory for creating and retrieving context items"""
    tm_class = pd.Series

    def __call__(self, context_type, components, events=None, description="", fields=None, keywords=None):
        """Instantiate a new pandas.Series instance representing a single context item

        Parameters
        ----------
        context_type : ContextType or str
            Type associated with the new context item
        components : list
            Components (tags, assets, attributes) to which the context item needs to be attached. Though through the UX,
            a context item can only be attached to a single component, multiple components can be provided via API.
            Adding more than a single component is not recommended.
        events : list or Interval, optional
            List of events corresponding to the context item. These can be ContextEvent or datetime. An interval can
            also be given as input, taking the interval start and end as the start and end events. Though the events
            need to be defined before context item creation on the appliance, this parameter can be left initially,
            allowing a context item 'template' to be initialized. This template can then be used to create many items
            (e.g. by filling in the `events` attribute in a loop).
        description : str, default ""
            Context item description
        fields : dict, optional
            Context item data fields.
        keywords : list, optional
            Keywords attached to the context item
        """
        pass # FIXME

    def from_identifier(self, ref):
        """Retrieve a single context item by its identifier

        Parameters
        ----------
        ref : str
            Context item UUID or shortKey

        Returns
        -------
        pandas.Series
        """
        response = self.client.session.get(f"/context/item/{ref}")
        return self._from_json(response.json())

    def _from_json(self, data):
        """Json to context item Series

        Parameters
        ----------
        data : dict
            response json

        Returns
        -------
        pandas.Series
        """

        interval = pd.Interval(
            left=pd.Timestamp(data["startEventDate"]).tz_convert(self.client.tz),
            right=pd.Timestamp(data.get("endEventDate", pd.Timestamp.now(tz=self.client.tz))).tz_convert(self.client.tz),
            closed="both",
        )

        # Metadata
        context_type = ContextTypeFactory(client=self.client)._from_json(data["type"])

        component = (
            ComponentMultiFactory(client=self.client)._from_json_context_item(data["components"][0])
            if data["components"] else None
        )

        created_by = (
            UserFactory(client=self.client)._from_json_limited(data["userDetails"])
            if "userDetails" in data else None
        )

        metadata = {
            "key": data["shortKey"],
            "identifier": data["identifier"],
            "identifier_external": data.get("externalId"),
            "description": data.get("description"),
            "type": context_type,
            "component": component,
            "created_by": created_by,
            "created": pd.Timestamp(data["createdDate"]).tz_convert(self.client.tz),
            "last_modified": pd.Timestamp(data["lastModifiedDate"]).tz_convert(self.client.tz),
        }

        ser_base = pd.Series(name=interval, data=metadata)

        # Event data
        event_dict = {}
        for event in data["events"][1:-1]: # ignore start and end state, this info is in the IntervalIndex
            original_state = event["state"]
            state = original_state
            i = 0
            while state in event_dict:
                i+=1
                state = f"{original_state}_{i}"
            event_dict[state] = pd.Timestamp(event["occurred"], tz=self.client.tz)

        ser_events = pd.Series(name=interval, data=event_dict)

        # Keyword data
        keyword_dict = {keyword: True for keyword in data["keywords"]}
        ser_keywords = pd.Series(name=interval, data=keyword_dict)

        # Field data
        ser_fields = pd.Series(name=interval,data=data["fields"])

        return pd.concat([ser_base, ser_events, ser_keywords, ser_fields])

    @property
    def _get_methods(self):
        return self.from_identifier,
