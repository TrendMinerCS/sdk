from trendminer_interface.base import FactoryBase
from .access import Member


class ClientUserClient:
    @property
    def client(self):
        return ClientUserFactory(client=self)


class ClientUser(Member):
    endpoint = "/confighub/clients"
    member_type = "CLIENT"

    def __init__(self, client, identifier):
        super().__init__(client=client, identifier=identifier, name=identifier)

    @property
    def path(self):
        return self.identifier

    def _post_updates(self, response):
        self.identifier = response.json()["id"]

    def _put_updates(self, response):
        self._post_updates(response)

    def _json(self, password=None):
        return {
            "id": self.name,
        }

    def _full_instance(self):
        return ClientUserFactory(client=self.client).from_identifier(self.identifier)

    def get_secret(self):  # pragma: no cover
        """Retrieve client secret

        Returns
        -------
        str
            Secret matching the client; used to authenticate to the server.
        """
        r = self.client.session.get(f"{self.endpoint}/{self.identifier}/secret")
        return r.json()["secret"]

    def __repr__(self):
        return f"<< {self.__class__.__name__} | {self.identifier} >>"


class ClientUserFactory(FactoryBase):
    tm_class = ClientUser

    def __call__(self, name):
        return self.tm_class(
            client=self.client,
            identifier=name,
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        ClientUser
        """
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
        )

    def _from_json_member_acl(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["name"],
        )

    @property
    def _get_methods(self):
        return self.from_identifier,
