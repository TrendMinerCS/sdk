from .datasource import DatasourceACLFactory
from .timeseries_builder import TimeseriesBuilderACLFactory


class AccessClient:
    @property
    def access(self):
        return DatasourceACLFactory(client=self)

    @property
    def access_builder(self):
        return TimeseriesBuilderACLFactory(client=self)