from trendminer_interface.asset import Attribute
from trendminer_interface.tag import Tag


def resolve_chart_aliases(
    chart_aliases: dict[str, str],
    entries: list[Tag | Attribute],
) -> dict[Tag | Attribute, str]:
    """Resolve a chart alias dict with string ID keys to one with Tag/Attribute keys

    Chart alias dicts returned by TrendMiner only map an identifier to an alias string, without providing any
    information about whether an entry identifier corresponds to a Tag or an Attribute. Luckily, we know the aliased
    entries must be returned as full objects elsewhere in the object where they are aliased. This function provides a
    simple mapping by picking the correct Tag/Attribute based on the identifier.

    Parameters
    ----------
    chart_aliases : dict[str, str]
        Chart alias mapping with string ID keys, which refer to either a Tag or an Attribute. The values are the alias
        strings.
    entries : list[Union[Tag, Attribute]]
        List of Tag and Attribute objects that could potentially have been aliased in the parent object (e.g., all the
        tags and attributes in a TrendHub view).

    Notes
    -----
    Rather than raising a KeyError, this function ignores any entries in `chart_aliases` that do not have a
    corresponding object in `entries`. This accounts for the edge case where an aliased Tag or Attribute has been
    deleted, but the alias mapping has remained.

    """
    entry_map = {entry.identifier: entry for entry in entries}
    return {
        entry_map[entry_id]: alias
        for entry_id, alias in chart_aliases.items()
        if entry_id in entry_map
    }
