import trendminer_interface._input as ip

from .base import DescriptorBase


class HasOptions(DescriptorBase):
    """Descriptor for when a class attribute needs to be on of fixed set of options

    Case corrects inputs.

    Attributes
    ----------
    options : list or dict
        list of options, or dict with accepted keys, and the final values they map to.
    """

    def __init__(self, options):
        self.options = options

    def __set__(self, instance, value):
        setattr(instance, self.private_name, ip.correct_value(value, self.options))
