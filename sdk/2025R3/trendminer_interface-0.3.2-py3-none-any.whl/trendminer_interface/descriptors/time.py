import pandas as pd

from trendminer_interface import _input as ip
from trendminer_interface.base import LazyAttribute

from .base import DescriptorBase


class AsTimestamp(DescriptorBase):
    """Descriptor for setting an attribute as pandas Timestamp"""

    def __set__(self, instance, value):
        setattr(
            instance,
            self.private_name,
            ip.to_local_timestamp(ts=value, tz=instance.client.tz),
        )


class AsTimedelta(DescriptorBase):
    """Descriptor for setting an attribute as pandas Timestamp"""

    def __set__(self, instance, value):
        if not isinstance(value, LazyAttribute):
            value = pd.Timedelta(value)
        setattr(instance, self.private_name, value)
