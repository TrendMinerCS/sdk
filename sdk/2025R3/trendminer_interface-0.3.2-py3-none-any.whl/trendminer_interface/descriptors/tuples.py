from typing import TypeVar

from .base import DescriptorBase

T = TypeVar("T")


# TODO: implement base class with __iter__ for tuple-like types
class FromTuple(DescriptorBase):
    def __init__(self, cls: type[T]):
        self._cls = cls

    def __set__(self, instance, value: T | tuple):
        if isinstance(value, self._cls):
            setattr(instance, self.private_name, value)
        else:
            setattr(instance, self.private_name, self._cls(*value))


class FromTupleList(DescriptorBase):
    def __init__(self, cls: type[T]):
        self._cls = cls

    def __set__(self, instance, value: list[T] | list[tuple]):
        if all(isinstance(v, self._cls) for v in value):
            setattr(instance, self.private_name, value)
        else:
            setattr(instance, self.private_name, [self._cls(*t) for t in value])
