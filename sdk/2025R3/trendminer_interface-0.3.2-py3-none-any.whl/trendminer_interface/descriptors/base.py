import abc


class DescriptorBase(abc.ABC):
    """Base class for all descriptors

    Implements setting a private name and getting the value.
    """

    def __set_name__(self, owner, name):
        self.private_name = "_" + name

    def __get__(self, instance, owner):
        return getattr(instance, self.private_name)

    @abc.abstractmethod
    def __set__(self, instance, value):
        pass
