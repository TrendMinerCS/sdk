import pandas as pd

from trendminer_interface.base import FactoryBase
from trendminer_interface.context.filter.base.filter import ContextFilterBase
from trendminer_interface.descriptors import HasOptions


class IntervalFilter(ContextFilterBase):
    """Filter on context item event or creation time through fixed interval

    Attributes
    ----------
    interval : pandas.Interval
        The time interval on which to filter
    interval_type : str
        The type of interval filter:
        - "EVENT" will filter on context item interval overlapping the given filter interval
        - "CREATED_DATE" will filter on the context item creation date falling in the filter interval

    Notes
    -----
    The interval closed attribute is not taken into account. TrendMiner will return context item as if the given
    interval closed attribute was "both".
    """

    filter_type = "INTERVAL_FILTER"
    interval_type = HasOptions(["EVENT", "CREATED_DATE"])

    def __init__(self, client, interval, interval_type):
        super().__init__(client=client)
        self.interval = interval
        self.interval_type = interval_type

    def _json(self):
        data = {
            "startDate": self.interval.left.isoformat(timespec="milliseconds"),
            "endDate": self.interval.right.isoformat(timespec="milliseconds"),
            "type": self.filter_type,
            "intervalType": self.interval_type,
        }

        return data


class IntervalFilterFactory(FactoryBase):
    """Factory for creating context interval filter"""

    tm_class = IntervalFilter

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        IntervalFilter
        """
        return self.tm_class(
            client=self.client,
            interval=pd.Interval(
                left=pd.Timestamp(data["startDate"]).tz_convert(self.client.tz),
                right=pd.Timestamp(data["endDate"]).tz_convert(self.client.tz),
                closed="both",
            ),
            interval_type=data["intervalType"],
        )

    def __call__(self, interval, interval_type="EVENT"):
        """Create new filter on context item interval

        Parameters
        ----------
        interval : pandas.Interval
            Interval on which to filter
        interval_type : str, default "EVENT"
            The type of interval filter:
            - "EVENT" will filter on context item interval overlapping the given filter interval
            - "CREATED_DATE" will filter on the context item creation date falling in the filter interval

        Returns
        -------
        IntervalFilter
            Interval filter on context item event or creation time
        """
        return self.tm_class(
            client=self.client,
            interval=interval,
            interval_type=interval_type,
        )
