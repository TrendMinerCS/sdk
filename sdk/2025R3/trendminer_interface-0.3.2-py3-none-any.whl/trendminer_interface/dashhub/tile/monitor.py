from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import FromTuple, HasOptions
from trendminer_interface.monitor import Monitor, MonitorFactory

from .base import (
    DraftTileFactoryBase,
    TileBase,
    TileConfigurationBase,
    TileFactoryBase,
    TilePosition,
    TupleLike,
)

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class MonitorTileConfiguration(TileConfigurationBase):
    def __init__(self, show_title: bool, fill_background: bool):
        self.show_title = show_title
        self.fill_background = fill_background

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
            "fillBackground": self.fill_background,
        }

    @classmethod
    def _from_json(cls, data: dict) -> MonitorTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
            fill_background=data.get("fillBackground", False),
        )


class DraftMonitorTile(TileBase[MonitorTileConfiguration]):
    """A monitor tile without a monitor assigned

    This tile cannot be instantiated using the SDK, but it is possibly returned from a saved dashboard.
    """

    visualization_type = "DRAFT_ALERT"
    _config_type = MonitorTileConfiguration

    def _json_content(self) -> dict:
        return {}


class MonitorTileCondition(TupleLike):
    """Condition for monitor tile state

    Attributes
    ----------
    icon : str
        Icon displayed for the condition. Options:
        "snowflake", "flame", "bucket", "ruler", "flask", "information", "waterdrops", "flow--line", "waves",
        "circle-success", "person", "arrows--round", "cracked", "wheelbarrow", "alert--circle", "clipboard", "wrench",
        "warning", "trending--down", "spoon", "wrench", "file--check"
    text : str
        Text displayed for the condition
    color : str
        Color for the condition (e.g., "#FF0010")
    """

    _fields = ("icon", "text", "color")

    icon: str = HasOptions(
        [
            "snowflake",
            "flame",
            "bucket",
            "ruler",
            "flask",
            "information",
            "waterdrops",
            "flow--line",
            "waves",
            "circle-success",
            "person",
            "arrows--round",
            "cracked",
            "wheelbarrow",
            "alert--circle",
            "clipboard",
            "wrench",
            "warning",
            "trending--down",
            "spoon",
            "wrench",
            "file--check",
        ]
    )

    def __init__(self, icon: str, text: str, color: str):
        self.icon = icon
        self.text = text
        self.color = color

    def _json(self) -> dict:
        return {
            "icon": self.icon,
            "color": self.color,
            "definition": self.text,
        }

    @classmethod
    def _from_json(cls, data: dict) -> MonitorTileCondition:
        return cls(
            icon=data["icon"],
            color=data["color"],
            text=data["definition"],
        )


class MonitorTile(TileBase[MonitorTileConfiguration]):
    """Monitor dashboard tile

    Attributes
    ----------
    monitor : Monitor
        The monitor to display in the tile
    active : MonitorTileCondition
        Condition to display when the monitor is active (triggered)
    inactive : MonitorTileCondition
        Condition to display when the monitor is inactive (not triggered)
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "ALERT"
    _config_type = MonitorTileConfiguration
    active: MonitorTileCondition = FromTuple(MonitorTileCondition)
    inactive: MonitorTileCondition = FromTuple(MonitorTileCondition)

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        monitor: Monitor,
        active: MonitorTileCondition | tuple[str, str, str],
        inactive: MonitorTileCondition | tuple[str, str, str],
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: MonitorTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )
        self.monitor = monitor
        self.active = active
        self.inactive = inactive

    def _json_content(self) -> dict:
        return {
            "monitorId": int(self.monitor.identifier),
            "stateDefinitions": {
                "TRIGGERED": self.active._json(),
                "NOT_TRIGGERED": self.inactive._json(),
            },
        }


class MonitorTileFactory(TileFactoryBase[MonitorTile, MonitorTileConfiguration]):
    """Factory for creating and retrieving monitor tiles"""

    tm_class = MonitorTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        monitor: Monitor,
        active: MonitorTileCondition | tuple[str, str, str] = (
            "alert--circle",
            "",
            "#FF0010",
        ),
        inactive: MonitorTileCondition | tuple[str, str, str] = (
            "circle-success",
            "",
            "#2BCE48",
        ),
        title: str = "",
        refresh_rate: pd.Timedelta | str = "1m",
        config: MonitorTileConfiguration | None = None,
    ) -> MonitorTile:
        """Instantiate a new monitor tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        monitor : Monitor
            Monitor to display in the tile
        active : MonitorTileCondition or tuple[str, str, str], optional
            Condition to display when the monitor is active (icon, text, color),
            by default ("alert--circle", "", "#FF0010")
        inactive : MonitorTileCondition or tuple[str, str, str], optional
            Condition to display when the monitor is inactive (icon, text, color),
            by default ("circle-success", "", "#2BCE48")
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "1m"
        config : MonitorTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        MonitorTile
        """

        return self.tm_class(
            client=self.client,
            position=position,
            monitor=monitor,
            active=active,
            inactive=inactive,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> MonitorTile:
        """Response json to instance

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        MonitorTile
        """
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            monitor=MonitorFactory(self.client)._from_json_identifier_only(
                data["configuration"]["monitorId"]
            ),
            active=MonitorTileCondition._from_json(
                data["configuration"]["stateDefinitions"]["TRIGGERED"]
            ),
            inactive=MonitorTileCondition._from_json(
                data["configuration"]["stateDefinitions"]["NOT_TRIGGERED"]
            ),
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=MonitorTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(
        show_title: bool = True, fill_background: bool = False
    ) -> MonitorTileConfiguration:
        """Default configuration for monitor tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True
        fill_background : bool, optional
            Whether to fill the tile background with color based on the monitor state, by default False

        Returns
        -------
        MonitorTileConfiguration
        """
        return MonitorTileConfiguration(
            show_title=show_title,
            fill_background=fill_background,
        )


class DraftMonitorTileFactory(
    DraftTileFactoryBase[DraftMonitorTile, MonitorTileConfiguration]
):
    """Factory for creating draft monitor tiles"""

    tm_class = DraftMonitorTile
