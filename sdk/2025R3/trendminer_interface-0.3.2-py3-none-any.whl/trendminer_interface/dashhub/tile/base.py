from __future__ import annotations

import abc
from typing import TYPE_CHECKING, Generic, TypeVar

import pandas as pd

from trendminer_interface.base import FactoryBase, SerializableBase, TupleLike
from trendminer_interface.descriptors import AsTimedelta, FromTuple

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class TilePosition(TupleLike):
    """Tile position and size in dashboard grid

    Attributes
    ----------
    x : int
        Horizontal position of the tile. Leftmost column is 0.
    y : int
        Vertical position of the tile. Top row is 0.
    width : int
        Number of columns taken up by the tile.
    height : int
        Number of rows taken up by the tile.
    """

    _fields = ("x", "y", "width", "height")

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def _json(self) -> dict:
        return {
            "x": self.x,
            "y": self.y,
            "cols": self.width,
            "rows": self.height,
        }

    @classmethod
    def _from_json(cls, data: dict) -> TilePosition:
        return cls(
            x=data["x"],
            y=data["y"],
            width=data["cols"],
            height=data["rows"],
        )


class TileConfigurationBase(abc.ABC):
    """Base class for tile configuration"""

    @abc.abstractmethod
    def _json(self) -> dict:
        pass

    @classmethod
    @abc.abstractmethod
    def _from_json(cls, data: dict):
        pass

    def __repr__(self):
        return f"<< {self.__class__.__name__} >>"


TConfig = TypeVar("TConfig", bound=TileConfigurationBase)


class TileBase(SerializableBase, abc.ABC, Generic[TConfig]):
    """DashHub Tile base class

    Attributes
    ----------
    title : str
        Tile title
    refresh_rate : pandas.Timedelta
        How often the tile is refreshed if the dashboard is live.
    config : Any
        Tile configuration specific to the tile type
    """

    position: TilePosition = FromTuple(TilePosition)
    visualization_type: str
    refresh_rate = AsTimedelta()
    _config_type: type[TConfig]

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition | tuple[int, int, int, int],
        title: str,
        refresh_rate: pd.Timedelta | str | None,
        config: TConfig,
    ):
        super().__init__(client=client)
        self.position = position
        self.title = title
        self.refresh_rate = refresh_rate
        self.config = config

    @abc.abstractmethod
    def _json_content(self) -> dict:
        pass

    def _json(self) -> dict:
        return {
            # text tile does not have refresh rate
            "refreshRate": int(self.refresh_rate.total_seconds())
            if self.refresh_rate is not None
            else None,
            "title": self.title,
            "visualizationType": self.visualization_type,
            "configuration": {
                **self.config._json(),
                **self._json_content(),
            },
            **self.position._json(),
        }


T = TypeVar("T", bound=TileBase)


class TileFactoryBase(FactoryBase, abc.ABC, Generic[T, TConfig]):
    """Base class for DashHub tile factories"""

    tm_class: type[T]

    @abc.abstractmethod
    def __call__(self, *args, **kwargs) -> T:
        pass

    @abc.abstractmethod
    def _from_json(self, data: dict) -> T:
        pass

    @staticmethod
    @abc.abstractmethod
    def config(*args, **kwargs) -> TConfig:
        """Tile configuration. Configuration type depends on the tile type."""
        pass


class DraftTileFactoryBase(TileFactoryBase[T, TConfig], abc.ABC):
    """Base class for DashHub draft tile factories"""

    def __call__(self, *args, **kwargs) -> T:
        raise NotImplementedError(
            "Direct instantiation of draft tiles is not supported"
        )

    def config(*args, **kwargs) -> TConfig:
        raise NotImplementedError(
            "Accessing configuration of tiles through draft tile factories is not supported"
        )

    def _from_json(self, data: dict) -> T:
        # Draft tiles only have base attributes and a configuration
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            title=data["title"],
            config=self.tm_class._config_type._from_json(data["configuration"]),
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
        )
