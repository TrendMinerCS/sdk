from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import ByFactory
from trendminer_interface.notebook import Pipeline, PipelineFactory

from .base import TileBase, TileConfigurationBase, TileFactoryBase, TilePosition

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class NotebookTileConfiguration(TileConfigurationBase):
    """Configuration for external content dashboard tile"""

    def __init__(self, show_title: bool):
        self.show_title = show_title

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
        }

    @classmethod
    def _from_json(cls, data: dict) -> NotebookTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
        )


class NotebookTile(TileBase[NotebookTileConfiguration]):
    """Notebook pipeline dashboard tile

    Attributes
    ----------
    pipeline : Pipeline
        The notebook pipeline displayed in the tile
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "NOTEBOOK_PIPELINE"
    pipeline: Pipeline = ByFactory(PipelineFactory)
    _config_type = NotebookTileConfiguration

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        pipeline: Pipeline,
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: NotebookTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )
        self.pipeline = pipeline

    def _json_content(self) -> dict:
        if self.pipeline is None:
            return {}
        return {
            "notebookPipelineIdentifier": self.pipeline.identifier,
        }


class NotebookTileFactory(TileFactoryBase[NotebookTile, NotebookTileConfiguration]):
    """Factory for creating and retrieving notebook pipeline tiles"""

    tm_class = NotebookTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        pipeline: Pipeline | None,
        title: str = "",
        refresh_rate: pd.Timedelta | str = "5m",
        config: NotebookTileConfiguration | None = None,
    ) -> NotebookTile:
        """Instantiate a new notebook pipeline tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        pipeline : Pipeline or None
            Notebook pipeline to display in the tile
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "5m"
        config : NotebookTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        NotebookTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            pipeline=pipeline,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> NotebookTile:
        if pipeline_id := data["configuration"].get("notebookPipelineIdentifier"):
            pipeline = PipelineFactory(client=self.client)._from_json_identifier_only(
                pipeline_id
            )
        else:
            pipeline = None

        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            pipeline=pipeline,
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=NotebookTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(show_title: bool = True) -> NotebookTileConfiguration:
        """Default configuration for notebook pipeline tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True

        Returns
        -------
        NotebookTileConfiguration
        """
        return NotebookTileConfiguration(show_title=show_title)
