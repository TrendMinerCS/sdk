from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.asset import Attribute
from trendminer_interface.base import TupleLike
from trendminer_interface.component_factory import ComponentMultiFactory
from trendminer_interface.descriptors import (
    ByFactory,
    FromTuple,
    FromTupleList,
    HasOptions,
)
from trendminer_interface.tag import Tag

from .base import (
    DraftTileFactoryBase,
    TileBase,
    TileConfigurationBase,
    TileFactoryBase,
    TilePosition,
)

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class GaugeTileConfiguration(TileConfigurationBase):
    def __init__(
        self,
        show_title: bool,
        accuracy: float | None,
        colored_value: bool,
        percentage_ranges: bool,
        percentage_delta: bool,
        percentage_value: bool,
        show_range_labels: bool,
        show_delta: bool,
        show_ticks: bool,
        show_timestamp: bool,
        use_chart_alias: bool,
    ):
        self.show_title = show_title
        self.accuracy = accuracy
        self.use_chart_alias = use_chart_alias
        self.colored_value = colored_value
        self.percentage_ranges = percentage_ranges
        self.percentage_delta = percentage_delta
        self.percentage_value = percentage_value
        self.show_range_labels = show_range_labels
        self.show_delta = show_delta
        self.show_ticks = show_ticks
        self.show_timestamp = show_timestamp

    def _json(self) -> dict:
        payload: dict = {
            "showTitle": self.show_title,
            "colorValueAsRangeColor": self.colored_value,
            "displayRangesAsPercentage": self.percentage_ranges,
            "displayTargetDifferenceAsPercentage": self.percentage_delta,
            "displayValueAsPercentage": self.percentage_value,
            "showRangeLabel": self.show_range_labels,
            "showTargetDifference": self.show_delta,
            "showTicks": self.show_ticks,
            "showTimestamp": self.show_timestamp,
            "useChartAlias": self.use_chart_alias,
        }

        # null accuracy not accepted by API
        if self.accuracy is not None:
            payload["accuracy"] = self.accuracy

        return payload

    @classmethod
    def _from_json(cls, data: dict) -> GaugeTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
            accuracy=data.get("accuracy", None),
            colored_value=data.get("colorValueAsRangeColor", False),
            percentage_ranges=data.get("displayRangesAsPercentage", False),
            percentage_delta=data.get("displayTargetDifferenceAsPercentage", False),
            percentage_value=data.get("displayValueAsPercentage", False),
            show_range_labels=data.get("showRangeLabel", True),
            show_delta=data.get("showTargetDifference", False),
            show_ticks=data.get("showTicks", True),
            show_timestamp=data.get("showTimestamp", True),
            use_chart_alias=data.get("useChartAlias", False),
        )


class DraftGaugeTile(TileBase[GaugeTileConfiguration]):
    """A gauge tile without a component assigned

    This tile cannot be instantiated using the SDK, but it is possibly returned from a saved dashboard.
    """

    visualization_type = "DRAFT_GAUGE"
    _config_type = GaugeTileConfiguration

    def _json_content(self):
        return {}


class GaugeRange(TupleLike):
    """Range for gauge tile

    Attributes
    ----------
    min_value : float
        Minimum value of the range
    max_value : float
        Maximum value of the range
    label : str
        Label for the range
    color : str
        Color of the range (e.g., "#FF0010")
    """

    _fields = ("min_value", "max_value", "label", "color")

    def __init__(self, min_value: float, max_value: float, label: str, color: str):
        self.min_value = min_value
        self.max_value = max_value
        self.label = label
        self.color = color

    def _json_base(self) -> dict:
        return {
            "min": self.min_value,
            "max": self.max_value,
            "color": self.color,
        }

    def _json(self) -> dict:
        """Payload for a regular gauge range"""
        return {
            **self._json_base(),
            "label": self.label,
        }

    def _json_default(self) -> dict:
        """Payload for the default gauge range"""
        return {
            **self._json_base(),
            "defaultRangeLabel": self.label,
        }

    @classmethod
    def _from_json(cls, data: dict) -> GaugeRange:
        return cls(
            min_value=data["min"],
            max_value=data["max"],
            label=data.get("label", data.get("defaultRangeLabel", "")),
            color=data["color"],
        )


class GaugeTile(TileBase[GaugeTileConfiguration]):
    """Gauge dashboard tile

    Attributes
    ----------
    component : Tag or Attribute
        The time-series component to display in the gauge
    mode : str
        Display mode of the gauge. Options: "linear-vertical", "linear-horizontal", "angular", "speedometer"
    default_range : GaugeRange
        Default range for the gauge
    ranges : list[GaugeRange]
        Additional ranges for the gauge
    target : float or None
        Target value to display in the gauge
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "GAUGE"
    _config_type = GaugeTileConfiguration

    mode: str = HasOptions(
        ["linear-vertical", "linear-horizontal", "angular", "speedometer"]
    )
    component: Tag | Attribute = ByFactory(ComponentMultiFactory)
    default_range: GaugeRange = FromTuple(GaugeRange)
    ranges: list[GaugeRange] = FromTupleList(GaugeRange)

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        component: Tag | Attribute,
        mode: str,
        default_range: GaugeRange | tuple[float, float, str, str],
        ranges: list[GaugeRange | tuple[float, float, str, str]],
        target: float | None,
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: GaugeTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )

        self.component = component
        self.mode = mode
        self.default_range = default_range
        self.ranges = ranges
        self.target = target

    def _json_content(self) -> dict:
        payload: dict = {
            **self.default_range._json_default(),
            "component": {
                "identifier": self.component.identifier,
                "type": self.component.component_type,
            },
            "ranges": [r._json() for r in self.ranges],
            "type": self.mode,
        }

        if isinstance(self.component, Attribute):
            payload["component"]["path"] = self.component.path_hex

        if self.target is not None:
            payload["target"] = {"min": self.target, "type": "value"}

        return payload


class GaugeTileFactory(TileFactoryBase[GaugeTile, GaugeTileConfiguration]):
    """Factory for creating and retrieving monitor tiles"""

    tm_class = GaugeTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        component: Tag | Attribute,
        default_range: GaugeRange | tuple[float, float, str, str],
        ranges: list[GaugeRange | tuple[float, float, str, str]] | None = None,
        mode: str = "angular",
        target: float | None = None,
        title: str = "",
        refresh_rate: pd.Timedelta | str = "1m",
        config: GaugeTileConfiguration | None = None,
    ) -> GaugeTile:
        """Instantiate a new gauge tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        component : Tag or Attribute
            Time-series component to display in the gauge tile
        default_range : GaugeRange or tuple[float, float, str, str]
            Default range for the gauge tile (min, max, label, color)
        ranges : list of GaugeRange or list of tuple[float, float, str, str], optional
            Additional ranges for the gauge tile. List of (min, max, label, color), by default None
        mode : str, optional
            Type of gauge tile. Options: "linear-vertical", "linear-horizontal", "angular", "speedometer",
            by default "angular"
        target : float, optional
            Target value to display in the gauge tile, by default None
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "1m"
        config : GaugeTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        GaugeTile
        """

        return self.tm_class(
            client=self.client,
            position=position,  # TODO: fix type checker issue (https://stackoverflow.com/questions/54413434/type-hinting-with-descriptors)
            component=component,
            mode=mode,
            default_range=default_range,
            ranges=ranges or [],
            target=target,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> GaugeTile:
        """Response json to instance

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        GaugeTile
        """
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            component=ComponentMultiFactory(
                client=self.client
            )._from_json_current_value_tile(data["configuration"]["component"]),
            mode=data["configuration"]["type"],
            default_range=GaugeRange._from_json(data["configuration"]),
            ranges=[GaugeRange._from_json(r) for r in data["configuration"]["ranges"]],
            target=data["configuration"].get("target", {}).get("min", None),
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=GaugeTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(
        show_title: bool = True,
        accuracy: float | None = None,
        colored_value: bool = False,
        percentage_ranges: bool = False,
        percentage_delta: bool = False,
        percentage_value: bool = False,
        show_range_labels: bool = True,
        show_delta: bool = False,
        show_ticks: bool = True,
        show_timestamp: bool = True,
        use_chart_alias: bool = False,
    ) -> GaugeTileConfiguration:
        """Default configuration for gauge tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True
        accuracy : float, optional
            Number of decimal places to show for the value, by default None
        colored_value : bool, optional
            Whether to color the value based on the range colors, by default False
        percentage_ranges : bool, optional
            Whether to display the ranges as percentages, by default False
        percentage_delta : bool, optional
            Whether to display the target difference as a percentage, by default False
        percentage_value : bool, optional
            Whether to display the value as a percentage, by default False
        show_range_labels : bool, optional
            Whether to show the range labels, by default True
        show_delta : bool, optional
            Whether to show the target difference, by default False
        show_ticks : bool, optional
            Whether to show the ticks on the gauge, by default True
        show_timestamp : bool, optional
            Whether to show the timestamp of the value, by default True
        use_chart_alias : bool, optional
            Whether to use the chart alias for the component, by default False

        Returns
        -------
        GaugeTileConfiguration
        """
        return GaugeTileConfiguration(
            show_title=show_title,
            accuracy=accuracy,
            colored_value=colored_value,
            percentage_ranges=percentage_ranges,
            percentage_delta=percentage_delta,
            percentage_value=percentage_value,
            show_range_labels=show_range_labels,
            show_delta=show_delta,
            show_ticks=show_ticks,
            show_timestamp=show_timestamp,
            use_chart_alias=use_chart_alias,
        )

    @staticmethod
    def range(min_value: float, max_value: float, label: str, color: str) -> GaugeRange:
        """Instantiate a new gauge range

        Parameters
        ----------
        min_value : float
            Minimum value of the range
        max_value : float
            Maximum value of the range
        label : str
            Label for the range
        color : str
            Color of the range (e.g., "#FF0010")

        Returns
        -------
        GaugeRange
        """
        return GaugeRange(
            min_value=min_value,
            max_value=max_value,
            label=label,
            color=color,
        )


class DraftGaugeTileFactory(
    DraftTileFactoryBase[DraftGaugeTile, GaugeTileConfiguration]
):
    """Factory for creating draft gauge tiles"""

    tm_class = DraftGaugeTile
