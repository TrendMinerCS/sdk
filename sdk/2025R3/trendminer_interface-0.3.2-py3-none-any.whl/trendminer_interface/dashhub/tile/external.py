from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from .base import TileBase, TileConfigurationBase, TileFactoryBase, TilePosition

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class ExternalContentTileConfiguration(TileConfigurationBase):
    """Configuration for external content dashboard tile"""

    def __init__(self, show_title: bool):
        self.show_title = show_title

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
        }

    @classmethod
    def _from_json(cls, data: dict) -> ExternalContentTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
        )


class ExternalContentTile(TileBase[ExternalContentTileConfiguration]):
    """External content dashboard tile

    Attributes
    ----------
    url : str
        The URL of the external content to display
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "EXTERNAL_CONTENT"
    _config_type = ExternalContentTileConfiguration

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        url: str,
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: ExternalContentTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )
        self.url = url

    def _json_content(self) -> dict:
        return {
            "url": self.url,
        }


class ExternalContentTileFactory(
    TileFactoryBase[ExternalContentTile, ExternalContentTileConfiguration]
):
    """Factory for creating external content dashboard tiles"""

    tm_class = ExternalContentTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        url: str,
        title: str = "",
        refresh_rate: pd.Timedelta | str = "5m",
        config: ExternalContentTileConfiguration | None = None,
    ) -> ExternalContentTile:
        """Instantiate a new external content tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        url : str
            URL of the external content to display
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "5m"
        config : ExternalContentTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        ExternalContentTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            url=url,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> ExternalContentTile:
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            url=data["configuration"]["url"],
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=ExternalContentTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(show_title: bool = True) -> ExternalContentTileConfiguration:
        """Default configuration for external content tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True

        Returns
        -------
        ExternalContentTileConfiguration
        """
        return ExternalContentTileConfiguration(show_title=show_title)
