from __future__ import annotations

from typing import TYPE_CHECKING

from .base import TileBase, TileConfigurationBase, TileFactoryBase, TilePosition

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class TextTileConfiguration(TileConfigurationBase):
    """Configuration for text tile"""

    def __init__(self, show_title: bool):
        self.show_title = show_title

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
        }

    @classmethod
    def _from_json(cls, data: dict) -> TextTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
        )


class TextTile(TileBase[TextTileConfiguration]):
    """Dashboard text tile

    Attributes
    ----------
    content : str
        The text content to display in the tile
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "RICH_TEXT"
    _config_type = TextTileConfiguration
    refresh_rate = None  # Text tiles do not refresh; do not use AsTimedelta descriptor

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        content: str,
        title: str,
        config: TextTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=None,  # Text tiles do not refresh
            config=config,
        )
        self.content = content

    def _json_content(self) -> dict:
        return {
            "content": self.content,
        }


class TextTileFactory(TileFactoryBase[TextTile, TextTileConfiguration]):
    """Factory for creating and retrieving text tiles"""

    tm_class = TextTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        content: str,
        title: str = "",
        config: TextTileConfiguration | None = None,
    ) -> TextTile:
        """Instantiate a new text tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        content : str
            Text content to display in the tile
        title : str, optional
            Title of the tile, by default ""
        config : TextTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        TextTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            content=content,
            title=title,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> TextTile:
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            content=data["configuration"]["content"],
            title=data["title"],
            config=TextTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(show_title: bool = True) -> TextTileConfiguration:
        """Default configuration for text tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True

        Returns
        -------
        TextTileConfiguration
        """
        return TextTileConfiguration(show_title=show_title)
