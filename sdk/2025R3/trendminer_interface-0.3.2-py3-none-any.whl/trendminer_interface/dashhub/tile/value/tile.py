from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import AsTimedelta

from ..base import (
    DraftTileFactoryBase,
    TileBase,
    TileConfigurationBase,
    TileFactoryBase,
    TilePosition,
)
from .entry import CurrentValueEntry, CurrentValueEntryFactory

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class CurrentValueTileConfiguration(TileConfigurationBase):
    """Configuration for current value tile

    Attributes
    ----------
    show_title : bool
        Whether to show the tile title
    accuracy : float or None
        Accuracy to which values are displayed (..., 10, 1, 0.1, 0.01, ...)
    show_graph : bool
        Whether to show the trend graph
    graph_duration : pd.Timedelta or str
        Duration of the trend graph
    fill_background : bool
        Whether to fill the background
    show_component_names : bool
        Whether to show component names
    show_timestamp : bool
        Whether to show timestamp of latest datapoint
    use_chart_alias : bool
        Whether to use chart alias
    """

    graph_duration: pd.Timedelta = AsTimedelta()

    def __init__(
        self,
        show_title: bool,
        accuracy: float | None,
        show_graph: bool,
        graph_duration: pd.Timedelta | str,
        fill_background: bool,
        show_component_names: bool,
        show_timestamp: bool,
        use_chart_alias: bool,
    ):
        self.show_title = show_title
        self.accuracy = accuracy
        self.show_graph = show_graph
        self.graph_duration = graph_duration
        self.fill_background = fill_background
        self.show_component_names = show_component_names
        self.show_timestamp = show_timestamp
        self.use_chart_alias = use_chart_alias

    def _json(self) -> dict:
        components = self.graph_duration.components  # type: ignore
        timespan_str = f"{components.days * 24 + components.hours:02}{components.minutes:02}{components.seconds:02}"

        payload: dict = {
            "showTitle": self.show_title,
            "miniGraph": {
                "show": self.show_graph,
                "timeSpan": timespan_str,
            },
            "fillBackground": self.fill_background,
            "showComponentNames": self.show_component_names,
            "showTimestamp": self.show_timestamp,
            "useChartAlias": self.use_chart_alias,
        }

        # null accuracy not accepted by API
        if self.accuracy is not None:
            payload["accuracy"] = self.accuracy

        return payload

    @classmethod
    def _from_json(cls, data: dict) -> CurrentValueTileConfiguration:
        timespan_str = data["miniGraph"]["timeSpan"]
        timespan = pd.Timedelta(
            hours=int(timespan_str[0:2]),
            minutes=int(timespan_str[2:4]),
            seconds=int(timespan_str[4:6]),
        )
        return cls(
            show_title=data.get("showTitle", True),
            accuracy=data.get("accuracy"),
            show_graph=data.get("miniGraph", {}).get("show", True),
            graph_duration=timespan,
            fill_background=data.get("fillBackground", False),
            show_component_names=data.get("showComponentNames", False),
            show_timestamp=data.get("showTimestamp", True),
            use_chart_alias=data.get("useChartAlias", False),
        )


class DraftCurrentValueTile(TileBase[CurrentValueTileConfiguration]):
    visualization_type = "DRAFT_VALUE"
    _config_type = CurrentValueTileConfiguration

    def _json_content(self):
        return {}


class CurrentValueTile(TileBase[CurrentValueTileConfiguration]):
    """Current value dashboard tile

    Attributes
    ----------
    entries : list[CurrentValueEntry]
        List of current value entries to display in the tile
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "VALUE"
    _config_type = CurrentValueTileConfiguration

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition | tuple[int, int, int, int],
        entries: list[CurrentValueEntry],
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: CurrentValueTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )

        self.entries = entries

    def _json_content(self) -> dict:
        return {
            "components": [entry._json() for entry in self.entries],
        }


class CurrentValueTileFactory(
    TileFactoryBase[CurrentValueTile, CurrentValueTileConfiguration]
):
    tm_class = CurrentValueTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        entries: list[CurrentValueEntry],
        title: str = "",
        refresh_rate: pd.Timedelta | str = "1m",
        config: CurrentValueTileConfiguration | None = None,
    ) -> CurrentValueTile:
        """Instantiate new current value tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        entries : list[CurrentValueEntry]
            Entries to show in the tile
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "1m"
        config : CurrentValueTileConfiguration, optional
            Configuration of the tile, defaults to a standard configuration if None

        Returns
        -------
        CurrentValueTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            entries=entries,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> CurrentValueTile:
        """Response json to instance

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        CurrentValueTile
        """

        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            entries=[
                CurrentValueEntryFactory(client=self.client)._from_json(entry)
                for entry in data["configuration"]["components"]
            ],
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=CurrentValueTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(
        show_title: bool = True,
        accuracy: float | None = None,
        show_graph: bool = True,
        graph_duration: pd.Timedelta | str = "1h",
        fill_background: bool = False,
        show_component_names: bool = True,
        show_timestamp: bool = True,
        use_chart_alias: bool = False,
    ) -> CurrentValueTileConfiguration:
        """Default configuration for current value tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True
        accuracy : float or None, optional
            Accuracy to which values are displayed (..., 10, 1, 0.1, 0.01, ...), by default None
        show_graph : bool, optional
            Whether to show the trend graph, by default True
        graph_duration : pd.Timedelta or str, optional
            Duration of the trend graph, by default "1h"
        fill_background : bool, optional
            Whether to fill the background, by default False
        show_component_names : bool, optional
            Whether to show component names, by default True
        show_timestamp : bool, optional
            Whether to show timestamp of latest datapoint, by default True
        use_chart_alias : bool, optional
            Whether to use chart aliases, by default False

        Returns
        -------
        CurrentValueTileConfiguration
        """
        return CurrentValueTileConfiguration(
            show_title=show_title,
            accuracy=accuracy,
            show_graph=show_graph,
            graph_duration=graph_duration,
            fill_background=fill_background,
            show_component_names=show_component_names,
            show_timestamp=show_timestamp,
            use_chart_alias=use_chart_alias,
        )

    @property
    def entry(self):
        return CurrentValueEntryFactory(client=self.client)


class DraftCurrentValueTileFactory(
    DraftTileFactoryBase[DraftCurrentValueTile, CurrentValueTileConfiguration]
):
    """Factory for creating draft current value tiles"""

    tm_class = DraftCurrentValueTile
