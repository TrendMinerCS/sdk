from __future__ import annotations

from typing import Sequence

from trendminer_interface.base import TupleLike
from trendminer_interface.descriptors import HasOptions


class CurrentValueCondition(TupleLike):
    """Current value tile conditional formatting entity

    Defines a single condition and corresponding tag color

    Attributes
    ----------
    condition : str
        "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO", "EQUAL_TO",
        "NOT_EQUAL_TO", "BETWEEN", "NOT_BETWEEN", "CONTAINS" or "DOES_NOT_CONTAIN"
    value : float | str | tuple[float, float]
        Value or range of values associated with the condition
    color : str
        Tag color for the condition (e.g., "#FF0010")
    """

    _fields = ("condition", "value", "color")

    condition = HasOptions(
        {
            "GREATER_THAN": "GREATER_THAN",
            ">": "GREATER_THAN",
            "GREATER_THAN_OR_EQUAL_TO": "GREATER_THAN_OR_EQUAL_TO",
            ">=": "GREATER_THAN_OR_EQUAL_TO",
            "LESS_THAN": "LESS_THAN",
            "<": "LESS_THAN",
            "LESS_THAN_OR_EQUAL_TO": "LESS_THAN_OR_EQUAL_TO",
            "<=": "LESS_THAN_OR_EQUAL_TO",
            "EQUAL_TO": "EQUAL_TO",
            "=": "EQUAL_TO",
            "NOT_EQUAL_TO": "NOT_EQUAL_TO",
            "!=": "NOT_EQUAL_TO",
            "<>": "NOT_EQUAL_TO",
            "BETWEEN": "BETWEEN",
            "NOT_BETWEEN": "NOT_BETWEEN",
            "CONTAINS": "CONTAINS",
            "DOES_NOT_CONTAIN": "DOES_NOT_CONTAIN",
        }
    )

    def __init__(
        self, condition: str, value: float | str | tuple[float, float], color: str
    ):
        self.condition = condition
        self.value = value
        self.color = color

    def _json(self) -> dict:
        if isinstance(self.value, Sequence):
            values = list(self.value)
        else:
            values = [self.value]
        return {
            "color": self.color,
            "condition": self.condition,
            "values": values,
        }

    @classmethod
    def _from_json(cls, data: dict) -> CurrentValueCondition:
        values = data["values"]
        if len(values) == 1:
            value = values[0]
        else:
            value = tuple(values)
        return cls(
            condition=data["condition"],
            value=value,
            color=data["color"],
        )
