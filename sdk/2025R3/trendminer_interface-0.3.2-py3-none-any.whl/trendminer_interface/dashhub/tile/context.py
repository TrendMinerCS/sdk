from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.context import ContextHubView, ContextHubViewFactory
from trendminer_interface.descriptors import HasOptions

from .base import (
    DraftTileFactoryBase,
    TileBase,
    TileConfigurationBase,
    TileFactoryBase,
    TilePosition,
)

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class ContextHubViewTileConfiguration(TileConfigurationBase):
    """Configuration for ContextHub view tile

    Attributes
    ----------
    show_title : bool
        Whether to show the tile title
    show_colored_points_legend : bool
        Whether to show the colored points legend
    show_timeframe : bool
        Whether to show the timeframe
    """

    def __init__(
        self,
        show_title: bool,
        show_colored_points_legend: bool,
        show_timeframe: bool,
    ):
        self.show_title = show_title
        self.show_colored_points_legend = show_colored_points_legend
        self.show_timeframe = show_timeframe

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
            "showColoredPointsLegend": self.show_colored_points_legend,
            "showTimeFrame": self.show_timeframe,
        }

    @classmethod
    def _from_json(cls, data: dict) -> ContextHubViewTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
            show_colored_points_legend=data.get("showColoredPointsLegend", True),
            show_timeframe=data.get("showTimeFrame", True),
        )


class DraftContextHubViewTile(TileBase[ContextHubViewTileConfiguration]):
    """A ContextHub view tile without a view assigned

    This tile cannot be instantiated using the SDK, but it is possibly returned from a saved dashboard.

    Attributes
    ----------
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "DRAFT_CONTEXT_HUB_VIEW"
    _config_type = ContextHubViewTileConfiguration

    def _json_content(self) -> dict:
        return {}


class ContextHubViewTile(TileBase[ContextHubViewTileConfiguration]):
    """ContextHub tile base class

    Tile content is a ContextHub view

    Attributes
    ----------
    view : ContextHubView
        The ContextHub view displayed in the tile
    mode : str
        The display mode of the tile. Options: "COUNT", "TABLE", "GANTT"
    visualization_type : str
        The visualization type of the tile
    """

    mode = HasOptions(["COUNT", "TABLE", "GANTT"])
    visualization_type = "CONTEXT_HUB_VIEW"
    _config_type = ContextHubViewTileConfiguration

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        view: ContextHubView,
        mode: str,
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: ContextHubViewTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )
        self.view = view
        self.mode = mode

    def _json_content(self) -> dict:
        return {
            "displayMode": self.mode,
            "contextViewId": self.view.identifier,
        }


class ContextHubViewTileFactory(
    TileFactoryBase[ContextHubViewTile, ContextHubViewTileConfiguration]
):
    """Factory for creating and retrieving ContextHub view tiles"""

    tm_class = ContextHubViewTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        view: ContextHubView,
        mode: str = "TABLE",
        title: str = "",
        refresh_rate: pd.Timedelta | str = "5m",
        config: ContextHubViewTileConfiguration | None = None,
    ) -> ContextHubViewTile:
        """Instantiate a new ContextHub view tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        view : ContextHubView
            ContextHub view to display in the tile
        mode : str, optional
            Display mode of the tile. Options: "COUNT", "TABLE", "GANTT", by default "TABLE"
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "5m"
        config : ContextHubViewTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        ContextHubViewTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            view=view,
            mode=mode,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> ContextHubViewTile:
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            view=ContextHubViewFactory(client=self.client)._from_json_identifier_only(
                data["configuration"]["contextViewId"]
            ),
            mode=data["configuration"]["displayMode"],
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=ContextHubViewTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(
        show_title: bool = True,
        show_colored_points_legend: bool = True,
        show_timeframe: bool = True,
    ) -> ContextHubViewTileConfiguration:
        """Default configuration for ContextHub view tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True
        show_colored_points_legend : bool, optional
            Whether to show the colored points legend, by default True
        show_timeframe : bool, optional
            Whether to show the timeframe, by default True

        Returns
        -------
        ContextHubViewTileConfiguration
        """
        return ContextHubViewTileConfiguration(
            show_title=show_title,
            show_colored_points_legend=show_colored_points_legend,
            show_timeframe=show_timeframe,
        )


class DraftContextHubViewTileFactory(
    DraftTileFactoryBase[DraftContextHubViewTile, ContextHubViewTileConfiguration]
):
    """Factory for creating draft ContextHub view tiles"""

    tm_class = DraftContextHubViewTile
