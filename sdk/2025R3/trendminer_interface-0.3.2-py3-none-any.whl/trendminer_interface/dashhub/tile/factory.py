from trendminer_interface.base import MultiFactoryBase, to_subfactory

from .context import ContextHubViewTileFactory, DraftContextHubViewTileFactory
from .external import ExternalContentTileFactory
from .gauge import DraftGaugeTileFactory, GaugeTileFactory
from .monitor import DraftMonitorTileFactory, MonitorTileFactory
from .notebook import NotebookTileFactory
from .text import TextTileFactory
from .trend import DraftTrendHubViewTileFactory, TrendHubViewTileFactory
from .value import CurrentValueTileFactory, DraftCurrentValueTileFactory


class TileMultiFactory(MultiFactoryBase):
    """Factory for creating dashboard tile instances out of json responses"""

    factories = {
        factory.tm_class.visualization_type: factory
        for factory in [
            CurrentValueTileFactory,
            ContextHubViewTileFactory,
            DraftContextHubViewTileFactory,
            DraftCurrentValueTileFactory,
            DraftGaugeTileFactory,
            DraftMonitorTileFactory,
            DraftTrendHubViewTileFactory,
            ExternalContentTileFactory,
            GaugeTileFactory,
            MonitorTileFactory,
            NotebookTileFactory,
            TextTileFactory,
            TrendHubViewTileFactory,
        ]
    }

    @to_subfactory
    def _from_json(self, data: dict):
        return data["visualizationType"]
