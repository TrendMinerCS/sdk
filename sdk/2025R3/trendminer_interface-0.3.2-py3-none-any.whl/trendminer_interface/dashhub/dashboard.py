from __future__ import annotations

from typing import TYPE_CHECKING

from trendminer_interface.aliasing import resolve_chart_aliases
from trendminer_interface.asset import Attribute
from trendminer_interface.descriptors import ByFactory
from trendminer_interface.folder import Folder
from trendminer_interface.tag import Tag
from trendminer_interface.work import (
    WorkOrganizerObjectBase,
    WorkOrganizerObjectFactoryBase,
)

if TYPE_CHECKING:
    import pandas as pd

    from trendminer_interface.client import TrendMinerClient
    from trendminer_interface.user import User


from .tile import (
    ContextHubViewTile,
    ContextHubViewTileConfiguration,
    ContextHubViewTileFactory,
    CurrentValueTile,
    CurrentValueTileConfiguration,
    CurrentValueTileFactory,
    ExternalContentTile,
    ExternalContentTileConfiguration,
    ExternalContentTileFactory,
    GaugeTile,
    GaugeTileConfiguration,
    GaugeTileFactory,
    MonitorTile,
    MonitorTileConfiguration,
    MonitorTileFactory,
    NotebookTile,
    NotebookTileConfiguration,
    NotebookTileFactory,
    TextTile,
    TextTileConfiguration,
    TextTileFactory,
    TileMultiFactory,
    TilePosition,
    TrendHubViewTile,
    TrendHubViewTileConfiguration,
    TrendHubViewTileFactory,
)


class DashboardConfiguration:
    """Global dashboard configuration

    Can override settings for the different tile types.

    Attributes
    ----------
    context : ContextHubViewTileConfiguration
        Global configuration for ContextHub view tiles
    external : ExternalContentTileConfiguration
        Global configuration for External content tiles
    gauge : GaugeTileConfiguration
        Global configuration for Gauge tiles
    monitor : MonitorTileConfiguration
        Global configuration for Monitor tiles
    notebook : NotebookTileConfiguration
        Global configuration for Notebook tiles
    text : TextTileConfiguration
        Global configuration for Text tiles
    trend : TrendHubViewTileConfiguration
        Global configuration for TrendHub view tiles
    value : CurrentValueTileConfiguration
        Global configuration for Current value tiles
    """

    def __init__(
        self,
        context: ContextHubViewTileConfiguration,
        external: ExternalContentTileConfiguration,
        gauge: GaugeTileConfiguration,
        monitor: MonitorTileConfiguration,
        notebook: NotebookTileConfiguration,
        text: TextTileConfiguration,
        trend: TrendHubViewTileConfiguration,
        value: CurrentValueTileConfiguration,
    ):
        self.context = context
        self.external = external
        self.gauge = gauge
        self.monitor = monitor
        self.notebook = notebook
        self.text = text
        self.trend = trend
        self.value = value

    def _json(self):
        return {
            ContextHubViewTile.visualization_type: self.context._json(),
            ExternalContentTile.visualization_type: self.external._json(),
            GaugeTile.visualization_type: self.gauge._json(),
            MonitorTile.visualization_type: self.monitor._json(),
            NotebookTile.visualization_type: self.notebook._json(),
            TextTile.visualization_type: self.text._json(),
            TrendHubViewTile.visualization_type: self.trend._json(),
            CurrentValueTile.visualization_type: self.value._json(),
        }

    @classmethod
    def _from_json(cls, data: dict):
        return cls(
            context=ContextHubViewTileConfiguration._from_json(
                data[ContextHubViewTile.visualization_type]
            ),
            external=ExternalContentTileConfiguration._from_json(
                data[ExternalContentTile.visualization_type]
            ),
            gauge=GaugeTileConfiguration._from_json(data[GaugeTile.visualization_type]),
            monitor=MonitorTileConfiguration._from_json(
                data[MonitorTile.visualization_type]
            ),
            notebook=NotebookTileConfiguration._from_json(
                data[NotebookTile.visualization_type]
            ),
            text=TextTileConfiguration._from_json(data[TextTile.visualization_type]),
            trend=TrendHubViewTileConfiguration._from_json(
                data[TrendHubViewTile.visualization_type]
            ),
            value=CurrentValueTileConfiguration._from_json(
                data[CurrentValueTile.visualization_type]
            ),
        )


class Dashboard(WorkOrganizerObjectBase):
    """TrendMiner dashboard (DashHub view)

    Attributes
    ----------
    live : bool
        Whether the dashboard is updating live
    tiles : list
        Tiles that are on the dashboard
    global_timeframe : dict
        Global timeframe configuration for the dashboard. Currently configured as a raw dictionary. Setting/editing
        the global timeframe is not yet supported.
    chart_aliases : dict[Tag | Attribute, str]
        Chart aliases mapping tags and attributes to custom strings
    dynamic_font_sizing: bool
        Whether dynamic font sizing is enabled
    override_tile_config: bool
        Whether the dashboard configuration overrides individual tile settings
    config : DashboardConfiguration
        Dashboard configuration settings
    scrollable : bool
        Whether the dashboard is scrollable. Should be True for new dashboards. Exists for backwards compatibility.
    """

    content_type = "DASHBOARD"
    tiles = ByFactory(TileMultiFactory, "_list")

    def __init__(
        self,
        client: TrendMinerClient,
        identifier: str | None,
        name: str,
        description: str,
        parent: Folder | None,
        owner: User | None,
        last_modified: pd.Timestamp | None,
        version: int | None,
        tiles: list[
            ContextHubViewTile
            | CurrentValueTile
            | ExternalContentTile
            | GaugeTile
            | MonitorTile
            | NotebookTile
            | TextTile
            | TrendHubViewTile
        ],
        live: bool,
        global_timeframe: dict,
        dynamic_font_sizing: bool,
        override_tile_config: bool,
        config: DashboardConfiguration,
        scrollable: bool,
        chart_aliases: dict[Tag | Attribute, str],
    ):
        WorkOrganizerObjectBase.__init__(
            self,
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            parent=parent,
            owner=owner,
            last_modified=last_modified,
            version=version,
        )

        self.live = live
        self.tiles = tiles
        self.global_timeframe = global_timeframe
        self.dynamic_font_sizing = dynamic_font_sizing
        self.override_tile_config = override_tile_config
        self.config = config
        self.chart_aliases = chart_aliases
        self.scrollable = scrollable

    def _json_data(self):
        json_data: dict = {
            "autoRefreshEnabled": self.live,
            "configuration": {
                **self.config._json(),
                "dynamicFontSizing": self.dynamic_font_sizing,
                "overrideTileSettings": self.override_tile_config,
            },
            "scrollable": self.scrollable,
            "tiles": [tile._json() for tile in self.tiles],
        }

        if self.global_timeframe is not None:
            json_data["globalTimeframe"] = self.global_timeframe

        if self.chart_aliases:
            json_data["chartAliases"] = {
                entry.identifier: alias for entry, alias in self.chart_aliases.items()
            }

        return json_data

    def _full_instance(self):
        return DashboardFactory(client=self.client).from_identifier(self.identifier)


class DashboardFactory(WorkOrganizerObjectFactoryBase):
    """Factory for initializing and retrieving dashboards"""

    tm_class = Dashboard

    def __call__(
        self,
        tiles,
        name: str = "New Dashboard",
        description: str = "",
        parent: Folder | None = None,
        live: bool = False,
        global_timeframe: dict | None = None,
        dynamic_font_sizing: bool = True,
        override_tile_config: bool = False,
        config: DashboardConfiguration | None = None,
        chart_aliases: dict[Tag | Attribute, str] | None = None,
    ):
        """Initialize a new dashboard

        Parameters
        ----------
        tiles : list[TileBase]
            Tiles to add to the dashboard
        name : str, default "New Dashboard"
            Name of the dashboard
        description : str, optional
            Dashboard description
        parent : Folder, optional
            Folder in which the dashboard needs to be saved
        live : bool, default False
            Whether the dashboard will be updated live
        dynamic_font_sizing : bool, default True
            Whether dynamic font sizing is enabled
        override_tile_config : bool, default False
            Whether the dashboard configuration overrides individual tile settings
        config : DashboardConfiguration, optional
            Dashboard global configuration settings. Overrides tile settings when `override_tile_config` is True,
            otherwise does not have an effect.
        chart_aliases: dict[Union[Tag, Attribute], str], optional
            Chart aliases mapping tags and attributes to custom strings

        Returns
        -------
        Dashboard
        """

        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            parent=parent,
            owner=None,
            last_modified=None,
            version=None,
            tiles=tiles,
            live=live,
            global_timeframe={"type": "DEFAULT"},
            dynamic_font_sizing=dynamic_font_sizing,
            override_tile_config=override_tile_config,
            config=config or self.config(),
            scrollable=True,  # Should be True for new dashboards. Parameter only exists for backwards compatibility.
            chart_aliases={} if chart_aliases is None else chart_aliases,
        )

    def _json_data(self, data):
        """Enriched response json to dashboard

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        Dashboard
        """

        tiles = [
            TileMultiFactory(client=self.client)._from_json(tile)
            for tile in data["data"]["tiles"]
        ]

        # Get chart aliases payload
        aliasable_components = []
        for tile in tiles:
            if isinstance(tile, CurrentValueTile):
                for entry in tile.entries:
                    aliasable_components.append(entry.component)
            elif isinstance(tile, GaugeTile):
                aliasable_components.append(tile.component)

        chart_aliases = resolve_chart_aliases(
            data["data"].get("chartAliases", {}),
            entries=aliasable_components,
        )

        # Dashboard global tile configuration is optional. For the SDK users it is cleaner if the config is always
        # available as an object. Therefore, we set it to the default configuration when not present in the response.
        if "overrideTileSettings" in data["data"]["configuration"]:
            config = DashboardConfiguration._from_json(data["data"]["configuration"])
        else:
            config = self.config()

        return {
            "live": data["data"].get("autoRefreshEnabled", False),
            "scrollable": data["data"].get("scrollable", True),
            "tiles": tiles,
            "global_timeframe": data["data"].get("globalTimeframe"),
            "dynamic_font_sizing": data["data"]["configuration"].get(
                "dynamicFontSizing", True
            ),
            "override_tile_config": data["data"]["configuration"].get(
                "overrideTileSettings", False
            ),
            "config": config,
            "chart_aliases": chart_aliases,
        }

    @property
    def context(self):
        """ContextHub view tile factory

        Returns
        -------
        ContextHubViewTileFactory
        """
        return ContextHubViewTileFactory(client=self.client)

    @property
    def external(self):
        """External content tile factory

        Returns
        -------
        ExternalContentTileFactory
        """
        return ExternalContentTileFactory(client=self.client)

    @property
    def gauge(self):
        """Gauge tile factory

        Returns
        -------
        GaugeTileFactory
        """
        return GaugeTileFactory(client=self.client)

    @property
    def monitor(self):
        """Monitor tile factory

        Returns
        -------
        MonitorTileFactory
        """
        return MonitorTileFactory(client=self.client)

    @property
    def notebook(self):
        """Notebook tile factory

        Returns
        -------
        NotebookTileFactory
        """
        return NotebookTileFactory(client=self.client)

    @property
    def text(self):
        """Text tile factory

        Returns
        -------
        TextTileFactory
        """
        return TextTileFactory(client=self.client)

    @property
    def trend(self):
        """TrendHub view tile factory

        Returns
        -------
        TrendHubViewTileFactory
        """
        return TrendHubViewTileFactory(client=self.client)

    @property
    def value(self):
        """Current value tile factory

        Returns
        -------
        CurrentValueTileFactory
        """
        return CurrentValueTileFactory(client=self.client)

    @staticmethod
    def position(x: int, y: int, width: int, height: int) -> TilePosition:
        """Create a tile position object

        Parameters
        ----------
        x : int
            X coordinate of the tile upper left corner
        y : int
            Y coordinate of the tile upper left corner
        width : int
            Width of the tile (in grid units)
        height : int
            Height of the tile (in grid units)

        Returns
        -------
        TilePosition
        """
        return TilePosition(x=x, y=y, width=width, height=height)

    @staticmethod
    def config(
        context: ContextHubViewTileConfiguration | None = None,
        external: ExternalContentTileConfiguration | None = None,
        gauge: GaugeTileConfiguration | None = None,
        monitor: MonitorTileConfiguration | None = None,
        notebook: NotebookTileConfiguration | None = None,
        text: TextTileConfiguration | None = None,
        trend: TrendHubViewTileConfiguration | None = None,
        value: CurrentValueTileConfiguration | None = None,
    ) -> DashboardConfiguration:
        """Create a global dashboard configuration object

        Can override settings for the different tile types. Takes the configurations of the different tile types as
        input. If a configuration is not provided, the default configuration of the respective tile factory is used.

        Parameters
        ----------
        context : ContextHubViewTileConfiguration, optional
            Global configuration for ContextHub view tiles
        external : ExternalContentTileConfiguration, optional
            Global configuration for External content tiles
        gauge : GaugeTileConfiguration, optional
            Global configuration for Gauge tiles
        monitor : MonitorTileConfiguration, optional
            Global configuration for Monitor tiles
        notebook : NotebookTileConfiguration, optional
            Global configuration for Notebook tiles
        text : TextTileConfiguration, optional
            Global configuration for Text tiles
        trend : TrendHubViewTileConfiguration, optional
            Global configuration for TrendHub view tiles
        value : CurrentValueTileConfiguration, optional
            Global configuration for Current value tiles
        """
        return DashboardConfiguration(
            context=context or ContextHubViewTileFactory.config(),
            external=external or ExternalContentTileFactory.config(),
            gauge=gauge or GaugeTileFactory.config(),
            monitor=monitor or MonitorTileFactory.config(),
            notebook=notebook or NotebookTileFactory.config(),
            text=text or TextTileFactory.config(),
            trend=trend or TrendHubViewTileFactory.config(),
            value=value or CurrentValueTileFactory.config(),
        )
