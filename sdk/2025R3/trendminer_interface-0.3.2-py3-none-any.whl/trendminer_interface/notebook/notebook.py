from trendminer_interface.work import (
    WorkOrganizerObjectBase,
    WorkOrganizerObjectFactoryBase,
)


class Notebook(WorkOrganizerObjectBase):
    """TrendMiner MLHub notebook"""

    content_type = "NOTEBOOK"

    def __init__(
        self,
        client,
        identifier,
        name,
        description,
        parent,
        owner,
        last_modified,
        version,
        data: dict,
    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            parent=parent,
            owner=owner,
            last_modified=last_modified,
            version=version,
        )
        self.data = data

    def _full_instance(self):
        return NotebookFactory(client=self.client).from_identifier(self.identifier)

    def _json_data(self):
        return self.data


class NotebookFactory(WorkOrganizerObjectFactoryBase):
    """Factory for retrieving TrendMiner MLHub notebooks

    Creating a new notebook via SDK is not supported.
    """

    tm_class = Notebook

    def _json_data(self, data):
        """Full enriched payload"""
        return {"data": data["data"]}
