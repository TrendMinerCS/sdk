from .notebook import NotebookFactory
from .pipeline import PipelineFactory


class NotebookClient:
    """Client for TrendMiner MLHub notebooks and pipelines"""

    @property
    def notebook(self) -> NotebookFactory:
        """Factory for retrieving TrendMiner MLHub notebooks

        Returns
        -------
        NotebookFactory
        """
        return NotebookFactory(client=self)

    @property
    def pipeline(self) -> PipelineFactory:
        """Factory for retrieving TrendMiner MLHub pipelines

        Returns
        -------
        PipelineFactory
        """
        return PipelineFactory(client=self)
