from trendminer_interface.work import (
    WorkOrganizerObjectBase,
    WorkOrganizerObjectFactoryBase,
)


class Pipeline(WorkOrganizerObjectBase):
    """TrendMiner MLHub pipeline"""

    content_type = "PIPELINE"

    def __init__(
        self,
        client,
        identifier,
        name,
        description,
        parent,
        owner,
        last_modified,
        version,
        data: dict,
    ):
        super().__init__(
            client=client,
            identifier=identifier,
            name=name,
            description=description,
            parent=parent,
            owner=owner,
            last_modified=last_modified,
            version=version,
        )
        self.data = data

    def _full_instance(self):
        return PipelineFactory(client=self.client).from_identifier(self.identifier)

    def _json_data(self):
        return self.data


class PipelineFactory(WorkOrganizerObjectFactoryBase):
    """Factory for retrieving and instantiating TrendMiner MLHub pipelines"""

    tm_class = Pipeline

    def __call__(
        self,
        data,
        name="New Pipeline",
        description="",
        parent=None,
    ):
        """Instantiate a new TrendMiner MLHub pipeline

        Attributes
        ----------
        data : dict
            Pipeline data payload. This value is not intended to be constructed manually. Use an existing pipeline as a
            template.
        name : str, optional
            Pipeline name, by default "New Pipeline"
        description : str, optional
            Pipeline description, by default ""
        parent : Folder, optional
            Parent folder. Defaults to the current user's home folder

        Returns
        -------
        Pipeline
            New pipeline instance
        """
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            description=description,
            parent=parent,
            owner=None,
            last_modified=None,
            version=None,
            data=data,
        )

    def _json_data(self, data):
        """Full enriched payload"""
        return {"data": data["data"]}
