from trendminer_interface.base import FactoryBase
from .base import UserBase


EVERYONE_IDENTIFIER = "99999999-9999-9999-9999-999999999999"
EVERYONE_NAME = "*"


class Everyone(UserBase):
    _subject_type = "EVERYONE"
    _beneficiary_type = "GROUP"

    def __init__(self, client):
        super().__init__(client=client, identifier=EVERYONE_IDENTIFIER, name=EVERYONE_NAME)


class EveryoneFactory(FactoryBase):
    tm_class = Everyone

    def __init__(self, client):
        super().__init__(client)

    def _from_json_asset_access(self, data):
        return self.tm_class(client=self.client)

    def _from_json_work(self, data):
        return self.tm_class(client=self.client)

    @property
    def everyone(self):
        """'Everyone' user needed to give all users permissions/access at once

        Returns
        -------
        everyone : Everyone
            Pseudo-user representing all TrendMiner users
        """
        return self.tm_class(client=self.client)
