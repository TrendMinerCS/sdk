from .base import BaseACL, BaseACLFactory


class DatasourceACL(BaseACL):
    endpoint = "confighub/v2/acl/DATASOURCE"

    def _full_instance(self):
        return DatasourceACLFactory(client=self.client).from_identifier(self.identifier)


class DatasourceACLFactory(BaseACLFactory):
    tm_class = DatasourceACL