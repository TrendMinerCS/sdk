import pandas as pd

from trendminer_interface.base import RetrievableBase, FactoryBase, AsTimestamp
from trendminer_interface.times import Interval, IntervalFactory
from trendminer_interface.exceptions import ResourceNotFound

import trendminer_interface._input as ip

# TODO: event should not be needed anymore

class Event(RetrievableBase):
    """A context item event

    An event is defined by a timestamp and a state. A context item event is assigned a unique identifier (uuid) by
    TrendMiner.

    Attributes
    ----------
    state : str
        The context event state
    timestamp: datetime.datetime
        The event timestamp
    """
    timestamp = AsTimestamp()

    def __init__(self, client, identifier, state, timestamp):
        super().__init__(client=client, identifier=identifier)

        self.state = state
        self.timestamp = timestamp

    def _json(self):
        return {
            "identifier": self.identifier,
            "occurred": self.timestamp.isoformat(timespec="milliseconds"),
            "state": self.state
        }

    def __repr__(self):
        return f"<< Event | {self.state} | {self.timestamp.ctime()} >>"


class EventFactory(FactoryBase):
    """Factory for creating and retrieving context events

    Attributes
    ----------
    workflow : ContextWorkflow
        Workflow of the context item type. The workflow allows events can be generated from lists of timestamps, as
        the workflow reveals what the states of these events should be.
    """
    tm_class = Event

    def __init__(self, client, workflow):
        super().__init__(client=client)
        self.workflow = workflow

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        Event
        """
        return self.tm_class(client=self.client,
                             identifier=data["identifier"],
                             state=data.get("state"),
                             timestamp=data["occurred"],
                             )

    def _list(self, refs):
        """Generate list of events

        Parameters
        ----------
        refs : list
            Entries from which to generate events

        Returns
        -------
        list of Event
            Context item events
        """
        if isinstance(refs, Interval):
            return self.from_interval(refs)
        try:
            events = self.from_datetimes(refs)
        except (AttributeError, TypeError, IndexError, ResourceNotFound):
            events = super(EventFactory, self)._list(refs)
            events.sort(key=lambda event: event.timestamp)
        return events

    def from_interval(self, ref):
        """Make list of events based on an interval

        Parameters
        ----------
        ref : Any
            A single (entry convertible to) Interval

        Returns
        -------
        list of Event
            List with two events, corresponding to the interval start and end timestamp. The states match the workflow
            start and end state.
        """
        ref = IntervalFactory(client=self.client)._get(ref)

        if self.workflow is None:
            return [Event(client=self.client, identifier=None, state=None, timestamp=ref.start)]

        return [
            Event(client=self.client, identifier=None, state=self.workflow.states[0], timestamp=ref.start),
            Event(client=self.client, identifier=None, state=self.workflow.states[-1], timestamp=ref.end)
        ]

    # TODO: seems incorrect. Workflow states should not be iterated in order. Except for start and end state there should be no particular order. Perhaps possible do use default .list
    def from_datetimes(self, refs):
        """Make list of events from list of timestamps

        Parameters
        ----------
        refs : list
            List of (entries convertible to) datetime.datetime

        Returns
        -------
        list of Event
            List with events at the given timestamps, with states corresponding to the states in the workflow (in the
            same order). If the workflow is absent, only a single event is returned regardless of the number of entries.
        """
        refs = ip.any_list(refs)
        times = []
        for ref in refs:
            time = pd.Timestamp(ref)
            if not time.tz:
                time = time.tz_localize(self.client.tz)
            else:
                time = time.tz_convert(self.client.tz)
            times.append(time)

        if self.workflow is None:
            return [Event(client=self.client, identifier=None, state=None, timestamp=times[0])]

        return [
            Event(client=self.client, identifier=None, state=self.workflow.states[i], timestamp=ts)
            for i, ts in enumerate(times)
        ]
