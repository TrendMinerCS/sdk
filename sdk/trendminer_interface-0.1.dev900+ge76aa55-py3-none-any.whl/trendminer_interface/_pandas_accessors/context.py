import pandas as pd
from trendminer_interface.constants import MAX_GET_SIZE, MAX_POST_SIZE


@pd.api.extensions.register_dataframe_accessor("context")
class ContextItemAccessor:

    def __init__(self, pandas_obj):
        self._validate(pandas_obj)
        self._obj = pandas_obj

    @staticmethod
    def _validate(obj):

        if not isinstance(obj.index.dtype, pd.IntervalDtype):
            raise AttributeError("Context items are expected to have pandas.IntervalIndex index")

        if "type" not in obj.columns:
            raise AttributeError("Context items should have a `type` column")

        if "component" not in obj.columns:
            raise AttributeError("Context items should have a `component` column")

    @staticmethod
    def _validate_identifiers(obj):
        if obj["identifier"].isnull().any():
            raise AttributeError("All context items need an valid identifier to be updated")


    @property
    def client(self):
        """Client object associated with the DataFrame

        Only a single client per DataFrame is supported

        Returns
        -------
        TrendMinerClient
        """

        # Return client from first context type
        return self._obj["type"].iloc[0].client

    def save(self):
        """Create multiple new context items to the appliance in a single request

        Creating multiple items at once in one (large) POST request is much more efficient than creating items
        individually in a loop.

        Returns
        -------
        None

        Notes
        -----
        Updating context items via this method does not return anything, nor are any properties (e.g. identifier, key,
        last_modified, ...) updated in place. Context items need to be retrieved from the server via a ContextHubView
        search (`get_items` method) to get their metadata.
        """

        if self._obj.empty:
            return

        payload = self._obj.apply(item_to_json, axis=1).to_list()
        self.client.session.post("/context/item/batch", json=payload)

    def update(self):
        """Update the server context items based on the current data in the DataFrame

        Returns
        -------
        None

        Notes
        -----
        A request needs to be sent for every individual context item in the DataFrame, making this method slow compared
        to creating new items (which can be performed in a single request).

        Updating context items via this method does not return anything, nor are any properties (e.g. last_modified)
        updated in place. Context items need to be retrieved from the server via a ContextHubView search (`get_items`
        method) to get their metadata.

        When the original context items were open-ended (i.e., lacking an end state and having the current time at the
        moment of loading the item as the `index.right` value), they will be automatically closed when updating.
        When loading items with the goal of updating them, you generally load only closed items by using a filter:
        `ContextHubView.get_items(filters=[client.context.filter.states(mode="CLOSED_ONLY"), ...], ... )`
        """

        if self._obj.empty:
            return

        self._validate_identifiers(self._obj)

        payloads = self._obj.apply(item_to_json, axis=1).to_list()

        for payload in payloads:
            self.client.session.put(f"/context/item/{payload['identifier']}", json=payload)

    # TODO: get_approval method

    def approve(self):
        # TODO: errors parameter to deal with pre-existing approvals or types without approvals enabled
        """Add user approval to these context items

        Returns
        -------
        None
        """

        self._validate_identifiers(self._obj)

        # TODO: check if unique types have approvals enabled

        for identifier in self._obj["identifier"]:
            self.client.session.post(f"/context/data/{identifier}/approval")

    def remove_approval(self):
        """Remove user approval from these context items

        Returns
        -------
        None
        """
        self._validate_identifiers(self._obj)

        for identifier in self._obj["identifier"]:
            self.client.session.delete(f"/context/data/{identifier}/approval")

    def get_history(self):
        """Get context item history

        Returns
        -------
        pd.Series
        """

        # TODO: handling errors if history is not activated? Better way to structure output?
        params = {"size": MAX_GET_SIZE, "sort": "desc"}
        return self._obj.apply(
            lambda item: (
                self.client.session.get(f"/context/history/{item['identifier']}", params=params)
                .json()["content"]
            ),
            axis=1,
        )


def item_to_json(item):
    """Convert DataFrame row representing a context item to json payload

    Parameters
    ----------
    item : pd.Series

    Returns
    -------
    payload : dict
    """

    # Keywords are all columns where the value is a `True` boolean.
    keywords = item[item.apply(lambda value: value is True)].index.to_list()
    keywords = [kw.lower() for kw in keywords]

    # Events are all columns of the datetime type which are not `created` or `last_modified`
    if item["type"].workflow is None:
        events = [{"occurred": item.name.left.isoformat(timespec="milliseconds")}]
    else:
        additional_event_ser = (
            item[item.apply(isinstance, args=(pd.Timestamp, ))]
            .drop(["last_modified", "created"], errors="ignore")
        )

        additional_events = [
            {
                "occurred": value.isoformat(timespec="milliseconds"),
                "state": key
            }
            for key, value in additional_event_ser.to_dict().items()
        ]

        start_event = {
            "occurred": item.name.left.isoformat(timespec="milliseconds"),
            "state": item["type"].workflow.states[0],
        }

        end_event = {
            "occurred": item.name.right.isoformat(timespec="milliseconds"),
            "state": item["type"].workflow.states[1],
        }

        events = [start_event] + additional_events + [end_event]


    # Fields are str or numeric values which are not booleans
    fields = (
        item[item.apply(isinstance, args=((str, float, int), )) & ~item.apply(isinstance, args=(bool, ))]
        .dropna()  # nan values are seen as floats
        .drop(
            ["key", "identifier", "identifier_external", "description", "type", "component", # drop all default fields
             "created_by", "created", "last_modified"] + keywords, # Booleans are seen as int -> ignore keywords
            errors="ignore"  # dropped too many fields to be on the safe side (e.g. a user changed the type)
        )
        .to_dict()
    )

    payload = {
        "identifier": item.get("identifier"),
        "description": item.get("description", ""),
        "keywords": keywords,
        "type":  item["type"]._json(),
        "components": [item["component"]._json_component()],
        "fields": fields,
        "events": events,
    }

    return payload
