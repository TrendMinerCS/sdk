def test_client(cfg):
    cfg.session.token_refresh()
    print(cfg.now())


def test_users(cfg):

    prefix = cfg.unique_prefix

    # Users
    user = cfg.user(
        name=prefix,
        first_name="QA",
        last_name="Test",
        mail=f"{prefix}@trendminer.com"
    )
    user.save("Password1!")
    user = cfg.user.from_name(prefix)
    user.first_name = "QA2"
    user.update()
    assert cfg.user.from_identifier(user.identifier).first_name == "QA2"
    user.set_password("Password2!")
    assert len(cfg.user.by_name(prefix)) > 0
    assert len(cfg.user.all()) > 0
    user.delete()

    # Clients
    client = cfg.client(f"{prefix}client")
    client.save()
    client.name = f"{prefix}client2"
    client.update()
    assert cfg.client._get(f"{prefix}client2")
    assert len(cfg.client.all()) > 0
    client.delete()


def test_groups(cfg):
    assert cfg.group.local()

    prefix = cfg.unique_prefix

    group = cfg.group(prefix+"1")
    group.save()

    n = 5
    users = [cfg.user(name=f"{prefix}{i}", first_name="QA", last_name="TEST", mail=f"{prefix}{i}@trendminer.com")
             for i in range(0,n)]

    for user in users:
        user.save("Password1!")
        group.member_add(user)

    assert len(group.members_get()) == n

    group2 = cfg.group(prefix+"2")
    group2.save()
    assert len(cfg.group.by_name(prefix)) == 2

    group2.member_add(group)
    assert len(group2.members_get()) == 1

    group.member_remove(users[0].name)
    assert len(group.members_get()) == n-1

    group.delete()
    group2.delete()

    for user in users:
        user.delete()


def test_datasource(cfg):

    prefix = cfg.unique_prefix
    connector_name = f"SDK_QA_{prefix}"
    connector = cfg.connector(connector_name, f"https://{prefix}.trendminer.com", username="qa.test", password="test123")
    connector.save()
    assert len(cfg.connector.all()) > 0

    ds = cfg.datasource(
        name=prefix,
        connector=connector_name,
        provider="odbc",
        host=connector_name,
        tagfilter="CS*",
        prefix=prefix[-5:],
        max_connections=2,
    )
    ds.save()

    ds = cfg.datasource._get(prefix)
    ds.name = prefix + "2"
    ds.update()
    assert len(cfg.datasource.all()) > 0

    ds.delete()
    connector.delete()


def test_acl(cfg):

    prefix = cfg.unique_prefix

    user = cfg.user(name=prefix, first_name="QA", last_name="TEST", mail=f"{prefix}@trendminer.com")
    user.save("Password123!")

    client = cfg.client(prefix+"client")
    client.save()

    group = cfg.group(name=prefix)
    group.save()

    acl = cfg.access(name=prefix, members=[user, group, client])
    acl.save()

    for member in [user, group, client]:
        acl.member_remove(member)
        assert len(acl.members_get()) == 2
        acl.member_add(member)
        assert len(acl.members_get()) == 3

    acl.delete()
    client.delete()
    user.delete()
    group.delete()
