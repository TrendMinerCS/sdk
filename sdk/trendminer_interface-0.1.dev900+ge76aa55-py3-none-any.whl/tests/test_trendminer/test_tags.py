def test_datasource(client):
    assert client.datasource.all()
    assert client.datasource.all()
    assert client.datasource.from_name("demo")
    assert client.datasource.from_name("formula")
    ds = client.datasource.from_name("prediction")
    assert client.datasource.from_identifier(ds.identifier)
    assert client.datasource.from_identifier(ds.identifier)


def test_get(client):
    tag = client.tag.from_name("TM_day_Europe_Brussels")
    assert tag.name == client.tag.from_name("TM_DAY_Europe_Brussels").name
    assert tag.identifier == client.tag.from_identifier(tag.identifier).identifier
    assert tag.identifier == client.tag._get(tag.name).identifier
    assert isinstance(client.tag._list(["TM_day_Europe_Brussels", "TM_hour_Europe_Brussels"]), list)
    assert tag.datasource


def test_search(client):
    assert client.tag.search(name="*")
    assert client.tag.search("TM_day*")
    assert client.tag.search(name="TM_hour*")
    assert client.tag.search(description="*day*")
    assert client.tag.search(name="TM_day*", datasources=["DEMO"])
    assert client.tag.search(name="TM_hour*", datasources=["demo"])
    assert client.tag.search(description="*day*", datasources="DEMO")


def test_phases(client):
    tag = client.tag.from_name("TM_day_Europe_Brussels")
    assert "Monday" in tag.states.values()
    tag = client.tag.from_identifier(tag.identifier)
    assert "Tuesday" in tag.states.values()


def test_data(client):
    tag = client.tag.from_name("TM_hour_Europe_Brussels")
    assert tag._empty_series().index.tzinfo.zone
    data = tag.get_data("8h", resolution='2m')
    assert len(data) > 100

    tag = client.tag.from_name("TM4-BP2-CONC.1")
    period = ("2023-01-01", "2023-01-31")
    data = tag.get_index_data(period)
    assert len(data) > 100
    assert data.index.tzinfo.zone

    period = ("2023-01-01", "2023-01-02")
    data = tag.get_chart_data(period, n_blocks=300)
    assert len(data) > 100


def test_index(client):
    assert client.tag.index.search()
    assert client.tag.index.search(name="TM_day*")
    client.tag.index.search(status="INCOMPLETE")

    tag = client.tag.from_name("TM_year_Asia_Jakarta")
    assert tag.index.status
    assert tag.index.progress is not None
    tag.index.refresh()
    assert tag.index
    tag.index.delete()
    assert tag.index
    assert tag.index.tag
    tag.index()


def test_calculations(client):
    tag = client.tag.from_name("TM_hour_Europe_Brussels")
    assert tag.calculate("1d", "mean")
    intervals = client.interval._list(["1d", "1w", "1M"])

    assert tag.calculate(operation="max", intervals=intervals, inplace=False)

    tag.calculate(operation="delta", intervals=intervals, inplace=True, key="difference")
    assert intervals[0].data
    assert intervals[0]["difference"] is not None

    tag = client.tag.from_name("TM_day_Europe_Brussels")
    assert tag.calculate("1h", "end")[0]["end"] is not None


def test_current_value(user1):
    prefix = user1.unique_prefix
    # Current value tile only has identifier
    tag = user1.tag.from_name("TM_hour_Europe_Brussels")
    db = user1.dashboard(
        tiles=[
            user1.dashboard.values(
                content=[
                    user1.dashboard.values.entry(component=tag, color="blue"),
                ],
                x=0, y=0,
            )
        ],
        name=prefix,
    )

    db.save()
    db = user1.dashboard.from_identifier(db.identifier)
    assert db.tiles[0].content[0].component.name == tag.name
    db.delete()


def test_from_name_only(user1):
    # Only used in PI AF browsing; test explicitly
    tag = user1.tag.from_name("TM_hour_Europe_Brussels")
    assert user1.tag._from_json_name_only(tag.name)._interpolation_payload_str
    assert user1.tag._from_json_name_only(tag.name).identifier == tag.identifier
