from pprint import pprint
import pandas as pd


def test_vbs(client, user1, af_name):

    prefix = user1.unique_prefix

    hour = client.tag.from_name("TM_hour_Europe_Brussels")
    vbs = client.search.value(
        queries=[
            (hour, ">", 10),
            (hour, "<", 24)
        ]
    )
    assert isinstance(vbs.tags, list), "tags attribute should be a list"

    user1.search.value(
        queries=[("TM_day_Europe_Brussels", "constant")]
    ).__repr__()

    vbs.get_results(interval="24h")

    vbs = client.search.value(
        queries=("TM_day_Europe_Brussels", "=", ["Monday", "Friday"]),
        duration="15m")
    vbs.get_results(interval="7d")

    vbs = user1.search.value(
        queries=[
            "TM_hour_Europe_Brussels constant",
            "TM_hour_Europe_Brussels > 20",
            "TM_day_Europe_Brussels = Friday",
        ],
        duration=3000,
        calculations={
            "test1": (hour, "mean"),
            "test2": (f"{af_name}/Houston/Time/hour", "max", "-"),
            "test3": ("TM_year_Europe_Brussels", "mean", "y"),
            "test4": ("TM_day_Europe_Brussels", "start"),
        }
    )

    for query in vbs.queries:
        assert query.__repr__()
        assert query.__repr__()

    results = vbs.get_results(
        interval="7d",
        excluded_intervals=["1d"]
    )
    assert len(results) > 0

    vbs.name = prefix
    vbs.save()

    assert len(user1.search._get(vbs.identifier).get_results("7d")) > 0
    assert len(user1.search._get(vbs.name).get_results("7d")) > 0

    vbs = user1.search.value.from_identifier(vbs.identifier)
    assert vbs

    vbs.description = prefix
    folder = user1.folder.from_path(prefix, create_new=True)
    vbs.parent = folder
    vbs.update()

    assert user1.search.value.search(ref=vbs.name)
    assert user1.search.value.from_path(f"{prefix}/{prefix}")

    vbs.delete()
    folder.delete()


def test_digital_calc(user1):
    calculations = {
        "test": ("TM_day_Europe_Brussels", "start"),
    }

    uvbs = user1.search.value(
        queries=["TM_hour_Europe_Brussels = 1"],
        calculations=calculations,
    )
    pprint(uvbs.get_results("7d"))

    cvbs = user1.search.value(
        queries=["TM_day_Europe_Brussels constant"],
        calculations=calculations,
    )
    pprint(cvbs.get_results("7d"))


def test_simsearch(user1):

    prefix = user1.unique_prefix

    context_interval = user1.interval.from_timedelta("1w")
    excluded_intervals = [
        user1.interval.from_timedelta("1d"),
        user1.interval.from_timedelta("4d").before("1d")
    ]

    folder = user1.folder(prefix)
    folder.save()

    # Simple tag input; saving and loading
    threshold = 75
    search = user1.search.similarity(
        queries=["TM_hour_Europe_Brussels", "TM_year_Europe_Brussels"],
        interval="8h",
        name=f"{prefix}_tag",
        parent=folder,
        threshold=threshold,
        calculations={
            "avg": ("TM_hour_Europe_Brussels", "mean"),
            "stdev": ("TM_hour_Europe_Brussels", "stdev")
        }
    )

    assert len(search.tags) == 2

    results1 = search.get_results(
        interval=context_interval,
        excluded_intervals=excluded_intervals,
    )


    assert (results1["score"] >= threshold).all()

    search.save()
    search = user1.search.similarity.from_identifier(search.identifier)
    results2 = search.get_results(
        interval=context_interval,
        excluded_intervals=excluded_intervals,
    )

    assert len(results1) == len(results2)

    search.delete()

    # Search with more complex queries
    q1 = user1.search.similarity.query(
        source="TM_hour_Europe_Brussels",
        target="TM_hour_Asia_Calcutta",
        search_type="signal shape",
        weights=[(user1.interval.from_timedelta("1h"), 5)],
    )

    q2 = user1.search.similarity.query(
        source="TM_hour_Asia_Calcutta",
        target="TM_hour_Europe_Brussels",
        search_type="absolute values",
        weights=[(user1.interval.from_timedelta("2h"), 3)],
    )

    search = user1.search.similarity(
        queries=[q1, q2],
        interval="1d",
        name=f"{prefix}_queries",
        description="Search with complex queries",
        parent=folder,
        threshold=85,
    )

    results1 = search.get_results(interval=context_interval)

    search.save()

    assert folder.get_child_from_name(search.name)
    assert len(user1.search.similarity.search(ref=search.name)) > 0
    assert user1.search.similarity.from_path(f"{folder.name}/{search.name}")
    assert folder.get_children(included=[search.content_type])
    assert folder.get_child_from_name(search.name, included=[search.content_type])

    search = user1.search.similarity.from_name(search.name)
    results2 = search.get_results(interval=context_interval)
    assert len(results1) == len(results2)

    q3 = user1.search.similarity.query(
        source="TM_year_Europe_Brussels",
    )

    search.queries = search.queries + [q3]
    search.description = "new description"
    search.parent = None
    search.name = search.name + "_updated"
    search.calculations = {
        "avg": ("TM_hour_Europe_Brussels", "mean", "h"),
        "stdev": ("TM_hour_Europe_Brussels", "stdev")
    }
    search.threshold = 75
    search.update()

    assert search.__repr__()
    assert search.queries[0].__repr__()

    # Monitor tests
    monitor = user1.monitor.from_search(search)
    monitor.enabled = True
    monitor.update()

    assert len(user1.monitor.all(active_only=True)) > 0

    search = user1.monitor.from_identifier(monitor.identifier).search
    search.get_results(interval=context_interval)

    search = user1.monitor.from_name(search.name).search
    search.get_results(interval=context_interval)

    monitor.enabled = False
    monitor.update()
    folder.delete()
    search.delete()


def test_predict(client):

    tag = client.tag.from_name("tm_hour_Europe_Brussels")

    def predict():
        """Predict timeseries data based on the current profile"""

        # Index the tag
        tag.index()

        # Set focus chart interval; search in the last 5h
        focus_interval = client.interval.from_timedelta("5h")

        # Define search
        search = client.search.similarity(
            queries=[tag],
            interval=focus_interval,
            threshold=85,
        )

        # Get results; ignore the focus interval to not return self
        results = search.get_results(
            interval="1y",
            excluded_intervals=[focus_interval]
        )

        # Sort by the score
        results = results.sort_values("score", ascending=False)

        # Keep top 5 results only
        results = results.iloc[0:5]

        # Get data for the 2h after the search result; these make up the prediction
        data_list = []
        # FIXME
        for result in results:
            data = tag.get_data(result.after("2h"), resolution="1m")
            data.index = data.index - data.index[0] # relative index
            data_list.append(data)

        return pd.concat(data_list, axis=1, ignore_index=True)

    df = predict()
    assert not df.empty
