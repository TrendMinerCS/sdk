import pandas as pd
import json
from trendminer_interface.asset import Asset, Attribute


def test_roots(user1, af_name):
    assert user1.asset.roots()


def test_asset(user1, af_name):

    # Root
    assert user1.asset.roots()
    prefix = user1.unique_prefix

    # Asset get
    asset = user1.asset.from_path(f"{af_name}/Hasselt/Plant")
    assert user1.asset.from_identifier(asset.identifier)
    asset = user1.asset._get(f"{af_name}/Hasselt/Plant")
    assert asset.source
    assert asset.get_children()
    assert asset.parent
    assert asset.path

    # Attribute get
    assert user1.attribute.from_path(f"{af_name}/Hasselt/Time/Hour")
    assert user1.asset.from_identifier(asset.identifier)
    attribute = user1.attribute._get(f"{af_name}/Hasselt/Time/Hour")
    assert attribute.source
    assert attribute.tag
    assert attribute._interpolation_payload_str in ["LINEAR", "STEPPED"]
    assert attribute.tag.numeric
    assert json.dumps(attribute._json())

    assert isinstance(attribute.parent, Asset)
    assert attribute.path

    # Getting children
    asset = user1.asset.from_path(af_name)
    time_tags = (
        asset
        .get_child_from_name("Hasselt")
        .get_child_from_template("time tags")
    )
    assert time_tags.get_child_from_name("Year")
    assert time_tags.get_child_from_template("Year")

    # Retrieving from context items
    for component in [attribute, asset]:
        item = user1.context.item(
            context_type="INFORMATION",
            components=[component],
            events=[user1.now()],
        )

        item.save()

        item = user1.context.item.from_identifier(item.identifier)
        assert isinstance(item.components[0], type(component))

        item.delete()

    # Retrieving from current value tile
    db = user1.dashboard(
        name=prefix,
        tiles=[
            user1.dashboard.values(
                [user1.dashboard.values.entry(component=attribute)],
                x=0,
                y=0
            )
        ]
    )
    db.save()
    db = user1.dashboard.from_identifier(db.identifier)
    assert isinstance(db.tiles[0].content[0].component, Attribute)
    db.delete()

    # Asset search
    assert user1.asset.search(template="time tags")
    assert user1.asset.search(template="time tags", frameworks=[af_name])

    assert user1.asset.search(name="Hasselt")
    assert user1.asset.search(name="Hasselt", frameworks=af_name)

    assert user1.asset.search(description="US offices")
    assert user1.asset.search(description="US offices", frameworks=af_name)

    # Attribute search
    assert user1.attribute.search(name="day", frameworks=[af_name])
    assert user1.attribute.search(template="day", frameworks=af_name)
    assert user1.attribute.search(description="Product density", frameworks=[af_name])


def test_frameworks(admin, af_name):

    # Frameworks
    assert len(admin.asset.framework.all()) > 0
    af = admin.asset.framework.from_name(af_name)
    af = admin.asset.framework.from_identifier(af.identifier)
    af.export()
    assert af.edited is False
    assert af.get_root_asset()

    # Sync status
    assert len(admin.asset.framework.sync.all()) > 0
    assert af.sync.status == "DONE"
    assert af.sync.name
    assert af.sync.ended > af.sync.started
    assert af.af_type


def test_framework_create(admin, user1):

    prefix = admin.unique_prefix

    # Create
    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[
            ["", "/" + prefix, prefix, prefix, "ASSET", prefix, "", ""],
            ["", f"/{prefix}/attribute", "attribute", "a dummy attribute", "ATTRIBUTE", "dummy attribute template",
             "TM_hour_Europe_Brussels", ""]
        ],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.save()
    assert af.ordering
    af.wait_for_sync()
    af = admin.asset.framework.from_identifier(af.identifier)

    af.published = True
    af.update()

    af.export()
    af.df.loc[0, "description"] = "updated description"
    assert af.edited is True
    af.update()

    # Access rights
    asset = af.get_root_asset()

    asset.access.add(user1.username, "read")
    assert asset.access.all()
    assert asset.get_children()[0].access_inherited.all()
    asset.access.remove(user1.username)
    assert not asset.access.all()

    asset.access.add(user1.username, "browse")
    assert asset.access.all()

    asset.access.add("everyone", "read")
    assert asset.access.all()

    asset.access.clear()
    assert not asset.access.all()

    # Retrieve without permissions
    asset_no_access = user1.asset.from_path_hex(asset.path_hex)

    # Test getting deleted attributes
    attribute = admin.attribute.from_path(f"{prefix}/{prefix}/attribute")
    item = admin.context.item(
        context_type="INFORMATION",
        components=[attribute],
        events=[admin.now()]
    )
    item.save()
    af.delete()
    assert admin.attribute.from_identifier(attribute.identifier)
    assert admin.context.item.from_identifier(item.identifier).components[0]
    item.delete()


def test_framework_errors(admin):

    prefix = admin.unique_prefix

    df = pd.DataFrame(
        columns=["id", "path", "name", "description", "type", "template", "tag", "source"],
        data=[["", "incorrect path", prefix, prefix, "ASSET", prefix, "", ""]],
    )
    af = admin.asset.framework(name=prefix, df=df)
    af.save()
    af.wait_for_sync()
    assert isinstance(af.get_errors(), pd.DataFrame)
    af.delete()


def test_from_trendhub_attribute(user1, af_name):

    prefix = user1.unique_prefix

    attribute = user1.attribute.from_path(f"{af_name}/Hasselt/Time/Hour")
    thv = user1.trend.view(
        layers=["8h"],
        entries=[attribute],
        name=prefix,
    )
    thv.save()

    thv = user1.trend.view.from_identifier(thv.identifier)
    assert thv.entries[0].source


def test_asset_framework_builder(admin):
    prefix = admin.unique_prefix

    year_bxl = admin.tag.from_name("TM_year_Europe_Brussels")
    year_lon = admin.tag.from_name("TM_year_Europe_London")
    temp = admin.tag.from_name("TM4-BP2-TEMP.1")
    level = admin.tag.from_name("TM4-BP2-LEVEL.1")

    af = admin.asset.framework(name=prefix)
    af.save()

    root = af.get_root_asset()

    line1 = admin.asset(name="Line 1", parent=root, description="production line 1")
    line1.save()

    reactor1 = admin.asset(name="Reactor 1", parent=line1)
    reactor1.save()

    attr_year = admin.attribute(name="year", parent=line1, tag=year_bxl)
    attr_year.save()

    attr_temp = admin.attribute(name="temperature", parent=reactor1, description="Reactor Temperature", tag=temp)
    attr_temp.save()

    attr_level = admin.attribute(name="level", parent=reactor1, description="Reactor Level", tag=level)
    attr_level.save()

    af.published=True
    af.update()

    line1.name = "Production Line 1"
    line1.update()

    attr_year.tag = year_lon
    attr_year.parent = reactor1
    attr_year.update()

    attr_level.delete()
    line1.delete()

    af.delete()