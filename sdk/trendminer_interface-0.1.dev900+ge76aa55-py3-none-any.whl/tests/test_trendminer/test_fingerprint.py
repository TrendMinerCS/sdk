def test_fingerprint(user1, af_name):
    search_interval = user1.interval("2023-01-01", "2023-01-02")
    prefix = user1.unique_prefix
    level_attr = user1.attribute.from_path(f"{af_name}/Hasselt/Plant/Line 2/Level")
    conc_tag = user1.tag.from_name("TM4-BP2-CONC.1")
    qual_tag = user1.tag.from_name("TM4-BP2-QUAL.1")

    vbs = user1.search.value(
        queries = [
            (qual_tag, "constant")
        ],
        duration="1h",
    )

    batches = vbs.get_results(
        interval=search_interval,
    )

    if len(batches) > 20:
        batches = batches[0:20]

    # Truncate all intervals to the shortest process interval
    min_duration = min([batch.duration for batch in batches])
    batches = [
        user1.interval(
            batch.start,
            batch.start + min_duration,
        )
        for batch in batches
    ]

    fp = user1.fingerprint(
        entries=[conc_tag.name, qual_tag, level_attr],
        layers=batches,
        name=prefix,
    )

    fp.save()
    assert user1.fingerprint.from_name(prefix)
    fp = user1.fingerprint.from_path(prefix)
    hulls = fp.get_hulls()
    threshold = 90
    fp_search = user1.search.fingerprint(
        hulls=hulls,
        threshold=threshold,
    )
    results = fp_search.get_results()
    for result in results:
        assert result["score"] >= threshold
    fp.delete()