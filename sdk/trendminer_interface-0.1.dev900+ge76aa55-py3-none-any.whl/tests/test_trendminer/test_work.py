import pytest


def test_folder(user1):
    prefix = user1.unique_prefix
    new_folder = user1.folder(name=prefix, parent=None)
    new_folder.save()
    new_folder.name = prefix + "_edited"
    new_folder.update()
    new_folder = user1.folder._get(new_folder.identifier)
    new_subfolder = user1.folder(name=prefix, parent=new_folder.identifier)
    new_subfolder.save()
    new_folder.delete()


def test_browse(user1, user2):
    prefix = user1.unique_prefix
    folder = user1.folder(name=prefix, parent=None)
    folder.save()
    assert user1.folder.root.get_children()
    chv = user1.context.view(name=prefix, filters=user1.context.filter.period('1h'), parent=folder)
    chv.save()
    chv.access.add(user2.user.from_client().name, "read")
    assert chv.identifier in [item.identifier for item in folder.get_children()]
    assert chv.identifier in [item.identifier for item in folder.get_children(included=chv.content_type)]
    folder.delete()
    with pytest.raises(ValueError):
        folder.get_children(excluded="non-existing-content-type")


def test_path(user1):
    prefix = user1.unique_prefix
    path = f"{prefix}_l1/{prefix}_l2/{prefix}_l3"
    user1.folder.from_path(path, create_new=True)
    folder = user1.folder._get(path)
    chv = user1.context.view(name=prefix, parent=folder, filters=user1.context.filter.period('1h'))
    chv.save()
    assert chv.identifier == user1.context.view._get(path + f"/{prefix}").identifier
    assert folder.parent
    main_folder = user1.folder._get(prefix + '_l1')
    assert main_folder.get_children(folders_only=True)
    main_folder.delete()


def test_search(user1):
    prefix = user1.unique_prefix
    assert len(user1.search.value.search(prefix)) == 0
    folder = user1.folder(prefix)
    folder.save()
    db = user1.dashboard(tiles=[], name=prefix, parent=folder)
    db.save()
    assert len(user1.dashboard.search(prefix)) == 1
    db.delete()
    folder.delete()
