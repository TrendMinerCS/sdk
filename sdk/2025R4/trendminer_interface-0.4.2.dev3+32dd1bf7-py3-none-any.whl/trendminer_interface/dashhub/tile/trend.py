from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import HasOptions
from trendminer_interface.trendhub import TrendHubView, TrendHubViewFactory

from .base import (
    DraftTileFactoryBase,
    TileBase,
    TileConfigurationBase,
    TileFactoryBase,
    TilePosition,
)

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class TrendHubViewTileConfiguration(TileConfigurationBase):
    """Configuration for TrendHub view tile"""

    def __init__(
        self,
        show_title: bool,
        show_context_items: bool,
        show_timeframe: bool,
        show_labels: bool,
        show_colored_points_legend: bool,
    ):
        self.show_title = show_title
        self.show_context_items = show_context_items
        self.show_timeframe = show_timeframe
        self.show_colored_points_legend = show_colored_points_legend
        self.show_labels = show_labels

    def _json(self) -> dict:
        return {
            "showTitle": self.show_title,
            "showContextItems": self.show_context_items,
            "showTimeFrame": self.show_timeframe,
            "showColoredPointsLegend": self.show_colored_points_legend,
            "showDataReferenceLabels": self.show_labels,
        }

    @classmethod
    def _from_json(cls, data: dict) -> TrendHubViewTileConfiguration:
        return cls(
            show_title=data.get("showTitle", True),
            show_context_items=data.get("showContextItems", True),
            show_timeframe=data.get("showTimeFrame", True),
            show_labels=data.get("showDataReferenceLabels", True),
            show_colored_points_legend=data.get("showColoredPointsLegend", True),
        )


class DraftTrendHubViewTile(TileBase[TrendHubViewTileConfiguration]):
    """A TrendHub view tile without a view assigned

    This tile cannot be instantiated using the SDK, but it is possibly returned from a saved dashboard.
    """

    visualization_type = "DRAFT_TREND_HUB_VIEW"
    _config_type = TrendHubViewTileConfiguration

    def _json_content(self) -> dict:
        return {}


class TrendHubViewTile(TileBase[TrendHubViewTileConfiguration]):
    """TrendHub view dashboard tile

    Attributes
    ----------
    view : TrendHubView
        The TrendHub view displayed in the tile
    mode : str
        Display mode of the tile. Options: "PLOT", "STATISTICS_TABLE"
    visualization_type : str
        The visualization type of the tile
    """

    visualization_type = "TREND_HUB_VIEW"
    mode: str = HasOptions(["PLOT", "STATISTICS_TABLE"])
    _config_type = TrendHubViewTileConfiguration

    def __init__(
        self,
        client: TrendMinerClient,
        position: TilePosition,
        view: TrendHubView,
        mode: str,
        title: str,
        refresh_rate: pd.Timedelta | str,
        config: TrendHubViewTileConfiguration,
    ):
        super().__init__(
            client=client,
            position=position,
            title=title,
            refresh_rate=refresh_rate,
            config=config,
        )
        self.view = view
        self.mode = mode

    def _json_content(self) -> dict:
        return {
            "trendViewId": self.view.identifier,
            "displayMode": self.mode,
        }


class TrendHubViewTileFactory(
    TileFactoryBase[TrendHubViewTile, TrendHubViewTileConfiguration]
):
    tm_class = TrendHubViewTile

    def __call__(
        self,
        position: TilePosition | tuple[int, int, int, int],
        view: TrendHubView,
        mode: str = "PLOT",
        title: str = "",
        refresh_rate: pd.Timedelta | str = "5m",
        config: TrendHubViewTileConfiguration | None = None,
    ) -> TrendHubViewTile:
        """Instantiate a new TrendHub view tile

        Parameters
        ----------
        position : TilePosition or tuple[int, int, int, int]
            Position of the tile on the dashboard (x, y, width, height)
        view : TrendHubView
            TrendHub view to display in the tile
        mode : str, optional
            Display mode of the tile. Options: "PLOT", "STATISTICS_TABLE", by default "PLOT"
        title : str, optional
            Title of the tile, by default ""
        refresh_rate : pd.Timedelta or str, optional
            Refresh rate of the tile, by default "5m"
        config : TrendHubViewTileConfiguration, optional
            Configuration of the tile. If None, default configuration is used.

        Returns
        -------
        TrendHubViewTile
        """
        return self.tm_class(
            client=self.client,
            position=position,
            view=view,
            mode=mode,
            title=title,
            refresh_rate=refresh_rate,
            config=config or self.config(),
        )

    def _from_json(self, data: dict) -> TrendHubViewTile:
        return self.tm_class(
            client=self.client,
            position=TilePosition._from_json(data),
            view=TrendHubViewFactory(client=self.client)._from_json_identifier_only(
                data["configuration"]["trendViewId"]
            ),
            mode=data["configuration"].get(
                "displayMode", "PLOT"
            ),  # can be absent in old dashboards
            title=data["title"],
            refresh_rate=pd.Timedelta(seconds=data["refreshRate"]),
            config=TrendHubViewTileConfiguration._from_json(data["configuration"]),
        )

    @staticmethod
    def config(
        show_title: bool = True,
        show_context_items: bool = True,
        show_timeframe: bool = True,
        show_labels: bool = True,
        show_colored_points_legend: bool = True,
    ) -> TrendHubViewTileConfiguration:
        """Default configuration for TrendHub view tiles

        Parameters
        ----------
        show_title : bool, optional
            Whether to show the tile title, by default True
        show_context_items : bool, optional
            Whether to show context items, by default True
        show_timeframe : bool, optional
            Whether to show the timeframe, by default True
        show_labels : bool, optional
            Whether to show data reference labels, by default True
        show_colored_points_legend : bool, optional
            Whether to show the colored points legend, by default True

        Returns
        -------
        TrendHubViewTileConfiguration
        """
        return TrendHubViewTileConfiguration(
            show_title=show_title,
            show_context_items=show_context_items,
            show_timeframe=show_timeframe,
            show_labels=show_labels,
            show_colored_points_legend=show_colored_points_legend,
        )


class DraftTrendHubViewTileFactory(
    DraftTileFactoryBase[DraftTrendHubViewTile, TrendHubViewTileConfiguration]
):
    """Factory for creating draft TrendHub view tiles"""

    tm_class = DraftTrendHubViewTile
