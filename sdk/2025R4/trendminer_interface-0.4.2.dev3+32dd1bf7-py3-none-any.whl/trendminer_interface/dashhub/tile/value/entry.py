from trendminer_interface.asset import Attribute
from trendminer_interface.base import FactoryBase, SerializableBase
from trendminer_interface.component_factory import ComponentMultiFactory
from trendminer_interface.descriptors import ByFactory, FromTupleList
from trendminer_interface.tag import Tag

from .condition import CurrentValueCondition


class CurrentValueEntry(SerializableBase):
    """Current value tile entry

    Attributes
    ----------
    component : Tag or Attribute
        Time-series component giving the current value
    color : str
        The default color if no condition is triggered
    conditions : list of CurrentValueCondition
        Conditions for the color of the tile
    """

    component: Tag | Attribute = ByFactory(ComponentMultiFactory)
    conditions: list[CurrentValueCondition] = FromTupleList(CurrentValueCondition)

    def __init__(self, client, component, color, conditions):
        SerializableBase.__init__(self, client=client)
        self.color = color  # Unconditioned color
        self.component = component
        self.conditions = conditions

    def _json(self) -> dict:
        return {
            "componentIdentifier": self.component.identifier,
            "conditions": [
                {
                    "color": self.color,
                    "values": [],
                }
            ]
            + [condition._json() for condition in self.conditions],
            "identifier": self.component.identifier,
            "path": None
            if isinstance(self.component, Tag)
            else self.component.path_hex,
            "type": self.component.component_type,
        }


class CurrentValueEntryFactory(FactoryBase):
    """Factory for instantiating and retrieving current value entries"""

    tm_class = CurrentValueEntry

    def __call__(
        self,
        component: Tag | Attribute,
        color: str = "#005EB8",
        conditions: list[
            CurrentValueCondition | tuple[str, float | str | tuple[float, float], str]
        ]
        | None = None,
    ) -> CurrentValueEntry:
        """Instantiate a new current value tile entry

        Parameters
        ----------
        component : Tag or Attribute
            Time-series component giving the current value
        color : str, optional
            Default tag color when no condition is triggered, by default "#005EB8"
        conditions : list of CurrentValueCondition or list of tuple, optional
            Conditional coloring criteria for the tile. Each tuple should contain
            (condition, value, color), by default None

        Returns
        -------
        CurrentValueEntry
        """
        return self.tm_class(
            client=self.client,
            component=component,
            color=color,
            conditions=conditions if conditions else [],
        )

    def _from_json(self, data: dict) -> CurrentValueEntry:
        """Response json to instance

        Parameters
        ----------
        data : dict
            Response json

        Returns
        -------
        CurrentValueEntry
        """

        # conditions can be absent when the entry is broken
        if "conditions" in data:
            # unconditioned maps to entry color, not to a separate condition
            color = data["conditions"][0]["color"]
            conditions = data["conditions"][1:]  # Real conditions start from index 1
        else:
            color = "#005EB8"  # Default placeholder value
            conditions = []

        return self.tm_class(
            client=self.client,
            component=ComponentMultiFactory(
                client=self.client
            )._from_json_current_value_tile(data),
            color=color,
            conditions=[
                CurrentValueCondition._from_json(condition) for condition in conditions
            ],
        )

    @staticmethod
    def condition(
        condition: str,
        value: float | str | tuple[float, float],
        color: str,
    ) -> CurrentValueCondition:
        """Instantiate a new current value tile entry condition

        Parameters
        ----------
        condition : str
            "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO", "EQUAL_TO",
            "NOT_EQUAL_TO", "BETWEEN", "NOT_BETWEEN", "CONTAINS" or "DOES_NOT_CONTAIN". Also accepts numeric operators
            such as ">=".
        value : float, str or tuple of float
            Value(s) for the condition
        color : str
            Tag color for the condition (e.g., "#0075DC")

        Returns
        -------
        CurrentValueCondition
        """
        return CurrentValueCondition(
            condition=condition,
            value=value,
            color=color,
        )
