from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import pandas as pd

    from trendminer_interface.fingerprint import Fingerprint
    from trendminer_interface.search import SimilaritySearch, ValueBasedSearch

    from .notification import (
        ContextItemMonitorNotification,
        EmailMonitorNotification,
        WebhookMonitorNotification,
    )


@runtime_checkable
class Monitor(Protocol):
    """TrendMiner monitor

    Attributes
    ----------
    identifier : int
        Monitor identifier. Not a UUID, just simple sequential numbering.
    name : str
        Name of the monitor.
    created : pd.Timestamp | None
        Timestamp when the monitor was created.
    last_modified : pd.Timestamp | None
        Timestamp when the monitor was last modified.
    parent : ValueBasedSearch | SimilaritySearch | Fingerprint
        The search or fingerprint object that this monitor is based on.
    state : str
        Current state of the monitor. Options: "ENABLED", "DISABLED", "SYSTEM_DISABLED". Not intended to be set directly
        by the user; use `enable()` and `disable()` methods instead.
    fingerprint_trigger : ValueBasedSearch | None
        Optional search that triggers fingerprint-based monitoring.
    fingerprint_threshold : float | None
        Threshold value for fingerprint deviation monitoring.
    webhook : WebhookMonitorNotification
        Webhook notification configuration for this monitor.
    email : EmailMonitorNotification
        Email notification configuration for this monitor.
    context : ContextItemMonitorNotification
        Context item notification configuration for this monitor.

    """

    identifier: str
    parent: (
        ValueBasedSearch | SimilaritySearch | Fingerprint
    )  # TODO: other search types
    name: str
    state: str

    created: pd.Timestamp | None
    last_modified: pd.Timestamp | None

    fingerprint_trigger: (
        ValueBasedSearch | SimilaritySearch | Fingerprint | None
    )  # TODO: other search types
    fingerprint_threshold: float | None

    webhook: WebhookMonitorNotification
    email: EmailMonitorNotification
    context: ContextItemMonitorNotification

    # TODO: rename to save later
    def update(self) -> None: ...

    def enable(self) -> None:
        """Enable the monitor

        Notes
        -----
        does not update the attributes of the current monitor instance (e.g. `state`)
        """
        ...

    def disable(self) -> None:
        """Disable the monitor

        Notes
        -----
        does not update the attributes of the current monitor instance (e.g. `state`)
        """
        ...

    def __repr__(self) -> str: ...

    # TODO: implement on abstract base class later
    def __hash__(self) -> int: ...

    # TODO: implement on abstract base class later
    def __eq__(self, other) -> bool: ...
