from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import pandas as pd

    from trendminer_interface.component.asset import Asset
    from trendminer_interface.component.attribute import Attribute
    from trendminer_interface.component.tag import Tag
    from trendminer_interface.context_type.context_type import ContextType


class ContextItemMonitorNotification(Protocol):
    """Context item monitor notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : datetime
        What time the notification was enabled
    context_type : ContextType, optional
        The context item type
    component : Tag or Attribute or Asset, optional
        The component the item will be attached to
    description : str, optional
        The context item description
    fields : dict, optional
        The context item fields
    keywords : list of str, optional
        The keywords attached to the context item
    """

    enabled: bool
    enabled_at: pd.Timestamp | None
    context_type: ContextType | None
    component: Tag | Attribute | Asset | None
    description: str
    fields: dict[str, str | float]
    keywords: list[str]
