from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import pandas as pd


class WebhookMonitorNotification(Protocol):
    """Monitor webhook notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : datetime
        What time the notification was enabled
    url : str
        The webhook URL
    """

    enabled: bool
    enabled_at: pd.Timestamp | None
    url: str
