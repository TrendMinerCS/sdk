from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import pandas as pd


class EmailMonitorNotification(Protocol):
    """Monitor email notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : datetime
        What time the notification was enabled
    subject : str
        The email subject
    message : str
        The email message body
    to : list of str
        The email recipients
    """

    enabled: bool | None
    enabled_at: pd.Timestamp | None
    subject: str | None
    message: str | None
    to: list[str]
