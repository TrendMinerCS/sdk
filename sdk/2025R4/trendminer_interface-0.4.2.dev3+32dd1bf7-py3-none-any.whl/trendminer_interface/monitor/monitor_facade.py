from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import pandas as pd

    from trendminer_interface.user import User

    from .monitor import Monitor


# TODO: get_overview per monitor
class MonitorFacade(Protocol):
    """Facade for retrieving monitors

    Notes
    -----
    Retrieving a monitor by name is not supported. You must first retrieve the search or fingerprint by its name, and
    then call `get_monitor` on that object.

    """

    def from_identifier(self, identifier: int) -> Monitor:
        """Retrieve monitor from identifier

        Parameters
        ----------
        identifier : int
            Monitor identifier

        Returns
        -------
        _Monitor
        """
        ...

    # TODO: fix test
    def get_overview(self, since: pd.Timestamp | str | None = None) -> pd.DataFrame:
        """Get an overview of the number of hits for all active monitors

        Parameters
        ----------
        since : pandas.Timestamp or str, optional
            The start date from when to count the number of monitor results (up to the current date).

        Returns
        -------
        pandas.DataFrame
            DataFrame with columns 'monitor' and 'number_of_results'
        """
        ...

    def all(self, user: User | None = None, active_only: bool = True) -> list[Monitor]:
        """Retrieve all monitors

        Parameters
        ----------
        user : User, optional
            User for which to retrieve the monitors. If not provided, monitors for the currently authenticated user are
            retrieved.
        active_only : bool, default True
            Whether only the currently active monitors need to be retrieved, otherwise a monitor is retrieved for every
            search that is implemented in the SDK.

        Returns
        -------
        list of Monitor
            List of Monitor instances
        """
        ...
