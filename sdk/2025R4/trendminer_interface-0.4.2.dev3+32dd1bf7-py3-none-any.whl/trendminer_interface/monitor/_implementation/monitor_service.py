from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.base import LazyAttribute
from trendminer_interface.fingerprint import Fingerprint
from trendminer_interface.search import SimilaritySearch, ValueBasedSearch

from .monitor import _Monitor
from .notifications import (
    WebhookMonitorNotification,
    _ContextItemMonitorNotification,
    _EmailMonitorNotification,
)

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class _MonitorService:
    """Service for monitor operations

    This service handles serialization, deserialization, and CRUD operations for monitors.
    It manages the interaction between Monitor objects and the TrendMiner API.
    """

    def __init__(self, client: TrendMinerClient):
        self._client = client

    @staticmethod
    def _serialize_webhook_notification(
        notification: WebhookMonitorNotification,
    ) -> dict:
        """Serialize webhook notification to API format

        Parameters
        ----------
        notification : WebhookMonitorNotification
            The webhook notification to serialize

        Returns
        -------
        dict
            Serialized notification data
        """
        return {
            "enabled": notification.enabled,
            "url": notification.url,
        }

    def _deserialize_webhook_notification(
        self, data: dict
    ) -> WebhookMonitorNotification:
        """Deserialize webhook notification from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        WebhookMonitorNotification
            Deserialized webhook notification
        """
        return WebhookMonitorNotification(
            client=self._client,
            enabled=data["enabled"],
            enabled_at=data.get("enabledAt"),
            url=data["url"],
        )

    @staticmethod
    def _serialize_email_notification(notification: _EmailMonitorNotification) -> dict:
        """Serialize email notification to API format

        Parameters
        ----------
        notification : _EmailMonitorNotification
            The email notification to serialize

        Returns
        -------
        dict
            Serialized notification data
        """
        return {
            "enabled": notification.enabled,
            "subject": notification.subject,
            "message": notification.message,
            "to": ",".join(notification.to),
        }

    def _deserialize_email_notification(self, data: dict) -> _EmailMonitorNotification:
        """Deserialize email notification from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        _EmailMonitorNotification
            Deserialized email notification
        """
        to = data["to"]
        to = to.split(",") if to is not None else []
        return _EmailMonitorNotification(
            client=self._client,
            enabled=data["enabled"],
            enabled_at=data.get("enabledAt"),
            subject=data["subject"],
            message=data["message"],
            to=to,
        )

    @staticmethod
    def _serialize_context_notification(
        notification: _ContextItemMonitorNotification,
    ) -> dict:
        """Serialize context item notification to API format

        Parameters
        ----------
        notification : _ContextItemMonitorNotification
            The context item notification to serialize

        Returns
        -------
        dict
            Serialized notification data
        """
        return {
            "enabled": notification.enabled,
            "componentReference": notification.component.identifier
            if notification.component
            else None,
            "componentType": notification.component.component_type
            if notification.component
            else None,
            "description": notification.description,
            "fields": notification.fields,
            "keywords": notification.keywords,
            "type": notification.context_type.key
            if notification.context_type
            else None,
        }

    def _deserialize_context_notification(
        self, data: dict
    ) -> _ContextItemMonitorNotification:
        """Deserialize context item notification from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        _ContextItemMonitorNotification
            Deserialized context item notification
        """
        return _ContextItemMonitorNotification(
            client=self._client,
            enabled=data["enabled"],
            enabled_at=data.get("enabledAt"),
            context_type=data["type"],
            component=data["componentReference"],
            fields=data["fields"],
            keywords=data["keywords"],
            description=data["description"],
        )

    @staticmethod
    def _serialize_fingerprint_trigger(
        trigger: ValueBasedSearch | SimilaritySearch | Fingerprint,
    ):
        """Serialize fingerprint trigger to API format

        Parameters
        ----------
        trigger : ValueBasedSearch or SimilaritySearch or Fingerprint
            The fingerprint trigger to serialize

        Returns
        -------
        dict
            Serialized trigger data with type and id fields
        """

        if isinstance(trigger, ValueBasedSearch):
            return {
                "type": "valuebased",
                "id": trigger.identifier_complex,
            }
        elif isinstance(trigger, SimilaritySearch):
            return {
                "type": "similarity",
                "id": trigger.identifier_complex,
            }
        elif isinstance(trigger, Fingerprint):
            return {
                "type": "fingerprint",
                "id": trigger.identifier,
            }
        else:
            # TODO: add other search types
            raise NotImplementedError(
                f"Serialization of fingerprint trigger type '{type(trigger)}' is not implemented."
            )

    def _deserialize_fingerprint_trigger(
        self, data: dict
    ) -> ValueBasedSearch | SimilaritySearch | Fingerprint:
        """Deserialize fingerprint trigger from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        ValueBasedSearch or SimilaritySearch or Fingerprint
            Deserialized fingerprint trigger
        """
        trigger_type = data["type"]
        match trigger_type:
            case "valuebased":
                return self._deserialize_value_based_search({"searchId": data["id"]})
            case "similarity":
                return self._deserialize_similarity_search({"searchId": data["id"]})
            case "fingerprint":
                return self._deserialize_fingerprint({"searchId": data["id"]})
            case _:
                raise NotImplementedError(
                    f"Deserialization of fingerprint trigger type '{trigger_type}' is not implemented."
                )

    @classmethod
    def _serialize_monitor(cls, monitor: _Monitor) -> dict:
        """Serialize monitor to API format

        Parameters
        ----------
        monitor : _Monitor
            The monitor to serialize

        Returns
        -------
        dict
            Serialized monitor data
        """
        enabled = monitor.state == "ENABLED"

        data = {
            "enabled": enabled,
            "id": monitor.identifier,
            "isMonitoringPatternDependency": monitor._monitor_dependency,
            "name": monitor.name,
            "state": monitor.state,
            "username": monitor.parent.owner.name,
            "contextItemNotification": cls._serialize_context_notification(
                monitor.context
            ),
            "emailNotification": cls._serialize_email_notification(monitor.email),
            "webhookNotification": cls._serialize_webhook_notification(monitor.webhook),
        }

        if isinstance(monitor.parent, Fingerprint):
            data["type"] = "fingerprint"
            data["searchId"] = (
                monitor.parent.identifier
            )  # Fingerprint uses regular identifier
            data["fingerprintDetectionThreshold"] = monitor.fingerprint_threshold
            if monitor.fingerprint_trigger is None:
                data["matchType"] = "match"
            else:
                data["matchType"] = "mismatch"
                data["monitorTrigger"] = cls._serialize_fingerprint_trigger(
                    monitor.fingerprint_trigger
                )

        elif isinstance(monitor.parent, ValueBasedSearch):
            data["type"] = "valuebased"
            data["searchId"] = monitor.parent.identifier_complex

        elif isinstance(monitor.parent, SimilaritySearch):
            data["type"] = "similarity"
            data["searchId"] = monitor.parent.identifier_complex

        # TODO: add other search types
        else:
            raise NotImplementedError(
                f"Serialization of monitor parent type '{type(monitor.parent)}' is not implemented."
            )

        return data

    def _deserialize_value_based_search(self, data: dict) -> ValueBasedSearch:
        """Deserialize value-based search from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        ValueBasedSearch
            Deserialized value-based search (may contain lazy attributes)
        """
        # Presence of some keys depends on the endpoint
        return ValueBasedSearch(
            client=self._client,
            identifier=LazyAttribute(),
            identifier_complex=data["searchId"],
            name=data.get("name", LazyAttribute()),
            description=LazyAttribute(),
            parent=LazyAttribute(),
            owner=LazyAttribute(),
            last_modified=LazyAttribute(),
            version=LazyAttribute(),
            queries=LazyAttribute(),
            calculations=LazyAttribute(),
            duration=LazyAttribute(),
            operator=LazyAttribute(),
        )

    def _deserialize_similarity_search(self, data: dict) -> SimilaritySearch:
        """Deserialize similarity search from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        SimilaritySearch
            Deserialized similarity search (may contain lazy attributes)
        """
        # Presence of some keys depends on the endpoint
        return SimilaritySearch(
            client=self._client,
            identifier=LazyAttribute(),
            identifier_complex=data["searchId"],
            name=data.get("name", LazyAttribute()),
            description=LazyAttribute(),
            parent=LazyAttribute(),
            owner=LazyAttribute(),
            last_modified=LazyAttribute(),
            version=LazyAttribute(),
            interval=LazyAttribute(),
            threshold=LazyAttribute(),
            queries=LazyAttribute(),
            calculations=LazyAttribute(),
        )

    def _deserialize_fingerprint(self, data: dict) -> Fingerprint:
        """Deserialize fingerprint from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        Fingerprint
            Deserialized fingerprint (may contain lazy attributes)
        """
        # Presence of some keys depends on the endpoint
        return Fingerprint(
            client=self._client,
            name=data.get("name", LazyAttribute()),
            description=data.get("description", LazyAttribute()),
            identifier=data["searchId"],
            parent=LazyAttribute(),
            owner=LazyAttribute(),
            last_modified=LazyAttribute(),
            version=LazyAttribute(),
            entries=LazyAttribute(),
            layers=LazyAttribute(),
            identifier_complex=data.get("complexId", LazyAttribute()),
            data_type=LazyAttribute(),
        )

    def _deserialize_parent(
        self, data: dict
    ) -> ValueBasedSearch | SimilaritySearch | Fingerprint:
        """Deserialize monitor parent (search or fingerprint) from API format

        Parameters
        ----------
        data : dict
            The API response data

        Returns
        -------
        ValueBasedSearch or SimilaritySearch or Fingerprint
            Deserialized parent object
        """
        parent_type = data["type"]
        match parent_type:
            case "valuebased":
                return self._deserialize_value_based_search(data)
            case "similarity":
                return self._deserialize_similarity_search(data)
            case "fingerprint":
                return self._deserialize_fingerprint(data)
            case _:
                raise NotImplementedError(
                    f"Deserialization of monitor parent type '{parent_type}' is not implemented."
                )

    def _deserialize_monitor_by_search_id(self, data: dict) -> _Monitor:
        """Deserialize monitor from API format (bySearchId endpoint)

        Parameters
        ----------
        data : dict
            The API response data from /hps/api/monitoring/bySearchId/{searchId}

        Returns
        -------
        _Monitor
            Deserialized monitor instance
        """
        # /hps/api/monitoring/bySearchId/{searchId}

        # For some arcane reason, webhookNotification is missing on newly created objects. The other notifications are
        # always present.
        webhook_data = data.get("webhookNotification", {"enabled": False, "url": ""})

        fingerprint_trigger = data.get("monitorTrigger")
        if fingerprint_trigger is not None:
            fingerprint_trigger = self._deserialize_fingerprint_trigger(
                fingerprint_trigger
            )

        return _Monitor(
            service=self,
            identifier=data["id"],
            name=data["name"],
            created=data["created"],
            last_modified=data["lastUpdatedDate"],
            parent=self._deserialize_parent(data),
            state=data["state"],
            fingerprint_trigger=None,  # FIXME: deserialize trigger
            fingerprint_threshold=data.get("fingerprintDetectionThreshold"),
            monitor_dependency=data["isMonitoringPatternDependency"],
            webhook=self._deserialize_webhook_notification(webhook_data),
            email=self._deserialize_email_notification(data["emailNotification"]),
            context=self._deserialize_context_notification(
                data["contextItemNotification"]
            ),
        )

    def _deserialize_monitor_by_id(self, data: dict) -> _Monitor:
        """Deserialize monitor from API format (by id endpoint)

        Parameters
        ----------
        data : dict
            The API response data from /hps/api/monitoring/{id}

        Returns
        -------
        _Monitor
            Deserialized monitor instance (may contain lazy attributes)
        """
        # /hps/api/monitoring/{id}

        # For some arcane reason, webhookNotification is missing on newly created objects. The other notifications are
        # always present.
        webhook_data = data.get("webhookNotification", {"enabled": False, "url": ""})

        fingerprint_trigger = data.get("monitorTrigger")
        if fingerprint_trigger is not None:
            fingerprint_trigger = self._deserialize_fingerprint_trigger(
                fingerprint_trigger
            )

        return _Monitor(
            service=self,
            identifier=data["id"],
            name=LazyAttribute(),
            created=data["created"],
            last_modified=data["lastUpdatedDate"],
            parent=self._deserialize_parent(data),
            state=data["state"],
            fingerprint_trigger=fingerprint_trigger,
            fingerprint_threshold=data.get("fingerprintDetectionThreshold"),
            monitor_dependency=LazyAttribute(),
            webhook=self._deserialize_webhook_notification(webhook_data),
            email=self._deserialize_email_notification(data["emailNotification"]),
            context=self._deserialize_context_notification(
                data["contextItemNotification"]
            ),
        )

    def _deserialize_monitor_from_overview(self, data: dict) -> _Monitor:
        """Deserialize monitor from API format (overview endpoint)

        Parameters
        ----------
        data : dict
            The API response data from /hps/api/monitoring (overview)

        Returns
        -------
        _Monitor
            Deserialized monitor instance (with many lazy attributes)
        """
        # /hps/api/monitoring (overview)
        return _Monitor(
            service=self,
            identifier=data["id"],
            name=data["name"],
            created=LazyAttribute(),
            last_modified=data["lastUpdatedDate"],
            parent=self._deserialize_parent(data),
            state=data["state"],
            fingerprint_trigger=LazyAttribute(),
            fingerprint_threshold=LazyAttribute(),
            monitor_dependency=LazyAttribute(),
            webhook=LazyAttribute(),
            email=LazyAttribute(),
            context=LazyAttribute(),
        )

    def from_identifier_only(self, identifier: int) -> _Monitor:
        """Create a monitor instance from identifier only (all attributes lazy)

        Parameters
        ----------
        identifier : int
            Monitor identifier

        Returns
        -------
        _Monitor
            Monitor instance with all attributes as lazy attributes
        """
        return _Monitor(
            service=self,
            identifier=identifier,
            name=LazyAttribute(),
            created=LazyAttribute(),
            last_modified=LazyAttribute(),
            parent=LazyAttribute(),
            state=LazyAttribute(),
            fingerprint_trigger=LazyAttribute(),
            fingerprint_threshold=LazyAttribute(),
            monitor_dependency=LazyAttribute(),
            webhook=LazyAttribute(),
            email=LazyAttribute(),
            context=LazyAttribute(),
        )

    def from_identifier(self, identifier: int) -> _Monitor:
        """Retrieve monitor from identifier

        Parameters
        ----------
        identifier : int
            _Monitor identifier

        Returns
        -------
        _Monitor
        """
        response = self._client.session.get(f"/hps/api/monitoring/{identifier}")
        return self._deserialize_monitor_by_id(response.json())

    def from_search_identifier(self, identifier: str) -> _Monitor:
        """Retrieve monitor from complex identifier (searchId)

        Parameters
        ----------
        identifier : str
            Search identifier of the monitor parent. For a search, this is the complex identifier UUID. For a
            fingerprint, this is simply the work organizer identifier UUID.

        Returns
        -------
        _Monitor
        """
        response = self._client.session.get(
            f"/hps/api/monitoring/bySearchId/{identifier}"
        )
        return self._deserialize_monitor_by_search_id(response.json())

    def update_monitor(self, monitor: _Monitor) -> None:
        """Update the monitor configuration on the server

        Parameters
        ----------
        monitor : _Monitor
            The monitor to update
        """
        self._client.session.put(
            f"/hps/api/monitoring/{monitor.identifier}",
            json=self._serialize_monitor(monitor),
        )

    def enable_monitor(self, monitor: _Monitor) -> None:
        """Enable the monitor

                Parameters
        e        ----------
                monitor : _Monitor
                    The monitor to enable
        """
        self._client.session.post(f"/hps/api/monitoring/status/{monitor.identifier}")

    def disable_monitor(self, monitor: _Monitor) -> None:
        """Disable the monitor

        Parameters
        ----------
        monitor : _Monitor
            The monitor to disable
        """
        self._client.session.delete(f"/hps/api/monitoring/status/{monitor.identifier}")

    def all(self, username: str | None = None, active_only=True) -> list[_Monitor]:
        """Retrieve all monitors

        Parameters
        ----------
        username : str, optional
            Username for which to retrieve the monitors. If not provided, monitors for the currently authenticated user
            are retrieved.
        active_only : bool, default True
            Whether only the currently active monitors need to be retrieved, otherwise a monitor is retrieved for every
            search that is implemented in the SDK.

        Returns
        -------
        list of _Monitor
            List of Monitor instances
        """
        params: dict = {
            "filterOnlyActiveMonitors": active_only,
            "doNotRetrieveTags": True,
        }
        if username is not None:
            params["username"] = username
        response = self._client.session.get("/hps/api/monitoring", params=params)
        return [
            self._deserialize_monitor_from_overview(item)
            for item in response.json()
            if item["type"]
            in [
                "valuebased",
                "similarity",
                "fingerprint",
            ]  # TODO: include other search types later
        ]

    def get_overview(self, since: pd.Timestamp | None):
        """Get an overview of the number of hits for all active monitors

        Parameters
        ----------
        since : pd.Timestamp, optional
            The start date from when to count the number of monitor results (up to the current date).

        Returns
        -------
        pd.DataFrame
            DataFrame with columns 'monitor' and 'number_of_results'
        """
        if since is None:
            params = {}
        else:
            if since.tz is None:
                raise ValueError("The 'since' parameter must be timezone-aware.")
            params = {"since": since.isoformat(timespec="milliseconds")}

        response = self._client.session.get(
            url="/hps/api/monitoring/overview", params=params
        )

        overview = response.json()["overview"]
        if overview:
            return (
                pd.DataFrame(overview)
                .rename(
                    columns={"id": "monitor", "numberOfResults": "number_of_results"}
                )
                .assign(
                    monitor=lambda df: df["monitor"].apply(self.from_identifier_only)
                )
            )
        else:
            return pd.DataFrame(columns=["monitor", "number_of_results"]).astype(
                {"monitor": object, "number_of_results": int}
            )
