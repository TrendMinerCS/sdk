from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.base import LazyLoadingMixin
from trendminer_interface.descriptors import AsTimestamp, HasOptions
from trendminer_interface.fingerprint import Fingerprint
from trendminer_interface.search import SimilaritySearch, ValueBasedSearch

from ..monitor import Monitor
from .notifications import (
    WebhookMonitorNotification,
    _ContextItemMonitorNotification,
    _EmailMonitorNotification,
)

if TYPE_CHECKING:
    from .monitor_service import _MonitorService


class _Monitor(Monitor, LazyLoadingMixin):
    """TrendMiner monitor

    Attributes
    ----------
    identifier : int
        Monitor identifier. Not a UUID, just simple sequential numbering.
    name : str
        Name of the monitor.
    created : pd.Timestamp, optional
        Timestamp when the monitor was created.
    last_modified : pd.Timestamp, optional
        Timestamp when the monitor was last modified.
    parent : ValueBasedSearch or SimilaritySearch or Fingerprint
        The search or fingerprint object that this monitor is based on.
    state : str
        Current state of the monitor. Options: "ENABLED", "DISABLED", "SYSTEM_DISABLED". Not intended to be set directly
        by the user; use `enable()` and `disable()` methods instead.
    fingerprint_trigger : ValueBasedSearch, optional
        Optional search that triggers fingerprint-based monitoring.
    fingerprint_threshold : float, optional
        Threshold value for fingerprint deviation monitoring.
    webhook : WebhookMonitorNotification
        Webhook notification configuration for this monitor.
    email : _EmailMonitorNotification
        Email notification configuration for this monitor.
    context : _ContextItemMonitorNotification
        Context item notification configuration for this monitor.
    """

    created: pd.Timestamp | None = AsTimestamp()
    last_modified: pd.Timestamp | None = AsTimestamp()
    state: str = HasOptions(["ENABLED", "DISABLED", "SYSTEM_DISABLED"])

    def __init__(
        self,
        service: _MonitorService,
        identifier: int,
        name: str,
        created: pd.Timestamp | str | None,
        last_modified: pd.Timestamp | str | None,
        parent: ValueBasedSearch | SimilaritySearch | Fingerprint,
        state: str,
        fingerprint_trigger: ValueBasedSearch | None,  # TODO: other searches possible?
        fingerprint_threshold: float | None,
        monitor_dependency: bool,  # is this monitor a trigger for another monitor (fingerprint deviation)
        webhook: WebhookMonitorNotification,
        email: _EmailMonitorNotification,
        context: _ContextItemMonitorNotification,
    ):
        self._service = service

        # TODO: descriptors currently expect public 'client' attribute. Fix later.
        self.client = service._client

        self.identifier = identifier
        self.parent = parent
        self.name = name
        self.state = state

        self.created = created
        self.last_modified = last_modified

        self.fingerprint_trigger = fingerprint_trigger
        self.fingerprint_threshold = fingerprint_threshold

        self.webhook = webhook
        self.email = email
        self.context = context

        self._monitor_dependency = monitor_dependency

    def update(self) -> None:
        """Update the monitor configuration on the server"""
        self._service.update_monitor(self)

    def enable(self) -> None:
        """Enable the monitor

        Notes
        -----
        does not update the attributes of the current monitor instance (e.g. `state`)
        """
        self._service.enable_monitor(self)

    def disable(self) -> None:
        """Disable the monitor

        Notes
        -----
        does not update the attributes of the current monitor instance (e.g. `state`)
        """
        self._service.disable_monitor(self)

    def _full_instance(self) -> _Monitor:
        if "parent" not in self.lazy:
            if isinstance(self.parent, Fingerprint):
                return self._service.from_search_identifier(self.parent.identifier)
            else:
                return self._service.from_search_identifier(
                    self.parent.identifier_complex
                )
        else:
            return self._service.from_identifier(self.identifier)

    def __str__(self):
        return self.name

    def __repr__(self):
        # TODO: structural handling of lazy representation
        if "name" in self.lazy:
            return "Monitor(<not loaded>)"
        return f"Monitor(name='{self.name}', parent={self._repr_lazy('parent')}, ...)"

    def __hash__(self):
        return hash((self.__class__, self.identifier))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.identifier == other.identifier
