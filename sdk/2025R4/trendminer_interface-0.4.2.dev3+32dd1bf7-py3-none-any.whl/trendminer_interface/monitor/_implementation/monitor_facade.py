from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from ..monitor_facade import MonitorFacade
from .monitor import _Monitor
from .monitor_service import _MonitorService

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient
    from trendminer_interface.user import User  # TODO: convert to _User


class _MonitorFacade(MonitorFacade):
    """Facade for retrieving monitors

    Notes
    -----
    Retrieving a monitor by name is not supported. You must first retrieve the search or fingerprint by its name, and
    then call `get_monitor` on that object.

    """

    def __init__(self, client: TrendMinerClient):
        self._client = client
        self._service = _MonitorService(client)

    def from_identifier(self, identifier: int) -> _Monitor:
        """Retrieve monitor from identifier

        Parameters
        ----------
        identifier : int
            Monitor identifier

        Returns
        -------
        _Monitor
        """
        return self._service.from_identifier(identifier)

    def get_overview(self, since: pd.Timestamp | str | None = None) -> pd.DataFrame:
        """Get an overview of the number of hits for all active monitors

        Parameters
        ----------
        since : pd.Timestamp or str, optional
            The start date from when to count the number of monitor results (up to the current date).

        Returns
        -------
        pd.DataFrame
            DataFrame with columns 'monitor' and 'number_of_results'
        """
        if since is not None:
            since = pd.Timestamp(since)
            if since.tz is None:
                since = since.tz_localize(self._client.tz)
        return self._service.get_overview(since=since)

    def all(self, user: User | None = None, active_only: bool = True) -> list[_Monitor]:
        """Retrieve all monitors

        Parameters
        ----------
        user : User, optional
            User for which to retrieve the monitors. If not provided, monitors for the currently authenticated user are
            retrieved.
        active_only : bool, default True
            Whether only the currently active monitors need to be retrieved, otherwise a monitor is retrieved for every
            search that is implemented in the SDK.

        Returns
        -------
        list of _Monitor
            List of Monitor instances
        """
        username = user.name if user is not None else None
        return self._service.all(username=username, active_only=active_only)
