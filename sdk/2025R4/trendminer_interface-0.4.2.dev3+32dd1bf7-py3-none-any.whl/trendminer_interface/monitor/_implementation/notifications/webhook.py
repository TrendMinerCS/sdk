from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import AsTimestamp

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class WebhookMonitorNotification:
    """Monitor webhook notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : pd.Timestamp, optional
        What time the notification was enabled
    url : str
        The webhook URL
    """

    enabled_at = AsTimestamp()

    def __init__(
        self,
        client: TrendMinerClient,
        enabled: bool,
        enabled_at: pd.Timestamp | None,
        url: str,
    ):
        self.client = client
        self.enabled = enabled
        self.enabled_at = enabled_at
        self.url = url

    def __repr__(self):
        return f"WebhookMonitorNotification(enabled={self.enabled}, url='{self.url}')"
