from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.component_factory import ComponentMultiFactory
from trendminer_interface.context import ContextTypeFactory
from trendminer_interface.descriptors import AsTimestamp, ByFactory

if TYPE_CHECKING:
    from trendminer_interface.asset import Asset, Attribute
    from trendminer_interface.client import TrendMinerClient
    from trendminer_interface.context import ContextType
    from trendminer_interface.tag import Tag


class _ContextItemMonitorNotification:
    """Context item monitor notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : pd.Timestamp, optional
        What time the notification was enabled
    context_type : ContextType, optional
        The context item type
    component : Tag or Attribute or Asset, optional
        The component the item will be attached to
    description : str
        The context item description
    fields : dict
        The context item fields
    keywords : list of str
        The keywords attached to the context item
    """

    enabled_at = AsTimestamp()
    context_type = ByFactory(ContextTypeFactory)
    component = ByFactory(ComponentMultiFactory)

    def __init__(
        self,
        client: TrendMinerClient,
        enabled: bool,
        enabled_at: pd.Timestamp | None,
        context_type: ContextType | None,
        component: Tag | Attribute | Asset | None,
        description: str,
        fields: dict[str, str | float],
        keywords: list[str],
    ):
        self.client = client
        self.enabled = enabled
        self.enabled_at = enabled_at
        self.context_type = context_type
        self.component = component
        self.description = description
        self.fields = fields
        self.keywords = keywords

    def __repr__(self):
        return f"ContextItemMonitorNotification(enabled={self.enabled}, context_type={self.context_type}, ...)"
