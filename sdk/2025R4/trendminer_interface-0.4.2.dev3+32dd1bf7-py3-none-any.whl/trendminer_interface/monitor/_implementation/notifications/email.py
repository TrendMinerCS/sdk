from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from trendminer_interface.descriptors import AsTimestamp

if TYPE_CHECKING:
    from trendminer_interface.client import TrendMinerClient


class _EmailMonitorNotification:
    """Monitor email notification

    Attributes
    ----------
    enabled : bool
        Whether the notification is enabled
    enabled_at : pd.Timestamp, optional
        What time the notification was enabled
    subject : str, optional
        The email subject
    message : str, optional
        The email message body
    to : list of str
        The email recipients
    """

    enabled_at = AsTimestamp()

    def __init__(
        self,
        client: TrendMinerClient,
        enabled: bool,
        enabled_at: pd.Timestamp | None,
        subject: str,
        message: str,
        to: list[str],
    ):
        self.client = client  # TODO: make private later (now used as public method by descriptors)
        self.enabled = enabled
        self.enabled_at = enabled_at
        self.subject = subject
        self.message = message
        self.to = to

    def __repr__(self):
        return f"EmailMonitorNotification(enabled={self.enabled}, subject='{self.subject}', ...)"
