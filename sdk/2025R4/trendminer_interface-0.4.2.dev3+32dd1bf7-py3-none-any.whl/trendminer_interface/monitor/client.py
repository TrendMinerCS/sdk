import abc

from ._implementation.monitor_facade import _MonitorFacade
from .monitor_facade import MonitorFacade


class MonitorClient(abc.ABC):
    """Monitor Client"""

    @property
    def monitor(self) -> MonitorFacade:
        """Facade for monitors

        Returns
        -------
        MonitorFacade
        """
        return _MonitorFacade(client=self)
