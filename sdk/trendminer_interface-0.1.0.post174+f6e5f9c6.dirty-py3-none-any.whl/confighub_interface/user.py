from trendminer_interface.base import FactoryBase, LazyAttribute
import trendminer_interface._input as ip
from .access import Member
from .constants import USER_GET_SIZE


class ConfigUserClient:
    @property
    def user(self):
        return ConfigUserFactory(client=self)


class ConfigUser(Member):
    """User details in ConfigHub

    Attributes
    ----------
    identifier: str, optional
        User UUID
    name: str
        Username
    first_name: str
        User first name
    last_name: str
        User last name
    mail: str
        User email
    identity_provider: str
        User identity provider
    local: bool
        Whether the user is local to TrendMiner (i.e., no external identity provider)
    locked: bool
        Whether the user is locked because of too many failed logins.
    roles: list of str, default ["default-roles-trendminer"]
        Roles assigned to the User
            - default-roles-trendminer: regular user rights. Always present.
            - tm_admin: application administrator
            - tm_system_admin: ConfigHub access
            - tm_shared_space_user: Special purpose shared access user. Cannot be combined with any admin roles.
    """
    endpoint = "/confighub/v2/users"
    member_type = "USER"

    def __init__(
            self,
            client,
            identifier,
            name,
            first_name,
            last_name,
            mail,
            identity_provider,
            local,
            locked,
            roles,
    ):
        super().__init__(client=client, identifier=identifier, name=name)
        self.first_name = first_name
        self.last_name = last_name
        self.mail = mail
        self.identity_provider = identity_provider
        self.local = local
        self.locked = locked
        self.roles = roles
        
    @property
    def path(self):
        return self.name.lower()  # user cannot be removed from group if not lowercase

    def _post_updates(self, response):
        self.identifier = response.json()["id"]

    def _json(self, password=None):
        return {
            "email": self.mail,
            "firstName": self.first_name,
            "id": self.identifier,
            "identityProvider": self.identity_provider,
            "isLocal": self.local,
            "isLocked": self.locked,
            "lastName": self.last_name,
            "username": self.name,
            "password": password,
            "roles": self.roles,
        }

    def save(self, password):
        self.identifier = None  # prevents accidental overwriting
        payload = self._json(password=password)
        response = self.client.session.post(self.endpoint, json=payload)
        self._post_updates(response)

    def update(self):
        payload = self._json(password=None)
        response = self.client.session.update(self.link, json=payload)
        self._put_updates(response)

    def set_password(self, password):
        url = f"{self.endpoint}/changepassword/{self.identifier}"
        self.client.session.update(url, data=password)

    def _full_instance(self):
        if self.identifier is None:
            return ConfigUserFactory(client=self.client).from_name(self.name)
        else:
            return ConfigUserFactory(client=self.client).from_identifier(self.identifier)


class ConfigUserFactory(FactoryBase):
    tm_class = ConfigUser

    def __call__(self, name, first_name, last_name, mail, roles=None):
        """Instantiate a new user in ConfigHub

        Parameters
        ----------
        name: str
            Username
        first_name: str
            User first name
        last_name: str
            User last name
        mail: str
            User email
        roles: list of str, default ["default-roles-trendminer"]
            Following role option strings exist:
            - `default-roles-trendminer`: regular user options, MUST be present in the list
            - `tm_admin`: application adminsistrator (index menu, context type, asset frameworks, ...)
            - `tm_system_admin`: System administrator (ConfigHub)
            - `tm_shared_space_user`: Shared space user; cannot be combined with an administrator role
        """
        roles = roles or ["default-roles-trendminer"]
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            first_name=first_name,
            last_name=last_name,
            mail=mail,
            identity_provider="local",
            local=True,
            locked=False,
            roles=roles,
        )

    def _from_json(self, data):
        """Response json to instance

        Attributes
        ----------
        data : dict
            response json

        Returns
        -------
        User
        """
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["username"],
            first_name=data["firstName"],
            last_name=data["lastName"],
            mail=data["email"],
            identity_provider=data["identityProvider"],
            local=data["isLocal"],
            locked=data["isLocked"],
            roles=data["roles"],
        )

    def _from_json_name_only(self, data):
        return self.tm_class(
            client=self.client,
            identifier=LazyAttribute(),
            name=data,
            first_name=LazyAttribute(),
            last_name=LazyAttribute(),
            mail=LazyAttribute(),
            identity_provider=LazyAttribute(),
            local=LazyAttribute(),
            locked=LazyAttribute(),
            roles=LazyAttribute(),
        )

    def _from_json_member_acl(self, data):
        return self._from_json_name_only(data["name"])

    def _from_json_member_group(self, data):
        return self.tm_class(
            client=self.client,
            identifier=data["id"],
            name=data["name"],
            first_name=data["properties"]["firstname"],
            last_name=data["properties"]["lastname"],
            mail=LazyAttribute(),
            identity_provider=LazyAttribute(),
            local=LazyAttribute(),
            locked=LazyAttribute(),
            roles=LazyAttribute(),
        )

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_name

    @property
    def _search_methods(self):
        return self.by_name,

    def by_name(self, ref):
        params = {
            "size": USER_GET_SIZE,
            "enabled": True,
            "searchPattern": ref,
        }
        content = self.client.session.paginated(keys=["content"], total=False).get("confighub/v2/users", params=params)
        return [self._from_json(user) for user in content]

    def from_name(self, ref):
        return ip.object_match_nocase(self.by_name(ref), "name", ref)

    def all(self):
        params = {"size": USER_GET_SIZE}
        content = self.client.session.paginated(keys=["content"]).get(self._endpoint, params=params)
        return [self._from_json(data) for data in content]
