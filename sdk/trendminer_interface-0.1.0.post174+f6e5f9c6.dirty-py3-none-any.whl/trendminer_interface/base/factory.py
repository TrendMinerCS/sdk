import abc
import functools
from typing import Any, Callable, Dict, List, Optional, Tuple, Union, TYPE_CHECKING

from collections.abc import MutableMapping
from requests.exceptions import HTTPError

from trendminer_interface import _input as ip
from trendminer_interface.exceptions import ResourceNotFound
from .lazy_loading import LazyAttribute
from .objects import AuthenticatableBase

if TYPE_CHECKING:
    from ..client import TrendMinerClient


class FactoryCoreBase(AuthenticatableBase, abc.ABC):
    """Superclass for all factories instantiating new methods
    
    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    """

    @property
    def _get_methods(self) -> Tuple[Callable[..., Any], ...]:
        """Methods to try to retrieve an instance from the appliance

        get methods always have the following syntax: `from_*`
        
        Returns
        -------
        Tuple[Callable[..., Any], ...]
            Tuple of methods that can retrieve instances
        """
        return ()

    @classmethod
    @abc.abstractmethod
    def _correct_class(cls, ref: Any) -> bool:
        """Check if input is already of the correct class
        
        Parameters
        ----------
        ref : Any
            Reference to check
            
        Returns
        -------
        bool
            True if ref is of the correct class
        """
        pass

    def _get(self, ref: Any) -> Any:
        """Get instance from any possible reference type

        Tries all methods in `_get_methods` in order to retrieve an instance from the appliance.

        The given input is simply returned if:
        - It is already an instance of the correct type
        - It is None
        - It is a LazyAttribute

        Parameters
        ----------
        ref : Any
            Reference by which a unique instance can be retrieved from the appliance

        Returns
        -------
        Any
            The instance pointed to by the given reference
            
        Raises
        ------
        ResourceNotFound
            If no matching instance can be found
        """

        if ref is None:
            return None

        if isinstance(ref, LazyAttribute):
            return ref

        # Ref is already of correct instance, return
        if self._correct_class(ref):
            return ref

        # Try all other implemented methods to return data
        for method in self._get_methods:
            try:
                return method(ref)
            except (ResourceNotFound, AttributeError, TypeError, ValueError):
                pass
            except HTTPError as err:
                if err.response.status_code not in [400, 404]:
                    raise err

        raise ResourceNotFound(f"No match for {ref} found")

    def _list(self, refs: Union[List[Any], Any]) -> Union[List[Any], LazyAttribute]:
        """Retrieves instances from list of references

        Uses the `get` method on every item in the given list.

        Parameters
        ----------
        refs : Union[List[Any], Any]
            list of references representing unique instances on the appliance. A single input is converted into a list
            of length 1.

        Returns
        -------
        Union[List[Any], LazyAttribute]
            List of instances retrieved from given references, or LazyAttribute if refs is a LazyAttribute
        """
        if isinstance(refs, LazyAttribute):
            return refs
        if refs is None:
            refs = []
        if isinstance(refs, (str, tuple, MutableMapping)) or self._correct_class(refs):
            refs = [refs]
        return [self._get(ref) for ref in refs]

    def _cache_key_ref(self, ref: Any = None) -> Tuple[int, Any]:
        """Cachetools key for methods with ref argument or without arguments

        Caching factory methods conventionally has no effect as new factory classes are created on the fly. The cache
        key for a method is thus set based on the client (as well as the input, of course). This key function can be
        used for caching methods where ref is the only input.

        Cache decorator should follow this syntax:
        `@cachetools.cached(..., key=TrendMinerFactory._cache_key_ref)`

        Parameters
        ----------
        ref : Any, optional
            Input to the cached method

        Returns
        -------
        Tuple[int, Any]
            Cache key tuple containing client hash and ref
        """

        # Handling for object inputs
        if isinstance(ref, AuthenticatableBase):
            ref = hash(ref)

        key = hash(self.client), ref

        return key


class FactoryBase(FactoryCoreBase, abc.ABC):
    """Superclass for all factories instantiating new methods
    
    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    tm_class : Type[Any]
        The class that this factory creates instances of
    """
    tm_class: Any = abc.abstractmethod(lambda: None)

    @property
    def _endpoint(self) -> Optional[str]:
        """Get the endpoint for this factory's class.
        
        Returns
        -------
        Optional[str]
            The endpoint URL for this resource type
            
        Notes
        -----
        TODO: remove endpoint concept. It does not universally apply. Just putting the url when doing the request is clearer.
        """
        return self.tm_class.endpoint

    @classmethod
    def _correct_class(cls, ref: Any) -> bool:
        """Check if input is already of the correct class
        
        Parameters
        ----------
        ref : Any
            Reference to check
            
        Returns
        -------
        bool
            True if ref is an instance of tm_class
        """
        return isinstance(ref, cls.tm_class)


def kwargs_to_class(method: Callable[..., Dict[str, Any]]) -> Callable[..., Any]:
    """Decorator function that handles turning keyword arguments into a TrendMiner class instance

    Intended to decorate _from_json* methods on TrendMiner Factory classes. Creates an instance in which attributes not
    provided through the output dict are turned into LazyAttribute instances. This shortens our code as we no longer
    explicitly need to set our lazy attributes. Also allows the addition of a `from_list` parameter which will iterate
    the base method to turn a list of inputs into a list of instances. Prevents us from having to use list comprehension
    in our methods.

    Parameters
    ----------
    method : Callable[..., Dict[str, Any]]
        Method turning json input into a dict of kwargs usable for creating a class instances

    Returns
    -------
    Callable[..., Any]
        Decorated method that returns a class instance
    """

    @functools.wraps(method)
    def inner(*args: Any, **kwargs: Any) -> Any:
        """Decorator inner function. Creates a class instance or list of class instances."""

        self = args[0]
        try:
            data = args[1]
        except IndexError:
            data = kwargs["data"]

        values = method(self, data)

        output = {
            kw: LazyAttribute(name=kw)
            for kw in self.tm_class.__init__.__code__.co_varnames
        }
        output.pop("self")
        output.update({"client": self.client, **values})
        return self.tm_class(**output)
    return inner
