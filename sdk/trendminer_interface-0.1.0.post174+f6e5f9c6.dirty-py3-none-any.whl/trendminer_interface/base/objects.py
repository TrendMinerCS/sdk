import abc
from copy import deepcopy
from typing import Any, Dict, Optional, TYPE_CHECKING

import posixpath

if TYPE_CHECKING:
    from ..client import TrendMinerClient


class AuthenticatableBase(abc.ABC):
    """Instances which store authentication to the TrendMiner server

    Parameters
    ----------
    client : TrendMinerClient
        Client providing link to the appliance

    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    """
    
    def __init__(self, client: "TrendMinerClient") -> None:
        """Initialize with TrendMiner client.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        """
        self.client = client

    def __repr__(self) -> str:
        """String representation of the instance.
        
        Returns
        -------
        str
            String representation in format "<< ClassName >>"
        """
        return f"<< {self.__class__.__name__} >>"


class SerializableBase(AuthenticatableBase, abc.ABC):
    """Instances which are json-serializable on the TrendMiner server

    Attributes
    ----------
    client : TrendMinerClient
        Client authenticated to send requests to the appliance
    """

    def __init__(self, client: "TrendMinerClient") -> None:
        """Initialize with TrendMiner client.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        """
        super().__init__(client)

    @abc.abstractmethod
    def _json(self) -> Dict[str, Any]:
        """JSON representation of the instance used to create and update objects on the appliance

        Returns
        -------
        Dict[str, Any]
            Instance JSON representation
        """
        pass

    def copy(self, attributes: Optional[Dict[str, Any]] = None) -> "SerializableBase":
        """Creates deepcopy of the instance, optionally replacing some attributes in the copied instance

        Parameters
        ----------
        attributes : Dict[str, Any], optional
            Instance attributes and what to replace them with in the copy as key-value pairs in a dict

        Returns
        -------
        SerializableBase
            Deepcopy of the instance, potentially with some attributes changed.
        """
        attributes = attributes or {}
        copy = deepcopy(self)
        copy.client = self.client  # client needs to be explicitly assigned, since client.session does not copy over
        for key, value in attributes.items():
            setattr(copy, key, value)
        return copy


class RetrievableBase(SerializableBase, abc.ABC):
    """TrendMiner instances which can be retrieved by a get request

    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    identifier : str
        Unique reference on the appliance
    endpoint : Optional[str]
        API endpoint for this resource type
    """
    endpoint: Optional[str] = None  # TODO: remove this concept

    def __init__(self, client: "TrendMinerClient", identifier: str) -> None:
        """Initialize with client and identifier.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        identifier : str
            Unique reference on the appliance
        """
        super().__init__(client=client)
        self.identifier = identifier

    @property
    def link(self) -> str:
        """Link to existing object.
        
        Returns
        -------
        str
            Full path to the object on the server
        """
        if self.endpoint is None:
            raise ValueError("endpoint must be set for this class")
        return posixpath.join(self.endpoint, self.identifier)


class EditableBase(RetrievableBase, abc.ABC):
    """Instances which can be saved to the TrendMiner server
    
    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    identifier : str
        Unique reference on the appliance
    endpoint : Optional[str]
        API endpoint for this resource type
    """

    def __init__(self, client: "TrendMinerClient", identifier: str) -> None:
        """Initialize with client and identifier.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        identifier : str
            Unique reference on the appliance
        """
        super().__init__(client=client, identifier=identifier)

    def _put_updates(self, response: Any) -> None:
        """Update some instance attributes from a put response.
        
        Parameters
        ----------
        response : Any
            Response object from PUT request
        """
        pass

    def _post_updates(self, response: Any) -> None:
        """Update instance attributes from a post response.
        
        Parameters
        ----------
        response : Any
            Response object from POST request
        """
        self.identifier = response.json()["identifier"]

    def _delete_updates(self, response: Any) -> None:
        """Update instance attributes from a delete response.
        
        Parameters
        ----------
        response : Any
            Response object from DELETE request
        """
        self.identifier = None  # type: ignore

    def save(self) -> None:
        """Creates this instance on the TrendMiner appliance."""
        self.identifier = None  # type: ignore  # reset identifier to avoid overwriting  # TODO: move pre-config to another method
        if self.endpoint is None:
            raise ValueError("endpoint must be set for this class")
        response = self.client.session.post(self.endpoint, json=self._json())
        self._post_updates(response)

    def update(self) -> None:
        """Updates the appliance object to match this instance."""
        response = self.client.session.put(self.link, json=self._json())
        self._put_updates(response)

    def delete(self) -> None:
        """Remove this instance from the appliance."""
        self.client.session.delete(self.link)
