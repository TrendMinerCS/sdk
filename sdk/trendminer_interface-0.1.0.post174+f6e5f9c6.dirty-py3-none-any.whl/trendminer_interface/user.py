import cachetools
import posixpath
import abc
from typing import Any, Callable, Dict, List, Optional, Tuple, TYPE_CHECKING

import pandas as pd

from .exceptions import FromJsonError
from . import _input as ip
from trendminer_interface.base import RetrievableBase, FactoryBase, LazyLoadingMixin, kwargs_to_class, AsTimestamp
from .constants import MAX_GET_SIZE, MAX_USER_CACHE

if TYPE_CHECKING:
    from .client import TrendMinerClient


class UserClient(abc.ABC):
    """Client for UserFactory"""
    @property
    def user(self) -> "UserFactory":
        """Factory for retrieving users

        Returns
        -------
        UserFactory
            Factory for creating and retrieving User instances
        """
        return UserFactory(client=self)


class User(RetrievableBase, LazyLoadingMixin):
    """A TrendMiner user or client user

    Attributes
    ----------
    client : TrendMinerClient
        Client providing link to the appliance
    identifier : str
        Unique user identifier
    name : str
        TrendMiner username. The username of client users is `service-account-{client id}`.
    first_name : Optional[str]
        Assigned first name
    last_name : Optional[str]
        Assigned last name
    roles : List[str]
        Roles assigned to the User
            - default-roles-trendminer: regular user rights. Always present, except for special Everyone-user.
            - tm_admin: application administrator
            - tm_system_admin: ConfigHub access
            - tm_shared_space_user: Special purpose shared access user. Cannot be combined with any admin roles.
    mail : Optional[str]
        User email
    created : Optional[pd.Timestamp]
        User creation time
    subject_type : str
        User subject type: `USER` for regular users, `EVERYONE` for special Everyone-user

    Notes
    -----
    A special Everyone-user exists which is used to give permissions to all users.
    """
    endpoint: str = f"/auth/realms/trendminer/local/users/"
    created: Any = AsTimestamp()

    def __init__(
        self,
        client: "TrendMinerClient",
        identifier: str,
        subject_type: str,
        name: str,
        roles: List[str],
        mail: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        created: Optional[pd.Timestamp],
    ) -> None:
        """Initialize a User instance.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        identifier : str
            Unique user identifier
        subject_type : str
            User subject type (USER or EVERYONE)
        name : str
            TrendMiner username
        roles : List[str]
            List of roles assigned to the user
        mail : Optional[str]
            User email address
        first_name : Optional[str]
            User's first name
        last_name : Optional[str]
            User's last name
        created : Optional[pd.Timestamp]
            User creation timestamp
        """
        RetrievableBase.__init__(self, client=client, identifier=identifier)
        self.name = name
        self.first_name = first_name
        self.last_name = last_name
        self.roles = roles
        self.mail = mail
        self.created = created
        self.subject_type = subject_type

    def _full_instance(self) -> "User":
        """Get the full instance with all attributes loaded.
        
        Returns
        -------
        User
            Full User instance with all attributes loaded
        """
        if "identifier" in self.lazy:
            return UserFactory(client=self.client).from_name(ref=self.name)
        else:
            return UserFactory(client=self.client).from_identifier(ref=self.identifier)

    def _json(self) -> Dict[str, Any]:
        """Get JSON representation of the user.
        
        Returns
        -------
        Dict[str, Any]
            User identifier as JSON representation
        """
        return {"identifier": self.identifier}

    def __str__(self) -> str:
        """String representation of the user.
        
        Returns
        -------
        str
            User name
        """
        return self.name

    def __repr__(self) -> str:
        """String representation for debugging.
        
        Returns
        -------
        str
            Debug representation of the user
        """
        return f"<< User | {self._repr_lazy('name')} >>"


class UserFactory(FactoryBase):
    """Factory for creating and retrieving User instances."""
    tm_class = User

    def __init__(self, client: "TrendMinerClient") -> None:
        """Initialize UserFactory with client.
        
        Parameters
        ----------
        client : TrendMinerClient
            Client providing link to the appliance
        """
        super().__init__(client)

    @property
    def everyone(self) -> User:
        """'Everyone' user needed to give all users permissions/access at once

        Returns
        -------
        User
            Pseudo-user representing all TrendMiner users
        """
        return self.tm_class(
            client=self.client,
            identifier="Everyone",
            subject_type="EVERYONE",
            name="Everyone",
            mail=None,
            roles=[],
            first_name=None,
            last_name=None,
            created=None,
        )

    @property
    def self(self) -> User:
        """Get the currently authenticated user

        Returns
        -------
        User
            The currently authenticated user
        """
        data = self.client.session.token_decoded
        return self.tm_class(
            client=self.client,
            identifier=data["sub"],
            subject_type="USER",
            name=data["preferred_username"],
            roles=data["roles"],
            mail=data.get("email"),
            first_name=data.get("given_name"),
            last_name=data.get("family_name"),
            created=pd.Timestamp(data["createdDate"]*1000000, tz="UTC").astimezone(self.client.tz),
        )

    def from_identifier(self, ref: str) -> User:
        """Retrieve a user from their identifier

        Parameters
        ----------
        ref : str
            User UUID

        Returns
        -------
        User
            User with the given identifier
        """
        link = posixpath.join(self._endpoint, ref)
        response = self.client.session.get(link)
        return self._from_json(response.json())

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=MAX_USER_CACHE), key=FactoryBase._cache_key_ref)
    def from_name(self, ref: str) -> User:
        """Retrieve a user from their name

        Parameters
        ----------
        ref : str
            User username

        Returns
        -------
        User
            User with the given username

        Notes
        -----
        When given username is equal to `everyone` (case-insensitive), a special Everyone-user is returned.
        """
        if ref.lower() == "everyone":
            return self.everyone

        params = {"username": ref}

        response = self.client.session.get(self.tm_class.endpoint, params=params)
        content = response.json()["_embedded"]["content"]

        # Since the call only returns exact username matches, only a single object should be returned. Nonetheless, we
        # robustly select the exact match in case multiple results are returned.
        return ip.object_match_nocase([self._from_json(data=data) for data in content], attribute="name", value=ref)

    def search(self, ref: str) -> List[User]:
        """Retrieve a user by any of their properties

        Searches by username, first name, last name, and email

        Parameters
        ----------
        ref : str
            Partial match for username, first name, last name or email

        Returns
        -------
        List[User]
            Users with a property matching the given search string

        Notes
        -----
        There is no endpoint for searching users by a specific property (e.g. username)

        Client users cannot be retrieved by this method. They can be retrieved by their exact name
        (`service-account-{client id}`) using the `.from_name` method.

        Searching for a first or last name with a string that includes spaces does not work.
        """
        params={
            "search": ref,
            "size": MAX_GET_SIZE
        }

        content = self.client.session.paginated(keys=["_embedded", "content"]).get(
            self.tm_class.endpoint,
            params=params
        )

        return [self._from_json(data=data) for data in content]

    def _from_json_everyone(self, data: Dict[str, Any]) -> User:
        """Create User instance from JSON data, handling Everyone user case.
        
        Parameters
        ----------
        data : Dict[str, Any]
            JSON data from server
            
        Returns
        -------
        User
            User instance
            
        Raises
        ------
        FromJsonError
            If data is not for Everyone user
        """
        if data.get("subjectType", "").upper() == "EVERYONE":
            return self.everyone
        else: # pragma: no cover
            raise FromJsonError(data)

    def _json_to_kwargs_base(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Get base keyword arguments for User creation from JSON data.
        
        Parameters
        ----------
        data : Dict[str, Any]
            JSON data from server
            
        Returns
        -------
        Dict[str, Any]
            Base keyword arguments
        """
        return {
            "first_name": data.get("firstName"),
            "last_name": data.get("lastName"),
            "subject_type": "USER",
        }

    @kwargs_to_class
    def _from_json(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create User instance from full JSON data.
        
        Parameters
        ----------
        data : Dict[str, Any]
            Full JSON data from server
            
        Returns
        -------
        Dict[str, Any]
            Keyword arguments for User creation
        """
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["userId"],
            "name": data["username"],
            "roles": data["roles"],
            "mail": data.get("email"),
            "created": data.get("createdDate"),
        }

    @kwargs_to_class
    def _from_json_limited(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create User instance from limited JSON data.
        
        Parameters
        ----------
        data : Dict[str, Any]
            Limited JSON data from server
            
        Returns
        -------
        Dict[str, Any]
            Keyword arguments for User creation
        """
        return {
            **self._json_to_kwargs_base(data),
            "identifier": data["identifier"],
            "name": data["username"],
        }

    @kwargs_to_class
    def _from_json_limited_id(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create User instance from limited JSON data with ID.
        
        Used in context filter and work organizer.
        
        Parameters
        ----------
        data : Dict[str, Any]
            Limited JSON data from server
            
        Returns
        -------
        Dict[str, Any]
            Keyword arguments for User creation
        """
        return {
            "identifier": data["userId"],
            "name": data["userName"],
        }

    @kwargs_to_class
    def _from_json_name_only(self, data: str) -> Dict[str, Any]:
        """Create lazy instance from only the name.
        
        Parameters
        ----------
        data : str
            User name
            
        Returns
        -------
        Dict[str, Any]
            Keyword arguments for User creation
        """
        return {"name": data}

    @kwargs_to_class
    def _from_json_identifier_only(self, data: str) -> Dict[str, Any]:
        """Create lazy instance from only the identifier.
        
        Parameters
        ----------
        data : str
            User identifier
            
        Returns
        -------
        Dict[str, Any]
            Keyword arguments for User creation
        """
        return {"identifier": data}

    @property
    def _get_methods(self) -> Tuple[Callable[[str], User], ...]:
        """Get methods for retrieving User instances.
        
        Returns
        -------
        Tuple[Callable[[str], User], ...]
            Tuple of methods that can retrieve User instances
        """
        return (self.from_name,)
