import abc
from typing import Any, Callable, Dict, Optional, Tuple, Union

from .session import TrendMinerSession


class BaseClient(abc.ABC):
    """Handles all authentication for the client. Stores the session.
    
    Attributes
    ----------
    session : TrendMinerSession
        Session object handling authentication and HTTP requests
    """

    def __init__(
            self,
            url: str,
            client_id: Optional[str],
            client_secret: Optional[str],
            username: Optional[str],
            password: Optional[str],
            refresh_token: Optional[str],
            access_token_getter: Optional[Callable[[], str]],
            verify: Union[bool, str],
            timeout: Union[float, Tuple[float, float]],
            proxies: Optional[Dict[str, str]],
            use_uma: bool = False,
            uma_audience: str = "tm-timeseries-builder",
    ) -> None:
        """Initialize BaseClient with authentication parameters.
        
        Parameters
        ----------
        url : str
            TrendMiner appliance URL
        client_id : Optional[str]
            OAuth client ID
        client_secret : Optional[str]
            OAuth client secret
        username : Optional[str]
            Username for authentication
        password : Optional[str]
            Password for authentication
        refresh_token : Optional[str]
            Refresh token for authentication
        access_token_getter : Optional[Callable[[], str]]
            Function to get access token
        verify : Union[bool, str]
            SSL verification setting
        timeout : Union[float, Tuple[float, float]]
            Request timeout setting
        proxies : Optional[Dict[str, str]]
            Proxy configuration
        use_uma : bool, default False
            Whether to use UMA authentication
        uma_audience : str, default "tm-timeseries-builder"
            UMA audience for token requests
        """
        self.session = TrendMinerSession(
            base_url=url,
            verify=verify,
            timeout=timeout,
            proxies=proxies,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            refresh_token=refresh_token,
            access_token_getter=access_token_getter
        )
        
        # If UMA authentication is requested, override the token refresh method
        if use_uma:
            self.session._token_refresh = lambda: self.session._TrendMinerSession__refresh_uma_token(uma_audience)
            # Get initial UMA token
            self.session._token_refresh()

    def switch_to_uma_auth(self, audience: str = "tm-timeseries-builder") -> None:
        """Switch to UMA authentication for MLHub access
        
        Parameters
        ----------
        audience : str, default "tm-timeseries-builder"
            The audience for the UMA token request
        """
        self.session._token_refresh = lambda: self.session._TrendMinerSession__refresh_uma_token(audience)
        # Get new UMA token
        self.session._token_refresh()

    @property
    def url(self) -> str:
        """TrendMiner appliance url
        
        Returns
        -------
        str
            The base URL of the TrendMiner appliance
        """
        return self.session.base_url

    def __repr__(self) -> str:
        """String representation of the client.
        
        Returns
        -------
        str
            Debug representation of the client
        """
        return f"<< {self.__class__.__name__}" \
               f" | {self.url}" \
               f" | {self.session.token_decoded['preferred_username']} >>"

