import re
import cachetools

from trendminer_interface.base import FactoryBase, kwargs_to_class, WorkOrganizerObjectFactoryBase, LazyAttribute

from trendminer_interface.constants import  MAX_FOLDER_CACHE
from trendminer_interface.exceptions import ResourceNotFound
from trendminer_interface.user import UserFactory

from .folder import Folder


class FolderFactory(WorkOrganizerObjectFactoryBase):
    """Factory for creating and retrieving folders"""
    tm_class = Folder

    def __call__(self, name, parent=None):
        """Instantiate a new work organizer folder

        Attributes
        ----------
        name : str
            Folder name
        parent : Folder, optional
            Parent folder. Leave at None to create a folder in the root work organizer folder

        Returns
        -------
        Folder
            New folder instance
        """
        return self.tm_class(
            client=self.client,
            identifier=None,
            name=name,
            parent=self._get(parent),
            owner=None,
            last_modified=None,
        )

    @kwargs_to_class
    def _from_json(self, data):
        """Full enriched payload"""
        kwargs = self._json_to_kwargs_base(data)
        kwargs.pop("description")  # no description for folders
        return kwargs

    def _from_json_work_organizer(self, data):
        """Browse payload is equal to full enriched payload"""
        return self._from_json(data)

    @property
    def root(self):
        """WorkOrganizerRoot instance with methods for browsing the work organizer root

        Returns
        -------
        root : Folder
            The authenticated user's root folder
        """
        return Folder(
            client=self.client,
            identifier=LazyAttribute(),
            name=LazyAttribute(),
            parent=None,  # The root folder actually has a system folder parent, but this does not concern the user
            owner=UserFactory(client=self.client).self,
            last_modified=LazyAttribute(),
        )

    def from_path(self, ref, create_new=False):
        """Retrieve or create a folder on a given path

        Parameters
        ----------
        ref : str
            Folder path
        create_new : bool, default False
            Whether a new folder needs to be created at the given path if no folder is found there. Creates intermediate
            folders on the path too.

        Returns
        -------
        Folder
            Folder on the given path
        """
        # Split in parts
        path = re.sub("^/", "", ref)
        parts = path.split("/")

        # Start at root folder
        current_folder = self.root

        # Iterate folders
        for part in parts:
            try:
                current_folder = current_folder.get_child_from_name(part, folders_only=True)
            except ResourceNotFound as e:
                if create_new:
                    if current_folder.is_root():
                        parent = None  # Set parent to None if we are still in the root directory
                    else:
                        parent = current_folder
                    new_folder = self.client.folder(name=part, parent=parent)
                    new_folder.save()
                    current_folder = new_folder
                else:
                    raise e

        return current_folder

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=MAX_FOLDER_CACHE), key=FactoryBase._cache_key_ref)
    def from_identifier(self, ref):
        """Retrieve folder from its identifier

        Parameters
        ----------
        ref : str
            Folder UUID

        Returns
        -------
        Folder
        """
        return super().from_identifier(ref)

    @property
    def _get_methods(self):
        return self.from_identifier, self.from_path

    @cachetools.cached(cache=cachetools.LRUCache(maxsize=10), key=FactoryBase._cache_key_ref)
    def _get_root_folder_identifier(self):
        """Get the root folder identifier by retrieving the first item in it and taking the parent id

        This function can be safely cached as the root identifier should never change

        Returns
        -------
        identifier : str
            The identifier of the authenticated user's root folder
        """
        params = {"size": 1}
        response = self.client.session.get("/work/saveditem/browse", params=params)
        content = response.json()["_embedded"]["content"]

        # TODO: the root folder can be empty, in which case we cannot retrieve the identifier this way. The only option would be creating a temporary object for this.
        if len(content) == 0:
            raise NotImplementedError("Retrieving the identifier of an empty work organizer is currently not supported")

        return content[0]["parentId"]
