import abc
from .pipeline import PipelineFactory


class PipelineClient(abc.ABC):
    """Pipeline Client"""
    @property
    def monitor(self):
        """Factory for pipelines

        Returns
        -------
        PipelineFactory
        """
        return PipelineFactory(client=self)