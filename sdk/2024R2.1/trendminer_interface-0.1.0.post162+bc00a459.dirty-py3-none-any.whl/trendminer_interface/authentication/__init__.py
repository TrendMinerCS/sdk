from .client import BaseClient
from .session import TrendMinerSession