from trendminer_interface.trendhub import TrendHubViewFactory
from .base import TileBase, TileFactoryBase


class TrendHubViewTile(TileBase):
    visualization_type = "TREND_HUB_VIEW"
    min_size = (2, 4)

    def _get_content(self, content):
        return TrendHubViewFactory(client=self.client)._get(content)

    def _json_configuration(self):
        return {
            "trendViewId": self.content.identifier
        }


class TrendHubViewTileFactory(TileFactoryBase):
    tm_class = TrendHubViewTile

    def _from_json_content(self, data):
        return TrendHubViewFactory(client=self.client)._from_json_identifier_only(data["trendViewId"])
