import abc

from .session import TrendMinerSession


class BaseClient(abc.ABC):
    """Handles all authentication for the client. Stores the session."""

    def __init__(
            self,
            url,
            client_id,
            client_secret,
            username,
            password,
            refresh_token,
            access_token_getter,
            verify,
            timeout,
            proxies,
            use_uma=False,
            uma_audience="tm-timeseries-builder",
    ):

        self.session = TrendMinerSession(
            base_url=url,
            verify=verify,
            timeout=timeout,
            proxies=proxies,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            refresh_token=refresh_token,
            access_token_getter=access_token_getter
        )
        
        # If UMA authentication is requested, override the token refresh method
        if use_uma:
            self.session._token_refresh = lambda: self.session._TrendMinerSession__refresh_uma_token(uma_audience)
            # Get initial UMA token
            self.session._token_refresh()

    def switch_to_uma_auth(self, audience="tm-timeseries-builder"):
        """Switch to UMA authentication for MLHub access
        
        Parameters
        ----------
        audience : str, default "tm-timeseries-builder"
            The audience for the UMA token request
        """
        self.session._token_refresh = lambda: self.session._TrendMinerSession__refresh_uma_token(audience)
        # Get new UMA token
        self.session._token_refresh()

    @property
    def url(self):
        """TrendMiner appliance url"""
        return self.session.base_url

    def __repr__(self):
        return f"<< {self.__class__.__name__}" \
               f" | {self.url}" \
               f" | {self.session.token_decoded['preferred_username']} >>"

