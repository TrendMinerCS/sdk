from .base import BaseACL, BaseACLFactory


class TimeseriesBuilderACL(BaseACL):
    endpoint = "confighub/v2/acl/TIMESERIES_BUILDER"

    def _full_instance(self):
        return TimeseriesBuilderACLFactory(client=self.client).from_identifier(self.identifier)


class TimeseriesBuilderACLFactory(BaseACLFactory):
    tm_class = TimeseriesBuilderACL
