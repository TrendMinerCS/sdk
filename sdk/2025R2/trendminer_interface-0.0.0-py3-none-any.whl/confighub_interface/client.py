import pytz

from trendminer_interface.authentication import BaseClient, TrendMinerSession

from .connector import ConnectorClient
from .user import ConfigUserClient
from .datasource import DatasourceClient
from .access import AccessClient
from .group import GroupClient
from .client_user import ClientUserClient


class ConfigClient(
    BaseClient,
    ConnectorClient,
    ConfigUserClient,
    DatasourceClient,
    AccessClient,
    GroupClient,
    ClientUserClient,
):

    def __init__(
            self,
            url,
            client_id=None,
            client_secret=None,
            username=None,
            password=None,
            access_token_getter=None,
            refresh_token=None,
            verify=True,
            tz=pytz.utc,
            timeout=(10, 120),
            proxies=None,
    ):
        BaseClient.__init__(
            self,
            url=url,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            refresh_token=refresh_token,
            access_token_getter=access_token_getter,
            verify=verify,
            timeout=timeout,
            proxies=proxies,
        )

        # Set the timezone
        self.tz = pytz.timezone(tz) if isinstance(tz, str) else tz
